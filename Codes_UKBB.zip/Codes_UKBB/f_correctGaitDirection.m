%{ 
*********************************************************************************
              Function "f_correctGaitDirection" linked to 
script "Auswertung_mitFormularen"& "Datenarchivierung_footmodel"
             runs from "f_load_c3d" & "f_Foot_load_c3d"
              by Sebastian Krapf & Katrin Schweizer Feb. 2014
*********************************************************************************

Uses "f_rotCoordinateSystem" to change coordinate system from vicon xyz to x'y'z'
Walking direktion gets positive x' (1)
Medio lateral = y'
Vertical stays z

Gets names for video (e.g. "AP anterior")

INPUT: Markers = Struct with markers
       Forces = Struct with forces

OUTPUT: Markers_GaitDirecCorrect = struct with marker, where x = walking direction,
                                   y = medio-laterl, z = vertical
        Forces_1 = see Markers
        videoFront/videoSagitt = New names for videos e.g. "Sagittal_right"
%}


function [Markers_GaitDirecCorrect,Forces_1,videoFront,videoSagitt] = f_correctGaitDirection(Markers,Forces)


    % find walking direction
    SACR = Markers.SACR;

    % delete zeros at the beginning or end of an trial
    SACR(sum(SACR==0,2)>0,:) = [];

    dir_i = abs(SACR(end, 1) - SACR(1, 1)); 
    dir_j = abs(SACR(end, 2) - SACR(1, 2)); 
    
    walkdir = 1;  % x is walkdir

    if (dir_i < dir_j)  
        walkdir = 2;  % y is walkdir
    end

    % pos. or neg. direktion on axis
    sgn = sign(SACR(end, walkdir) - SACR(1, walkdir));
    walkdir = walkdir * sgn;


    % rotate marker coordinate system with "f_rotCoordinateSystem"
    [Markers_GaitDirecCorrect,videoFront,videoSagitt] = f_rotCoordinateSystem(Markers, walkdir, 1);
    [Forces_1,videoFront,videoSagitt] = f_rotCoordinateSystem(Forces, walkdir, 1);

    
    % Normalised ground reaction forces are already corrected for gait
    % direction (back and forth) but not for the direction in the room
    if walkdir == 1 || walkdir == -1 %If they walked orthogonal in the the lab correct the walking direction
       Forces_1.RNormalisedGRF(:,1:2) = Forces.RNormalisedGRF(:,1:2).*-1;
       Forces_1.LNormalisedGRF(:,1:2) = Forces.LNormalisedGRF(:,1:2).*-1;
    elseif walkdir == 2 || walkdir == -2
       Forces_1.RNormalisedGRF(:,1:2) = Forces.RNormalisedGRF(:,1:2);
       Forces_1.LNormalisedGRF(:,1:2) = Forces.LNormalisedGRF(:,1:2);
    end
end %FUNCTION