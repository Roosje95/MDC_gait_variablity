function [out,allGaitCycles] = f_GaitGycles_List(c3d_infos,emg)
%{
by M. Freslier, Dez. 2017

from the list of c3d analysed, makes a list with all the gait cycles and
corresponding informations

INPUT
    c3d_infos = struct with all the informations (obtain from the main
                script)
        .filename = name of the c3d
        .processed = if the c3d is processed or not
        .gaitcycles = a cell array with informations of the gait cycles:
            {x,1} = side
            {x,2} = 'FPx' (kinetics on force plate 'x', x=0 if no kinetics)
            {x,3} = a struct with the events (FS ipsi&contra, FO ipsi&contra)
            {x,4} = step number, obtained from the definition of the 4th
                    step, 0 if undetermined
            {x,5} = step number, obtained from the 1st gait cycle defined
                    in the trial
    emg = 'y' or 'n': gives the information if emg was recorded.
OUTPUT
    allGaitCycles = a cell array with informations of the gait cycles:
        {x,1} = name of the c3d
        {x,2} = side
        {x,3} = 'FP0' (no kinetics)
        {x,4} = a struct with the events (FS ipsi&contra, FO ipsi&contra)
        {x,5} = step number, obtained from the definition of the 4th
                step, 0 if undetermined
        {x,6} = trial number (obtained from the c3d name)
        {x,7} = step number, obtained from the 1st gait cycle defined
                in the trial, -1 if impossible to determine
        {x,8} = is emg recorded? 'y' or 'n'

    out = 1 if all ok, 0 if there is a problem to determine the
    informations
%}
if ~isempty(c3d_infos)
    nb_GZ = 0;
    for files = 1:length(c3d_infos)
        trial = regexp(c3d_infos(files).filename,'K\d+_|N\d+|B\d+|R\d+|L\d+','match','once');
        %trial_1 = regexp(c3d_infos(files).filename,'K|N|B|R|L','match','once');
        if ~isempty(trial)
            trialNb = str2num(regexp(trial,'\d+','match','once'));
        else
         trialNb = str2num(c3d_infos(files).filename(end-5:end-4));
        end
       
            for GZ = 1:size(c3d_infos(files).gaitcycles,1)
                nb_GZ = nb_GZ + 1;
                allGaitCycles{nb_GZ,1} = c3d_infos(files).filename;
                allGaitCycles{nb_GZ,2} = c3d_infos(files).gaitcycles{GZ,1};
                allGaitCycles{nb_GZ,3} = c3d_infos(files).gaitcycles{GZ,2};
                allGaitCycles{nb_GZ,4} = c3d_infos(files).gaitcycles{GZ,3};
                allGaitCycles{nb_GZ,5} = c3d_infos(files).gaitcycles{GZ,4};
                allGaitCycles{nb_GZ,6} = trialNb;
                allGaitCycles{nb_GZ,7} = c3d_infos(files).gaitcycles{GZ,5};
                allGaitCycles{nb_GZ,8} = emg;
            end
    end
    out = 1;
else
    out = 0;
    disp('!!! error in f_GaitGycles_List.m: !!!');
    disp('!!! the c3d list is empty. ���');
end
end