%{ 
*********************************************************************************
Function "f_checkKinetic" linked to function "f_extractTrials"
         adapted from "f_checkKineticSide" (by Katrin Schweizer Nov. 2013)
                      by Marie Freslier Jan 2017
*********************************************************************************

INPUT:
    description (cell) = text of the feld Description from enf file
    filename = name of the trial

OUTPUT:
    out = 1 if all ok, 0 if there is a problem to determine the kinetic
    kinetic = a list of the forceplate properly hit 
                (e.g. kinetic(i)=('left','FP2')), if no plate has been hit,
                kinetic=('none','FP0')
%}

function [out,kinetic] = f_checkKinetic(description,filename)

    nbKinetic = 1;
    if isempty(description) || strcmp(description{1},'') || ...
          strncmp(description{1},'ok',2)
        % i.e. dynamic without kinetic
        kinetic{nbKinetic,1} = 'none';
        kinetic{nbKinetic,2} = 'FP0';
        out = 1;
    else
        % extract the description of the hit forceplates: l/r+1..4
        forceplates = regexp(description{1},'l\d|r\d','match','all','ignorecase');
        if isempty(forceplates)
            disp(['!!! no correct kinetic description found for the trial ' filename ' !!!']);
            disp('!!! -> Trial considered as trial without kinetic. !!!');
            kinetic{nbKinetic,1} = 'none';
            kinetic{nbKinetic,2} = 'FP0';
            out = 1;
        else
            for i=1:size(forceplates,2)
                switch forceplates{1,i}(1)
                    case 'r'
                        kinetic{nbKinetic,1} = 'right';
                    case 'l'
                        kinetic{nbKinetic,1} = 'left';
                end
                switch forceplates{1,i}(2)
                    case '1'
                        kinetic{nbKinetic,2} = 'FP1';
                        nbKinetic = nbKinetic + 1;
                    case '2'
                        kinetic{nbKinetic,2} = 'FP2';
                        nbKinetic = nbKinetic + 1;
                    case '3'
                        kinetic{nbKinetic,2} = 'FP3';
                        nbKinetic = nbKinetic + 1;
                    case '4'
                        kinetic{nbKinetic,2} = 'FP4';
                        nbKinetic = nbKinetic + 1;
                    otherwise
                        disp(' ');
                        disp('!!! error in f_checkKinetic.m: !!!');
                        disp(['!!! Forceplate number isn''t right for Trial ' filename ' !!!']);
                        disp('!!!!!!! Please correct it !!!!!!!!');
                        out = 0;
                        return
                end
            end
            out = 1;
        end
    end
            
%     if sum(strncmp(enf_data,'fp1=',4))~=0
%         fp1 = enf_data{strncmp(enf_data,'fp1=',4)};
%     else fp1 = '';
%     end
%     if sum(strncmp(enf_data,'fp2=',4))~=0
%         fp2 = enf_data{strncmp(enf_data,'fp2=',4)};
%     else fp2 = '';
%     end
%     if sum(strncmp(enf_data,'fp3=',4))~=0
%         fp3 = enf_data{strncmp(enf_data,'fp3=',4)};
%     else fp3 = '';
%     end
%     if sum(strncmp(enf_data,'fp4=',4))~=0
%         fp4 = enf_data{strncmp(enf_data,'fp4=',4)};
%     else fp4 = '';
%     end
%     
%     nbKinetic = 1;
%     
%     switch fp1
%         case 'fp1=left'
%             kinetic{nbKinetic,1} = 'left';
%             kinetic{nbKinetic,2} = 'FP1';
%             nbKinetic = nbKinetic + 1;
%         case 'fp1=right'
%             kinetic{nbKinetic,1} = 'right';
%             kinetic{nbKinetic,2} = 'FP1';
%             nbKinetic = nbKinetic + 1;
%     end % switch fp1
%     
%     switch fp2
%         case 'fp2=left'
%             kinetic{nbKinetic,1} = 'left';
%             kinetic{nbKinetic,2} = 'FP2';
%             nbKinetic = nbKinetic + 1;
%         case 'fp2=right'
%             kinetic{nbKinetic,1} = 'right';
%             kinetic{nbKinetic,2} = 'FP2';
%             nbKinetic = nbKinetic + 1;
%     end % switch fp2
%         
%     switch fp3
%         case 'fp3=left'
%             kinetic{nbKinetic,1} = 'left';
%             kinetic{nbKinetic,2} = 'FP3';
%             nbKinetic = nbKinetic + 1;
%         case 'fp3=right'
%             kinetic{nbKinetic,1} = 'right';
%             kinetic{nbKinetic,2} = 'FP3';
%             nbKinetic = nbKinetic + 1;
%     end % switch fp3
%     
%     switch fp4
%         case 'fp4=left'
%             kinetic{nbKinetic,1} = 'left';
%             kinetic{nbKinetic,2} = 'FP4';
%             nbKinetic = nbKinetic + 1;
%         case 'fp4=right'
%             kinetic{nbKinetic,1} = 'right';
%             kinetic{nbKinetic,2} = 'FP4';
%             nbKinetic = nbKinetic + 1;
%     end % switch fp4
%     
%     if nbKinetic == 1 % no forceplate was hit
%         kinetic{nbKinetic,1} = 'none';
%         kinetic{nbKinetic,2} = 'FP0';
%     end
    

end % FUNCTION