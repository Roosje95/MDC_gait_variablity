function [out,list_GCs_selected,Kinetic_4orMore] = f_checkGaitCycles(list_GC)
%{
by M. Freslier, Mar. 2018

through a list of trials, where the gait cycles were already analysed and
their type determined (side, which forceplate, step number), the function
define which gait cycles (6x) will be used for the analysis:
- goal is 6 gait cycles for left&right from 4th and 5th steps
- otherwise others gait cycles from 3rd and more than 6th steps are taken.
- if the step numbers are unknown, all the steps are taken
- if there isn't any kinetics, all the gait cycles are taken (current
version: only 2 gait cycles per trials)

INPUT
    list_c3d: a struct with the trials informations (filename and a cell array with the
    gait cycles: {x,2} = side, {x,3} = forceplate, {x,4} = a struct with
    the events (FS ipsi&contra, FO ipsi&contra),{x,5} = step number (from 1st step =0 if
    undetermined), {x,6} = trial number, {x,7} = step number (from 1st gait
    cycle defined), {x,8} = is emg recorded? 'y' or 'n'
OUTPUT
    out = 1 if all ok, 0 if there is a problem to determine the
    informations
    list_GCs_selected = a list of the selected gait cycles
        {x,1} = filename of the c3d
        {x,2} = side
        {x,3} = forceplate
        {x,4} = struct with the events (FS ipsi&contra, FO ipsi&contra)
        {x,5} = step number, obtained from the definition of the 4th
                step, 0 if undetermined
        {x,6} = trial number (obtained from the c3d name)
        {x,7} = step number, obtained from the 1st gait cycle defined
                in the trial, -1 if impossible to determine
        {x,8} = is emg recorded? 'y' or 'n'
    Kinetic_4orMore = 1 if there is anough kinetics (>= 4x), else =0
%}
out = 1;

if isempty(list_GC)
    out = 0;
    disp('!!! error in f_checkGaitCycles.m: !!!');
    disp('!!! the list of gait cycles is empty !!!');
    list_GCs_selected = {};
    Kinetic_4orMore = 0;
    return
else nb_colomn = size(list_GC,2);
end

nb_le = 0;
nb_ri = 0;
index_fp_R_45 = 0;
index_fp_L_45 = 0;
index_fp_R = 0;
index_fp_L = 0;
index_fp_R_N = 0;
index_fp_L_N = 0;
list_fp_R = cell(1,nb_colomn);
list_fp_L = cell(1,nb_colomn);
list_fp_R_N = cell(1,nb_colomn);
list_fp_L_N = cell(1,nb_colomn);
list_fp_R_45 = cell(1,nb_colomn);
list_fp_L_45 = cell(1,nb_colomn);

for GC=1:size(list_GC,1)
    switch list_GC{GC,3}
        case 'FP0'
            switch list_GC{GC,2}
                case 'right'
                    index_fp_R_N = index_fp_R_N + 1;
                    list_fp_R_N(index_fp_R_N,:) = list_GC(GC,:);
                case 'left'
                    index_fp_L_N = index_fp_L_N + 1;
                    list_fp_L_N(index_fp_L_N,:) = list_GC(GC,:);
            end % switch side of the gait cycle
        otherwise
            switch list_GC{GC,2}
                case 'right'
                    switch list_GC{GC,5}
                        case {4,5}
                            nb_ri = nb_ri + 1;
                            index_fp_R_45 = index_fp_R_45 + 1;
                            list_fp_R_45(index_fp_R_45,:) = list_GC(GC,:);
                        case 0
                            nb_ri = nb_ri + 1;
                            index_fp_R = index_fp_R + 1;
                            list_fp_R(index_fp_R,:) = list_GC(GC,:);
                        case {1,2}
                            % do nothing: the gait cycle is too small
                        otherwise % =3 or >= 6
                            nb_ri = nb_ri + 1;
                            index_fp_R = index_fp_R + 1;
                            list_fp_R(index_fp_R,:) = list_GC(GC,:);
                    end % switch step number
                case 'left'
                    switch list_GC{GC,5}
                        case {4,5}
                            nb_le = nb_le + 1;
                            index_fp_L_45 = index_fp_L_45 + 1;
                            list_fp_L_45(index_fp_L_45,:) = list_GC(GC,:);
                        case 0
                            nb_le = nb_le + 1;
                            index_fp_L = index_fp_L + 1;
                            list_fp_L(index_fp_L,:) = list_GC(GC,:);
                        case {1,2}
                            % do nothing: the gait cycle is too small
                        otherwise % =3 or >= 6
                            nb_le = nb_le + 1;
                            index_fp_L = index_fp_L + 1;
                            list_fp_L(index_fp_L,:) = list_GC(GC,:);
                    end % switch step number
            end % switch side of the gait cycle
    end % switch kinetic or not of the gait cycle
end % for GC=1:size(list_GC,1)

if index_fp_L_45>=6 && index_fp_R_45>=6
    Kinetic_4orMore = 1;
    list_GCs_selected = [list_fp_L_45(1:6,:) ; list_fp_R_45(1:6,:)];
elseif nb_le>=4 && nb_ri>=4
    % if there is enough for le&ri (>=4 for each side),
    % they are all taken for print
    Kinetic_4orMore = 1;
    if index_fp_L_45 >= 6
        list_L = list_fp_L_45(1:6,:);
    else
        n_L = min(6-index_fp_L_45,index_fp_L);
        list_L = [list_fp_L_45(1:index_fp_L_45,:) ; list_fp_L(1:n_L,:)];
    end
    if index_fp_R_45 >= 6
        list_R = list_fp_R_45(1:6,:);
    else
        n_R = min(6-index_fp_R_45,index_fp_R);
        list_R = [list_fp_R_45(1:index_fp_R_45,:) ; list_fp_R(1:n_R,:)];
    end
    list_GCs_selected = [list_L ; list_R];
else
    if index_fp_R_N < 4 || index_fp_L_N < 4
        out = 0;
        disp('!!! error in f_checkGaitCycles.m: !!!');
        disp('!!! there isn''t enough gait cycles !!!');
        list_GCs_selected = {};
        Kinetic_4orMore = 0;
        return
    else
        % else it all be without kinetic
        Kinetic_4orMore = 0;
        list_L = [list_fp_L_45(1:index_fp_L_45,:) ; list_fp_L(1:index_fp_L,:) ; ...
            list_fp_L_N(1:index_fp_L_N,:)];
        list_R = [list_fp_R_45(1:index_fp_R_45,:) ; list_fp_R(1:index_fp_R,:) ; ...
            list_fp_R_N(1:index_fp_R_N,:)];
        
        n_L = min(6,size(list_L,1));
        n_R = min(6,size(list_R,1));
        
        list_GCs_selected = [list_L(1:n_L,:) ; list_R(1:n_R,:)];
    end
end
    