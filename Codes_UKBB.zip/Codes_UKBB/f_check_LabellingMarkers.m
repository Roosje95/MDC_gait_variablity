%{ 
*********************************************************************************
     Function "f_check_LabellingMarkersChiBa15b" linked to script "Auswertung_mitFormularen"
                          runs from "f_load_c3d"
                    by Katrin Bracht Oct. 2017
*********************************************************************************

Checks marker labelling for the ChiBa15b-Modell:

- Checks if there are gaps
- Checks if specific Markers are Anterior, Left of, or Above other markers at heel strike

Anterior:
  CLAV to C7      STERN to TH10    LFHD to LBHD      RFHD to RBHD
  LTOE to LHEE    RTOE to RHEE
  LHLX to LTOE    RHLX to RTOE     LASI to LPSI      RASI to RPSI
Left of:
  LFHD to RFHD    LBAK to C7       LSHO to RSHO      LELB to RELB
  LASI to RASI    LANK to RANK     LMT1 to LMT5      RMT5 to RMTS1
  LDMT5 to LDMT1   RDMT5 to RDMT1  LPSI to SACR      SACR to RPSI
Above:
  C7 to TH10      LSHO to LBAK 
  LTUB to LDTIB   RTUB to RDTIB    LPTHI_LDTHI       RPTHI_RDTHI
  LASI to LTRO    RASI to RTRO     LTRO to LTHI      RTRO to RTHI

INPUT: dataAll = Markers in struct as delivered by c3d, with gait direction corrected
       TrialNum = Trial number
       Events = Events in struct as delivered by c3d, but transferred to frames

OUTPUT: Error warnings
        e.g.: "Check labelling CLAV and C7"
%}

function out = f_check_LabellingMarkers(dataAll,TrialNum,Events)
    out = 1;
%% Remove fields with unlabelled markers from struct with marker (e.g. 'C_47')
  % if markers were unlabelled or if we had ghost markers they come up as 'C_number'
  
   FieldsMarker = fieldnames(dataAll);  
   UnlabelledMarkers = strncmp('C_',FieldsMarker,2);   
   Fields2Remove = FieldsMarker(UnlabelledMarkers,:)';    
   dataAll = rmfield(dataAll,Fields2Remove);
   if isfield(dataAll,'CentreOfMassFloor') == 1
      dataAll = rmfield(dataAll,'CentreOfMassFloor');
   end %IF isfield(dataAll,'CentreOfMassFloor') == 1
   
%% Cut data to the period between the first and last event 
   %--> to check marker labelling from data inbetween events only
   EV(1:2,1) = Events.Left_Foot_Strike';
   EV(3:4,1) = Events.Right_Foot_Strike';
   EV(5:6,1) = Events.Left_Foot_Off';
   EV(7:8,1) = Events.Right_Foot_Off';
   
   MinEV = min(EV);
   MaxEV = max(EV);
   
   data = structfun(@(x) (x(MinEV:MaxEV,:)), dataAll, 'UniformOutput', false);
   
   % Cut data to single support
   data_stanceLeft = structfun(@(x) (x(Events.Left_Foot_Strike(1,1):Events.Right_Foot_Off(1,1),:)), dataAll, 'UniformOutput', false);  
   data_stanceRight = structfun(@(x) (x(Events.Right_Foot_Strike(1,1):Events.Left_Foot_Off(1,1),:)), dataAll, 'UniformOutput', false); 
   
   % Cut data to initial contact
   data_IC_Left = structfun(@(x) (x(Events.Left_Foot_Strike(1,1),:)), dataAll, 'UniformOutput', false);  
   data_IC_Right = structfun(@(x) (x(Events.Right_Foot_Strike(1,1),:)), dataAll, 'UniformOutput', false); 
   
%% Check if there are gaps in labelled markers

    FindGAPS = structfun(@(x) (x(x==0)), data, 'UniformOutput', false);
    Fields = fieldnames(FindGAPS);   
   
    for i = 1:size(Fields,1);  
        if ~isempty(FindGAPS.(Fields{i,1}))
           disp(' '); disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
           disp(['Marker gaps in ' TrialNum])
           disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
           ERROR
        end %IF ~isempty(FindGAPS.(Fields{i,1}))
    end %FOR i = 1:size(Fields,1); 
   
 
%% Anterior/Posterior: 
   
   % CLAV_C7
   PosAnt = data.CLAV < data.C7; % zero if CLAV is anterior to C7
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'CLAV','C7',TrialNum);

   % STRN_T10
   PosAnt = data.STRN < data.T10; % zero if STRN is anterior to T10
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'STRN','T10',TrialNum);
   
   % LFHD_LBHD
   PosAnt = data.LFHD < data.LBHD; % zero if LFHD is anterior to LBHD
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LFHD','LBHD',TrialNum);
   
   % RFHD_RBHD
   PosAnt = data.RFHD < data.RBHD; % zero if RFHD is anterior to RBHD
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RFHD','RBHD',TrialNum);
   
   % LTOE_LHEE
   PosAnt = data_stanceLeft.LTOE < data_stanceLeft.LHEE; % zero if LTOE is anterior to LHEE
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LTOE','LHEE',TrialNum);

   % RTOE_RHEE
   PosAnt = data_stanceRight.RTOE < data_stanceRight.RHEE; % 0 if RTOE is anterior to RHEE
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RTOE','RHEE',TrialNum);
 
 %ChiBa Marker
   % LHLX_LTOE
   PosAnt = data_stanceLeft.LHLX < data_stanceLeft.LTOE; % zero if LHLX is anterior to LTOE
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LHLX','LTOE',TrialNum);

   % RHLX_RTOE
   PosAnt = data_stanceRight.RHLX < data_stanceRight.RTOE; % 0 if RHLX is anterior to RTOE
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RHLX','RTOE',TrialNum);
   
   % LASI_LPSI
   PosAnt = data_stanceLeft.LASI < data_stanceLeft.LPSI; % zero if LASI is anterior to LPSI
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LASI','LPSI',TrialNum);

   % RASI_RPSI
   PosAnt = data_stanceRight.RASI < data_stanceRight.RPSI; % 0 if RASI is anterior to RPSI
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RASI','RPSI',TrialNum);

   % LSITA_LANK
   PosAnt = data_IC_Left.LSITA < data_IC_Left.LANK; %  = zero if LSITA is anterior to LANK   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LSITA','LANK',TrialNum);
   
   % LSITA_LHEE
   PosAnt = data_IC_Left.LSITA < data_IC_Left.LHEE; %  = zero if LSITA is anterior to LHEE   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LSITA','LHEE',TrialNum);
   
   % LTOE_LCUN
   PosAnt = data_IC_Left.LTOE < data_IC_Left.LCUN; %  = zero if LTOE is anterior to LCUN   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LTOE','LCUN',TrialNum);
   
   % LDMT1_LPMT1
   PosAnt = data_IC_Left.LDMT1 < data_IC_Left.LPMT1; %  = zero if LDMT1 is anterior to LPMT1   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LDMT1','LPMT1',TrialNum);
   
   % LDMT5_LPMT5
   PosAnt = data_IC_Left.LDMT5 < data_IC_Left.LPMT5; %  = zero if LDMT5 is anterior to LPMT5   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LDMT5','LPMT5',TrialNum);
   
   % LTPR_LHEE
   PosAnt = data_IC_Left.LTPR < data_IC_Left.LHEE; %  = zero if LTPR is anterior to LHEE   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'LTPR','LHEE',TrialNum);
   
  
   % RSITA_RANK
   PosAnt = data_IC_Right.RSITA < data_IC_Right.RANK; %  = zero if RSITA is anterior to RANK   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RSITA','RANK',TrialNum);
   
   % RSITA_RHEE
   PosAnt = data_IC_Right.RSITA < data_IC_Right.RHEE; %  = zero if RSITA is anterior to RHEE   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RSITA','RHEE',TrialNum);
   
   % RTOE_RCUN
   PosAnt = data_IC_Right.RTOE < data_IC_Right.RCUN; %  = zero if RTOE is anterior to RCUN   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RTOE','RCUN',TrialNum);
   
   % RDMT1_RPMT1
   PosAnt = data_IC_Right.RDMT1 < data_IC_Right.RPMT1; %  = zero if RDMT1 is anterior to RPMT1   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RDMT1','RPMT1',TrialNum);
   
   % RDMT5_RPMT5
   PosAnt = data_IC_Right.RDMT5 < data_IC_Right.RPMT5; %  = zero if RDMT5 is anterior to RPMT5   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RDMT5','RPMT5',TrialNum);
   
   % RTPR_RHEE
   PosAnt = data_IC_Right.RTPR < data_IC_Right.RHEE; %  = zero if RTPR is anterior to RHEE   
   out = out * f_warnIf_LabellingError(PosAnt(:,1),'RTPR','RHEE',TrialNum);
   
%% Left/Right 
   
   % LFHD_RFHD
   PosLeft = data.LFHD < data.RFHD; % zero if LFHD is left of RFHD
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LFHD','RFHD',TrialNum);

   % LBAK_C7
   PosLeft = data.LBAK < data.C7; % zero if LBAK is left of C7
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LBAK','C7',TrialNum);

   % LSHO_RSHO
   PosLeft = data.LSHO < data.RSHO; % zero if LSHO is left of RSHO
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LSHO','RSHO',TrialNum);

   % LELB_RELB
   PosLeft = data.LELB < data.RELB; % zero if LELB is left of RELB
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LELB','RELB',TrialNum);

   % LASI_RASI
   PosLeft = data.LASI < data.RASI; % zero if LASI is left of RASI
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LASI','RASI',TrialNum);

   
 % ChiBa Marker
 
   % LDMT5_LDMT1
   PosLeft = data_stanceLeft.LDMT5 < data_stanceLeft.LDMT1; % zero if LDMT5 is left of LDMT1
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LDMT5','LDMT1',TrialNum);

   % RDMT1_RDMT5
   PosLeft = data_stanceRight.RDMT1 < data_stanceRight.RDMT5; % zero if RDMT1 is left of RDMT5
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'RDMT1','RDMT5',TrialNum);

   % LPSI_SACR
   PosLeft = data_stanceLeft.LPSI < data_stanceLeft.SACR; % zero if LPSI is left of SACR
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LPSI','SACR',TrialNum);

   % SACR_RPSI
   PosLeft = data_stanceLeft.SACR < data_stanceLeft.RPSI; % zero if SACR is left of RPSI
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'SACR','RPSI',TrialNum);

   % LTRO_RTRO
   PosLeft = data_IC_Left.LTRO < data_IC_Left.RTRO; %  = zero if LTRO is left of RTRO   
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LTRO','RTRO',TrialNum);
  
   % LTPR_RTPR
   PosLeft = data_IC_Left.LTPR < data_IC_Left.RTPR; %  = zero if LTPR is left of RTPR   
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LTPR','RTPR',TrialNum);
      
   % LHLX_RHLX
%    PosLeft = data_IC_Left.LHLX < data_IC_Left.RHLX; %  = zero if LHLX is left of RHLX   
%    out = out * f_warnIf_LabellingError(PosLeft(:,2),'LHLX','RHLX',TrialNum);
   
   % LPMT5_LPMT1
   PosLeft = data_IC_Left.LPMT5 < data_IC_Left.LPMT1; %  = zero if LPMT5 is left of LPMT1   
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'LPMT5','LPMT1',TrialNum);
   
   % RPMT1_RPMT5
   PosLeft = data_IC_Right.RPMT1 < data_IC_Right.RPMT5; %  = zero if RPMT1 is left of RPMT5  
   out = out * f_warnIf_LabellingError(PosLeft(:,2),'RPMT1','RPMT5',TrialNum);
   
   
   
%% Above/Below
   
   % C7_T10
   PosAbove = data.C7 < data.T10; % zero if C7 is above of T10
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'C7','T10',TrialNum);
   
   % LSHO_LBAK
   PosAbove = data.LSHO < data.LBAK; % zero if LSHO is above of LBAK
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'LSHO','LBAK',TrialNum);

 % ChiBa Marker
   % LTUB_LDTIB
   PosAbove = data.LTUB < data.LDTIB; % zero if LTUB is above of LDTIB
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'LTUB','LDTIB',TrialNum);
   % RTUB_RDTIB
   PosAbove = data.RTUB < data.RDTIB; % zero if RTUB is above of RDTIB
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'RTUB','RDTIB',TrialNum);
   
   % LPTHI_LDTHI
   PosAbove = data.LPTHI < data.LDTHI; % zero if LPTHI is above of LDTHI
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'LPTHI','LDTHI',TrialNum);
   % RPTHI_RDTIB
   PosAbove = data.RPTHI < data.RDTHI; % zero if RPTHI is above of RDTHI
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'RPTHI','RDTHI',TrialNum);
   
   % LASI_LTRO
   PosAbove = data.LASI < data.LTRO; % zero if LASI is above of LTRO
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'LASI','LTRO',TrialNum);
   % RASI_RTRO
   PosAbove = data.RASI < data.RTRO; % zero if RASI is above of RTRO
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'RASI','RTRO',TrialNum);
   
   % LTRO_LTHI
   PosAbove = data.LTRO < data.LTHI; % zero if LTRO is above of LTHI
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'LTRO','LTHI',TrialNum);
   % RASI_RTRO
   PosAbove = data.RTRO < data.RTHI; % zero if RTRO is above of RTHI
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'RTRO','RTHI',TrialNum);
 
   % LANK_LTPR
   PosAbove = data_IC_Left.LANK < data_IC_Left.LTPR; %  = zero if LANK is above the LTPR   
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'LANK','LTPR',TrialNum);
   % RANK_RTPR
   PosAbove = data_IC_Right.RANK < data_IC_Right.RTPR; %  = zero if RANK is above the RTPR   
   out = out * f_warnIf_LabellingError(PosAbove(:,3),'RANK','RTPR',TrialNum);
   
   
  %%
  if out == 1
    disp('++++++++++++++++++++')
    disp('Markers were checked --> no errors')
    disp(TrialNum)
    disp('++++++++++++++++++++')
  else
      disp('++++++++++++++++++++')
    disp('Markers were checked --> some errors, please correct and run the script')
    disp(TrialNum)
    disp('++++++++++++++++++++')
  end
end %FUNCTION


%{ 
*********************************************************************************
        Function "f_warnIf_LabellingError" linked to script
                    "Datenarchivierung_footmodel"
     runs from "f_check_LabellingMarkers" % "f_Foot_check_LabellingMarkers"
                    by Katrin Schweizer April 2015
*********************************************************************************

Checks marker labelling:

INPUT: data = difference between the two markers that are checked 
       Name1 = First marker name (e.g. 'RASI')
       Name2 = Second marker name
       TrialNum = Path to the c3d where events are wrong
       
OUTPUT: Error warnings
        e.g.: "Check labelling CLAV and C7"
%}

function out = f_warnIf_LabellingError(data,Name1,Name2,TrialNum)
    out = 1;
   if nanmean(data) > 0 
      
      disp(' '); disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
      disp(['Check labelling ' Name1 ' and ' Name2])
      disp(['In file: ',TrialNum])
      disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
      disp(' '); disp('Do you want to continue?')
      disp(' '); disp('no, check other markers then stop script -------->  0')
      disp(' '); disp('yes, ignore           --------------------------->  ENTER')
      disp(' '); Marker = input('Selection: ','s');
      Marker = lower(Marker); disp(' ')
      
      switch Marker
          case {'0'} %  
              out = 0;
                % stop the script execution
                return
%                 ERROR
          case {'ENTER'} % if script should be continued           
      end %SWITCH Marker
             
   end %IF nanmean(data) > 0 
end %FUNCTION f_warnIf_LabellingError(data,Name1,Name2,TrialNum)