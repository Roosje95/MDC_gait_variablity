%{
*********************************************************************************
                        Function "f_clinic2_c3d"
                     by Katrin Schweizer Oct. 2014
                    adapted by Marie F. July 2017
*********************************************************************************

Writes all important values and comments from the "clinical measurement form" 
and the "measurement information" to the c3d file.
                                     
INPUT
  Params4_c3d = Struct with all clinical measurements & measurement information form,
                NameParameter.Value (value is in string)
  acq = data acquisition for btk


OUTPUT
  acq = new data aquisition for btk with clinical measurements & measurement information
  
%}

function acq = f_clinic2_c3d(Params4_c3d,acq)

    Fields = fieldnames(Params4_c3d);

    %% Delete the fields that do not go into c3d
     
    ToDelete = {'LTibialTorsion_Grad',...
                'RTibialTorsion_Grad','Physio','Birthday','Date','Diagnostic_infos',...
                'Therapie_infos','Question','Scientist','Agreement','For_research'...
                'Meas_Type_1','Meas_Type_2','Meas_Type_3','Meas_Type_4','Meas_Type_5',...
                'EMG1','EMG2','EMG3','EMG4','EMG5','EMG6','EMG7','EMG8','EMG9',...
                'EMG10','EMG11','EMG12','EMG13','EMG14','EMG15','EMG16',...
                'EMG_channel_1','EMG_channel_1_muscle','EMG_channel_2','EMG_channel_2_muscle',...                
                'EMG_channel_3','EMG_channel_3_muscle','EMG_channel_4','EMG_channel_4_muscle',...
                'EMG_channel_5','EMG_channel_5_muscle','EMG_channel_6','EMG_channel_6_muscle',...
                'EMG_channel_7','EMG_channel_7_muscle','EMG_channel_8','EMG_channel_8_muscle',...
                'EMG_channel_9','EMG_channel_9_muscle','EMG_channel_10','EMG_channel_10_muscle',...
                'EMG_channel_11','EMG_channel_11_muscle','EMG_channel_12','EMG_channel_12_muscle',...
                'EMG_channel_13','EMG_channel_13_muscle','EMG_channel_14','EMG_channel_14_muscle',...
                'EMG_channel_15','EMG_channel_15_muscle','EMG_channel_16','EMG_channel_16_muscle',...
                'Labor','Surname','Firstname','Patient_ID'}';
    
     DeleteRows = ismember(Fields,ToDelete); %Identify rows
     Fields(DeleteRows,:) = []; %Delete fields
    
 
%**************************************************************************         
     %% Write information to MetaData in c3d file
%**************************************************************************

     for i = 1:size(Fields,1) 

         %if field value is not empty
         if ~isempty(Params4_c3d.(Fields{i})); 

            Value = str2double(Params4_c3d.(Fields{i})); 

            %If value is string
            if isnan(Value)               
               Type = 'Char';
               Input = {Params4_c3d.(Fields{i})(:,:)};              
            else %if value is double                
               Type = 'Real';
               Input = Value;               
            end

            btkAppendMetaData(acq, 'PROCESSING', Fields{i}, ...
            btkMetaDataInfo(Type,Input));

         end % IF ~isempty(Params4_c3d.(Fields{i}));    

     end % FOR i = 1:size(Params4_c3d,1)

%**************************************************************************     
    %% Write the new MetaData into acquision (c3d file)
%**************************************************************************

%     btkWriteAcquisition(acq,Path_c3d);
    
    
end %FUNCTION