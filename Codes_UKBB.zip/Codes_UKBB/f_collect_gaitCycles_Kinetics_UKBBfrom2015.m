function [out,gaitCycles_infos] = f_collect_gaitCycles_Kinetics_UKBBfrom2015(acq)
%{
by M. Freslier, Mar. 2017

collects the events for all gait cycles from a trial.
If the trial has kinetics, the gait cycles are determined by general events.
If the 4th step is determined, a general event defines it. Then the number
of each gait cycle will be determined

INPUT
    acq = handle to the trial (obtain from btkReadAcquisition)
OUTPUT
    gaitCycles_infos = a cell array with informations of the gait cycles:
        {x,1} = side
        {x,2} = forceplate
        {x,3} = a struct with the events (FS ipsi&contra, FO ipsi&contra)
        {x,4} = step number (=0 if undetermined)
        {x,5} = step number, obtained from the 1st gait cycle defined in 
                the trial
    out = 1 if all ok, 0 if there is a problem to determine the
    informations
%}
% by R.Visscher - April 2020
%   adapted to work on btk structs

    out = 1;
    gaitCycles_infos = {};
    
    %% remove subject name in event description and read events
    for t = 1 : btkGetEventNumber(acq)
        btkSetEventSubject(acq, t, '');
    end
    clear t
    events_struct = btkGetEvents(acq);

    
    % test if event is present
    if  ~isempty(struct2cell(events_struct))
        
        event_names = {};
        event_s = {};
        event_general = {};
        TO_4thStep = 0;
        
        %% get the foot off events and their names (X_Foot_Off), sort it in time order
        events_fields = fieldnames(events_struct);
        
        for evt_index = 1 : numel(events_fields)
            footOff = regexp(events_fields(evt_index),'Right_Foot_Off|Left_Foot_Off','once');
            if ~isempty(footOff{1,1})
                [event_s, event_names] = get_event(evt_index, events_struct,...
                    events_fields, event_s, event_names);
            end  % if
        end  % for
        list_FOs = sortrows([event_s, event_names],1);
        clear events_fields footOff event_s event_names
        
        %% get the general events and their description
        [evtValues,label,descript] = btkGetEventsValues(acq);
        events_infos = sortrows([num2cell(evtValues),label,descript], 1);
        general_index = 0;
        for evt_index = 1:size(events_infos,1)
            if strcmp(events_infos{evt_index,2},'Event') % it's a general events
                % infos from the description
                type_genEvt=regexp(events_infos{evt_index,3},{'left|right|Toe Off';'FP\d|4th'},'match');
                switch char(type_genEvt{1,1})
                    case 'Toe Off'
                        TO_4thStep = events_infos{evt_index,1}; % is a number, not a cell
                    case {'left','right'}
                        general_index = general_index + 1;
                        event_general{general_index,1} = events_infos{evt_index,1};
                        event_general{general_index,2} = type_genEvt{1,1};
                        event_general{general_index,3} = type_genEvt{2,1};
                    otherwise
%                         out = 0;
                        disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                        disp('!!! the description of general events is incomplete !!!');
                end
            end
        end
        clear general_index evt_index type_genEvt evtValues label descript events_infos
        if ~out
            return
        end
        
        %% extract the events of each gait cycle
        for gaitCycle = 1:length(event_general(:,1))
            GC_side = event_general{gaitCycle,2}{1,1};
            GC_forceplate = event_general{gaitCycle,3}{1,1};
            time_FSref = event_general{gaitCycle,1};
            % find the events from the events struct of btk
            out_FOipsi = 1;
            out_FOcontra = 1;
            out_FScontra = 1;
            switch GC_side
                case 'left'
                    footStrikes = events_struct.Left_Foot_Strike;
                    if isfield(events_struct,'Left_Foot_Off')
                        footOffsIpsi = events_struct.Left_Foot_Off;
                    else
                        out_FOipsi = 0;
                    end
                    if isfield(events_struct,'Right_Foot_Off')
                        footOffsContra = events_struct.Right_Foot_Off;
                    else
                        out_FOcontra = 0;
                    end
                    if isfield(events_struct,'Right_Foot_Strike')
                        footStrikesContra = events_struct.Right_Foot_Strike;
                    else
                        out_FScontra = 0;
                    end
                case 'right'
                    footStrikes = events_struct.Right_Foot_Strike;
                    if isfield(events_struct,'Right_Foot_Off')
                        footOffsIpsi = events_struct.Right_Foot_Off;
                    else
                        out_FOipsi = 0;
                    end
                    if isfield(events_struct,'Left_Foot_Off')
                        footOffsContra = events_struct.Left_Foot_Off;
                    else
                        out_FOcontra = 0;
                    end
                    if isfield(events_struct,'Left_Foot_Strike')
                        footStrikesContra = events_struct.Left_Foot_Strike;
                    else
                        out_FScontra = 0;
                    end
            end % switch GC_side
                    
            %%% FS ipsi
            [out_FS,message_FS,GC_FSipsi] = find_FSfromGenEvent(footStrikes,time_FSref);
            if ~out_FS % there is a problem
                disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                disp(['!!! for the ' GC_side ' gait cycle on ' GC_forceplate...
                    'there is ' message_FS '. Please have a look !!!']);
                out = 0;
            else % the 2 FS were found
                %%% FO ipsi
                if out_FOipsi
                    [out_FOipsi,GC_FOipsi] = find_eventBetween(footOffsIpsi,GC_FSipsi(1),GC_FSipsi(2));
                end
                if ~out_FOipsi % there is a problem
                    disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                    disp(['!!! the ' GC_side ' gait cycle on ' GC_forceplate...
                        ' hasn''t any foot off. Please have a look !!!']);
                    out = 0;
                end
                %%% FO contra
                % has to be between FSipsi(1)&FSipsi(2)
                % so running will also be taken into account
                if out_FOcontra
                    [out_FOcontra,GC_FOcontra] = find_eventBetween(footOffsContra,GC_FSipsi(1),GC_FSipsi(2));
                end
                if ~out_FOcontra % there is a problem
                    disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                    disp(['!!! the ' GC_side ' gait cycle on ' GC_forceplate...
                        ' hasn''t any contralateral foot off. Please have a look !!!']);
                    out = 0;
                end
                %%% FS contra
                % has to be between FSipsi(1)&FSipsi(2)
                % so running will also be taken into account
                if out_FScontra
                    [out_FScontra,GC_FScontra] = find_eventBetween(footStrikesContra,GC_FSipsi(1),GC_FSipsi(2));
                end
                if ~out_FScontra % there is a problem
                    disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                    disp(['!!! the ' GC_side ' gait cycle on ' GC_forceplate...
                        ' hasn''t any contralateral foot strike. Please have a look !!!']);
                    out = 0;
                end
            end % if ~out_FS
            if out
                gaitCycles_infos{gaitCycle,1} = GC_side;
                gaitCycles_infos{gaitCycle,2} = GC_forceplate;
                events.FS_ipsi = GC_FSipsi;
                events.FO_ipsi = GC_FOipsi;
                events.FO_contra = GC_FOcontra;
                events.FS_contra = GC_FScontra;
                gaitCycles_infos{gaitCycle,3} = events;
            end
        end % for gaitCycle = 1:length(event_general(:,1))
        
        %% look for the step number (from 4th step)
        if TO_4thStep % the value is different from initialisation to 0
            list_FO_values = cell2mat(list_FOs(:,1));
            [out_4thStep,ind_4thStep] = find_index(list_FO_values,TO_4thStep);
            if out_4thStep
                %%% give a step number to each foot off
                list_FOs{ind_4thStep,3} = 4;
                % steps after the 4th
                step = 4;
                for i = ind_4thStep+1:length(list_FO_values)
                    side_i = list_FOs{i,2}(1:4);
                    side_before = list_FOs{i-1,2}(1:4);
                    if ~strcmp(side_i,side_before)
                        step = step + 1;
                    else
                        step = step + 2;
                    end
                    list_FOs{i,3} = step;
                end
                % steps before the 4th
                if ind_4thStep > 1
                    i = ind_4thStep - 1;
                    step = 4;
                    while i >=1
                        side_i = list_FOs{i,2}(1:4);
                        side_after = list_FOs{i+1,2}(1:4);
                        if ~strcmp(side_i,side_after)
                            step = step - 1;
                        else
                            step = step - 2;
                        end
                        list_FOs{i,3} = step;
                        i = i - 1;
                    end
                end
                %%% make a connection between the foot offs and the gait cycles
                for gaitCycle = 1:size(gaitCycles_infos,1)
                    [~,ind_gc] = find_index(list_FO_values,...
                        gaitCycles_infos{gaitCycle,3}.FO_ipsi);
                    gaitCycles_infos{gaitCycle,4} = list_FOs{ind_gc,3};
                end
            else
                disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                disp(['!!! the given general event for the 4th step doesn''t '...
                    'correspond to any foot off event !!!']);
                out = 0;
            end % if out_4thStep
        else
            for gaitCycle = 1:size(gaitCycles_infos,1)
                gaitCycles_infos{gaitCycle,4} = 0;
            end
        end % if TO_4thStep
        %% look for the step number (first defined step = 1. step)
        list_FO_values = cell2mat(list_FOs(:,1));
        % the second FO is the one of the 1st step
        step = 1;
        list_FOs{2,3} = step;
        for i=3:length(list_FO_values)
            side_i = list_FOs{i,2}(1:4);
            side_before = list_FOs{i-1,2}(1:4);
            if ~strcmp(side_i,side_before)
                step = step + 1;
            else
                step = step + 2;
            end
            list_FOs{i,3} = step;
        end
        %%% make a connection between the foot offs and the gait cycles
        for gaitCycle = 1:size(gaitCycles_infos,1)
            [~,ind_gc] = find_index(list_FO_values,...
                gaitCycles_infos{gaitCycle,3}.FO_ipsi);
            gaitCycles_infos{gaitCycle,5} = list_FOs{ind_gc,3};
        end
    else
        disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
        disp('!!! There is''nt any events in the c3d. !!!');
        out = 0;
    end % if  ~isempty(struct2cell(events_struct))
end


function [out,message,events_FS] = find_FSfromGenEvent(listEvents,time_FSref)
% search the two values of foot strikes that define the given gait cycle
% 
% INPUT
%     listEvents = list of the plausible events
%     time_FSref = the value given from a general event that define the first
%     foot strike of the gait cycle
% 
% OUTPUT
%     out = 1 if all ok, 0 if there is a problem (typically no event found
%     that correspond to the given time, or there isn't any second foot
%     strike
%     message = text corresponding to the error that occured
%     events_FS = an array of two values: the first and the second foot
%     strikes of the gait cycle

    out = 1;
    message = '';
    
    index = 1;
    while index <= length(listEvents)
        if time_FSref == listEvents(index)
            if index ~= length(listEvents)
                events_FS = listEvents(index:index+1);
            else
                out = 0;
                message = 'no 2nd foot strike found';
                events_FS = [0,0];
            end
            break
        else
            index = index + 1;
        end
    end
    if index > length(listEvents)
        out = 0;
        message = 'no foot strike found';
        events_FS = [0,0];
    end
end

function [out,event] = find_eventBetween(listEvents,min,max)
% search the first event from a list which is between two values
% 
% INPUT
%     listEvents = list of the plausible events
%     min = lower boundary for the event
%     max = upper boundary for the event
% 
% OUTPUT
%     out = 1 if all ok, 0 if there is a problem (typically no event found
%     in the given interval
%     event = the found value
    out = 1;
    
    index = 1;
    while index <= length(listEvents)
        if (listEvents(index)>min) && (listEvents(index)<max)
            event = listEvents(index);
            break
        else
            index = index + 1;
        end
    end
    if index > length(listEvents)
        out = 0;
        event = 0;
        disp(' ');
    end
end


function [event_s, event_names] = get_event(evt_index, events_struct, events_fields, event_s, event_names)
% get the events from the field 'events_field' out of the struct
% 'events_list' and convert the values into a cell format 'events'
% event_names is a struct with corresponding types of the events:
% X_Foot_Strike or X_Foot_Off

    events_s = events_struct.(events_fields{evt_index});

    if numel(events_s) > 1
        event_names = [event_names; repmat(events_fields(evt_index), 1, numel(events_s))'];
        event_s = [event_s; num2cell(events_s)'];
    else
        event_names = [event_names; events_fields(evt_index)];
        event_s = [event_s; num2cell(events_s)];
    end  % if
end  % function

function [out,index] = find_index(list_values,value)
% find the index of the given value in the list_values
% if no corresponding value found -> index = 0 and out = 1
    out = 1;
    index = 1;
    while index <= length(list_values)
        if value == list_values(index)
            break
        else
            index = index + 1;
        end
    end
    if index > length(list_values)
        out = 0;
        index = 0;
    end
end

