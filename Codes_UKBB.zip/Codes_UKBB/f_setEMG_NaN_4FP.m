%{
********************************************************************************* 
     Function "f_EMG_NaN_4FP" linked to script "Auswertung_mitFormularen"
                       used in "f_load_c3d"
                    adapted from "f_Kinetic_NaN" from K. Schweizer, by
                    Marie Freslier Aug. 2016
*********************************************************************************

Sets Vectors to NaN if the kinetic was not good, according to "good left/good right..."

INPUT: Fieldname = Names of the fields that should be filled into the struct
       data = Struct as derived by c3d that has missing fields (e.g. no upper body angles)

OUTPUT: data = Input struct supplemented by the fields defined by "Fieldname"
               --> Matrices are NaN

%}

function data_KinematicCorr = f_setEMG_NaN_4FP(data,Kinetic)

    namefield1 = fieldnames(data); %all fieldnames
    
    namefield_right = namefield1;
    namefield_left = namefield1;
    
    Left_side = strncmp('EMG_L',namefield1,5);
    Right_side = strncmp('EMG_R',namefield1,5);
    
    
    namefield_right(Left_side,:) = []; %keep fieldnames of the right side only
    namefield_left(Right_side,:) = []; %keep fieldnames of the left side only
    
    Kinematic_NaN = NaN(size(data.(namefield1{1,1})));
    
    data_KinematicCorr = data;

    switch Kinetic
        case 'left'
            for i = 1:size(namefield_right,1)
                data_KinematicCorr.(namefield_right{i,1}) = Kinematic_NaN;
            end %FOR i = 1:size(namefield_right,1)
        case 'right'
            for i = 1:size(namefield_left,1)
                data_KinematicCorr.(namefield_left{i,1}) = Kinematic_NaN;
            end %FOR i = 1:size(namefield_left,1)
        case 'none'
            data_KinematicCorr = data;
    end

end %FUNCTION