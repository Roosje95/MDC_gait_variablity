function [out,trials_infos,TibiaTorsion_static] = f_copyFiles(Path_data,patName,Path_new,...
                                          patName_new,trials_infos,data)
%{
by M. Freslier, Mar. 2017
                                          
copy all the needed files in the temporary folder:
- .vsk & .mp: files from Nexus with model parameters and markers
- .c3d: measurement files from Nexus (static and dynamic), emg channels are
corrected with muscle name, clinical data (RoM, Strength testing...) are
written in the c3d
- calculate tibia torsion from static trial

INPUT
    Path_data = path where the original data are saved
    patName = name of the original data
    Path_new = path where the data are to be copied
    patName_new = name of the new data
    trials_infos = struct of the information of the trials, fields are
        filename, Processed (='static','vid_running','vid_orthosis' or
        'dynamic'), kinetic, newName
    data = Struct with all clinical measurements & measurement 
        information form, NameParameter.Value (value is in string)

OUTPUT
    out = 1 if all ok, 0 if there is a problem to copy some file (main 
    script will be stopped)
    trials_infos = the same struct as input, with newName field updated
    TibiaTorsion_static = Tibia torsion in room coordinates system and in
                          tibia coordinates system calculated from ankle markern and KAD
                                          
List of functions:
    - f_renameEMG_c3d
    - f_write_StaticInfo
    - f_clinic2_c3d
    - f_extractMarkerDiameter
    - f_Marker2_c3d
%}
out =1 ;
%%% vsk&mp files %%%
[status,message] = copyfile([Path_data,'\',patName,'.vsk'],...
    [Path_new,'\',patName_new,'.vsk']);
out = out*status;
if status
    disp('--- vsk file copied ---');
else
    disp(' ');
    disp('!!! error in f_copyFiles: !!!');
    disp(['!!! vsk file couldn''t be copied: ' message ' !!!']);
end

[status,message] = copyfile([Path_data,'\',patName,'.mp'],...
    [Path_new,'\',patName_new,'.mp']);
out = out*status;
if status
    disp('--- mp file copied ---');
else
    disp(' ');
    disp('!!! error in f_copyFiles: !!!');
    disp(['!!! mp file couldn''t be copied: ' message ' !!!']);
end

[NewNameEMG,~] = f_whichEMG(data);

[out_MkDiam,MarkerDiameter4_c3d] = f_extractMarkerDiameter([Path_new,'\',patName_new,'.vsk']);
out = out*out_MkDiam;
if ~out
    disp('!!! in f_copyFiles !!!');
    return
end

%%% c3d files %%%
for trialNumber = 1:length(trials_infos)
    switch trials_infos(trialNumber).Processed
        case 'static'
            trials_infos(trialNumber).newName = ...
                [trials_infos(trialNumber).newName,'_',patName_new];
            [status,message] = copyfile([Path_data,'\',...
                trials_infos(trialNumber).filename,'.c3d'],...
                [Path_new,'\',trials_infos(trialNumber).newName,'.c3d']);
            out = out*status;
            if status
                disp(['--- ',trials_infos(trialNumber).filename,'.c3d',' file copied ---']);
                warning off all
                acq = btkReadAcquisition([Path_new,'\',trials_infos(trialNumber).newName,'.c3d']);
                warning on all; warning('off','MATLAB:interp1:NaNinY')
                
                % Calculates Tibia torsion    
                TibiaTorsion_static = f_calc_TibTorsionStatic(acq,data);
                
                % Rename EMG channels in c3d with "f_renameEMG_c3d"
                acq = f_renameEMG_c3d(NewNameEMG,acq);
                % Writes information on whether the wooden foot plate was used for the static
                acq = f_write_StaticInfo(acq,data);
                
                btkWriteAcquisition(acq,[Path_new,'\',trials_infos(trialNumber).newName,'.c3d']);
                btkDeleteAcquisition(acq);
            else
                disp(' ');
                disp('!!! error in f_copyFiles: !!!');
                disp(['!!! ',trials_infos(trialNumber).filename,'.c3d',...
                    ' file couldn''t be copied: ' message ' !!!']);
            end
        case 'dynamic'
            trials_infos(trialNumber).newName = ...
                [trials_infos(trialNumber).newName,'_',patName_new];
            [status,message] = copyfile([Path_data,'\',...
                trials_infos(trialNumber).filename,'.c3d'],...
                [Path_new,'\',trials_infos(trialNumber).newName,'.c3d']);
            out = out*status;
            if status
                disp(['--- ',trials_infos(trialNumber).filename,'.c3d',' file copied ---']);
                warning off all
                acq = btkReadAcquisition([Path_new,'\',trials_infos(trialNumber).newName,'.c3d']);
                warning on all; warning('off','MATLAB:interp1:NaNinY')
                
                % Rename EMG channels in c3d with "f_renameEMG_c3d"
                acq = f_renameEMG_c3d(NewNameEMG,acq);
                % Write clinical data (RoM, Strength testing...) to c3d
                acq = f_clinic2_c3d(data,acq);
                % Write marker diameter to c3d
                acq = f_Marker2_c3d(MarkerDiameter4_c3d,acq);
                
                btkWriteAcquisition(acq,[Path_new,'\',trials_infos(trialNumber).newName,'.c3d']);
                btkDeleteAcquisition(acq);
            else
                disp(' ');
                disp('!!! error in f_copyFiles: !!!');
                disp(['!!! ',trials_infos(trialNumber).filename,'.c3d',...
                    ' file couldn''t be copied: ' message ' !!!']);
            end
        otherwise
            continue
    end

end
