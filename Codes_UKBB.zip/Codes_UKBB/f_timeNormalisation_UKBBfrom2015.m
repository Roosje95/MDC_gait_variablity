%{ 
*********************************************************************************
Function "f_timeNormalisation" & "f_Normalise" linked to script "Auswertung_mitFormularen"
                by Katrin Schweizer Jan. 2014
               revised Katrin Bracht Dez. 2017
*********************************************************************************

f_timeNormalisation

Go to last field in Struct (e.g. Struct.PIGunnormalised.Angle.Sagittal.Hip.Left)
choose the matching event (in this example from the left side) and apply 
f_Normalise to normalise the data

Filter EMG-data 20-700 butterworth 4th order for all EMG data, for time normalised
data take the envelop also.

INPUT: Struct = {Model}.{Measure}.{Plane}.{Joint}.{Side} (e.g PIGunnormalised.Angles.Sagittal.Knee.Left)
       EV1 = first event in seconds
       EV2 = second event in seconds

OUTPUT: Struct = similar as input supplemented by fields "PIGnormalised_51" and
                 "PIGnormalised_100", comprised of the same struct as "PIGunnormalised"
                 but data are time normalised to 51 or 100 values and all EMG data
                 are filtered and rectified

_________________________________________________________________________________
f_Normalise

Normalises the data inbetween two events (e.g. on 51 or 100 data points 
--> 0-100% gait cycle).
Produces exactly the same results as found in excel-marco!!!

INPUT: data = the data to normalise (vector) already cut to the sequence to normalise
       EV1 = first event in frames = 1
       EV2 = second event in frames
       points = number of points to normalise to -1 (e.g. 99 if one wishes
                to normalise to 100 data points)
       freq = measurement frequency
       firstFrame = the first frame of the measurement (normally = 1, if cut
                    it can defer)

OUTPUT: normData = time-normalised data in a vector
%}

function [Struct] = f_timeNormalisation_UKBBfrom2015(Struct,EV1,EV2,EMG_recorded)
   Fieldnames2 = fieldnames(Struct.PIGunnormalised);
          
   points51 = 50;
   points100 = 99;
   freq = Struct.PIGunnormalised.Frequency.Vicon.Hertz.Dummy;
   firstFrame = Struct.PIGunnormalised.FirstFrame.Vicon.Dummy.Dummy;
   freqAnalog = Struct.PIGunnormalised.Frequency.Analog.Hertz.Dummy;
   firstFrameAnalog = Struct.PIGunnormalised.FirstFrame.Analog.Dummy.Dummy;   
   
   for j = 1:size(Fieldnames2,1) %6
       if strcmp(Fieldnames2{j,:},'Angle') || ...
           strcmp(Fieldnames2{j,:},'Moment') || ...
           strcmp(Fieldnames2{j,:},'Power') || ...
           strcmp(Fieldnames2{j,:},'Force') || ...
           strcmp(Fieldnames2{j,:},'Marker') || ...
           strcmp(Fieldnames2{j,:},'EMG')
       
           Fieldnames3 = fieldnames(Struct.PIGunnormalised.(Fieldnames2{j,:}));

           for jj = 1:size(Fieldnames3,1)
               Fieldnames4 = fieldnames(Struct.PIGunnormalised.(Fieldnames2{j,:}).(Fieldnames3{jj,:}));

               for jjj = 1:size(Fieldnames4,1)
                   Fieldnames5 = fieldnames(Struct.PIGunnormalised.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}));

                   for jjjj = 1:size(Fieldnames5,1)
                       DataStruct = Struct.PIGunnormalised.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:});

                        if ~strcmp(Fieldnames2{j,:},'EMG') %if its not EMG
                           [normData51] = f_Normalise(DataStruct,EV1,EV2,points51,freq,firstFrame);
                           [normData100] = f_Normalise(DataStruct,EV1,EV2,points100,freq,firstFrame);

                            Struct.PIGnormalised_51.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}) = normData51;
                            Struct.PIGnormalised_100.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}) = normData100;                     

                        else %if its the EMG, filter and envelop EMG 
                            if EMG_recorded ==1
                                % Filter EMG data with 4th order butterworth 20-700 Hz
                                [filteredDataUnnorm] = f_filterEMG(DataStruct,freqAnalog,20,700);
                                [filteredData51] = f_filterEMG(DataStruct,freqAnalog,20,700);
                                [filteredData100] = f_filterEMG(DataStruct,freqAnalog,20,700);
                                
                                % Caluclate envelop EMG
                                [envelopedData51] = f_envelopEMG(filteredData51,EV1,EV2,points51,freqAnalog,firstFrameAnalog);
                                [envelopedData100] = f_envelopEMG(filteredData100,EV1,EV2,points100,freqAnalog,firstFrameAnalog);
                                
                                % Transver EMG vom Volt to milliVolt
                                Struct.PIGunnormalised.(Fieldnames2{j,:}).('mVolt').(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}) = filteredDataUnnorm.*1000;
                                Struct.PIGnormalised_51.(Fieldnames2{j,:}).('mVolt').(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}) = envelopedData51.*1000;
                                Struct.PIGnormalised_100.(Fieldnames2{j,:}).('mVolt').(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}) = envelopedData100.*1000;
                            end%IF EMG recorded normalize EMG oderwise skip
                        end %IF ~strcmp(Fieldnames2{j,:},'EMG') %if its not EMG

                   end %FOR jjjj = 1:size(Fieldnames5,1)

               end %FOR jjj = 1:size(Fieldnames4,1)

           end %FOR jj = 1:size(Fieldnames3,1)
       end % if strcmp(Fieldnames2{j,:},'Angle') || ...
    end %FOR Fieldnames2 = fieldnames(Struct.PIGunnormalised);
end


%****************************************************************************
%% Function "f_Normalise
%****************************************************************************

function [normData] = f_Normalise(data,EV1,EV2,points,freq,firstFrame)

   %% Transfer events from seconds to frames 
    % As the first frame is subtracted, it doesn't matter if the trials were cut
    % beforehand or not
   EV1 = round(EV1 * freq - firstFrame + 2);
   EV2 = round(EV2 * freq - firstFrame + 2);
  
   EV_1 = 1; %first event is in first row
   EV_2 = EV2-EV1+1;
   dataNormalise = data(EV1:EV2,:); %cut data --> keep data between the events
      
   
   %% normalise  
   
   inc = (EV_2 - EV_1) / points; % increment to get data points-1
   
   x = 1:EV_2; 
   xi = 1:inc:EV_2;
   
   normData = interp1(x,dataNormalise,xi)';   

end % FUNCTION
