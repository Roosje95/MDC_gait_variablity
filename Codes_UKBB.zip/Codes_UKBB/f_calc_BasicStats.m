%{
********************************************************************************* 
     Function "f_calc_BasicStats" linked to script "Auswertung_mitFormularen"
                    by Katrin Schweizer Jan. 2014
*********************************************************************************

Calculates the mean, standard deviation, and 95% confidence intervall 
across all trials of a patient.

INPUT: data = Struct with all trials of a subject in the columns of the endfields
 
OUTPUT: Mean,StandDev,ConfInterv = Structs with the same fields as the input
                                   struct (data) with means/standard deviation/
                                   95% confidence intervall across all trials
                                   of a patient

%}

function [Mean,StandDev,ConfInterv] = f_calc_BasicStats(data)

   Fieldnames2 = fieldnames(data);
   
   % Loops across all fieldnames in the struct to reach the endfield
   
   for j = 1:size(Fieldnames2,1)
       Fieldnames3 = fieldnames(data.(Fieldnames2{j,:}));
              
       for jj = 1:size(Fieldnames3,1) 
           Fieldnames4 = fieldnames(data.(Fieldnames2{j,:}).(Fieldnames3{jj,:}));
                  
           for jjj = 1:size(Fieldnames4,1)
               Fieldnames5 = fieldnames(data.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}));
                      
               for jjjj = 1:size(Fieldnames5,1)
                   Fieldnames6 = fieldnames(data.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}));                  
                                   
                   for jjjjj = 1:size(Fieldnames6,1)                          
                       data_endfield = data.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:});
                       N = sum(~isnan(data_endfield(1,:)));
                       
                       % Calculate mean across all trials of a subject
                       Mean.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:})= nanmean(data_endfield,2);
                       
                       % Calculate standard deviation across all trials of a subject
                       StandDev.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:})= nanstd(data_endfield,0,2);
                       
                       % Calculate 95% confidence interval across all trials of a subject
                       ConfInterv.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:})= nanstd(data_endfield,0,2)./sqrt(N).*1.96; %SD/Sqrt(N)*1.96                     
                       
                   end %FOR jjjjj = = 1:size(Fieldnames6,1)                      
              
               end %FOR jjjj = 1:size(Fieldnames5,1)
                      
           end %FOR jjj = 1:size(Fieldnames4,1)
                  
       end %FOR jj = 1:size(Fieldnames3,1)
              
    end %FOR Fieldnames2 = fieldnames(data);
    
end %FUNCTION