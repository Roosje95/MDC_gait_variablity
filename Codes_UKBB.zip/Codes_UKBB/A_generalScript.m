%{ 
 Script for the analysis of older data: it works analysed data
            M. Freslier - August 2018
 before you start, add the folder NCM_CP>Codes (& subfolders) to path
 read carefully the comments and adapt the script to your needs...

Adaptations:
August 2018 - Rosa Visscher - Adapted for ETH use 
    added setting changed Path_measurements, so in future only settinigs have to be adapted 
    added if-loop to select if kinetic data should be analyzed or not
    !!added ETH Codes, check is still needed!!
%}
    clear
    clc
    dbstop if error
    
%% Settings
Patient = {'v4598j'};       % select the patient trail you want to analyse
Kinetics = 1;               % select if kinetic data was collected (1) or not (0) - e.g. K, B, L, R in filename
Copy_mat = 1;               % 1 if you want to copy mat file with clinical info into analysed folder, 0 if not
%% ---> define here where are stored the data
%Path_measurements = 'C:\Vicon_Data_local\Nexus\Patient Classification
%2\Klinik'; % @UKBB location
Path_measurements = {'P:\Projects\NCM\NCM_CP\Data\UKBB_Gait_till2015\Archiv'}; % @ETHZ location
Path_measurements = split(Path_measurements,'\');
Path_measurements(8) = Patient;
Path_measurements = strjoin(Path_measurements,'\');
%% ---> define here where you want to copy the data
Path_temp = 'P:\Projects\NCM\NCM_CP\Data\Analysed_UKBB_Gait_from2015'; % @ETHZ location
Path_save = 'P:\Projects\NCM\NCM_CP\Data\Analysed_UKBB_Gait_from2015'; % @ETHZ location
Path_save = split(Path_save,'\');
Path_save(7) = Patient;
Path_save = strjoin(Path_save,'\');
    %% select the measurement folder
    Path_Patientfolder = uigetdir(Path_measurements);
    % extract name of patient folder
    pathDetailed = strsplit(Path_Patientfolder,'\');
    PatientFolder = pathDetailed{size(pathDetailed,2)};
    % create measurement folder in the new work folder (defined with
    % Path_temp)
    Path_Patientfolder_new = [Path_temp,'\',PatientFolder];
    if isempty(dir(Path_Patientfolder_new))
        mkdir(Path_Patientfolder_new) %make a folder
    else %if the patient folder already exists
        delete([Path_Patientfolder_new,'\*.*'])
    end

   % clear pathDetailed Path_temp Path_measurements
  %  addpath \\green-lmb.ethz.ch\green_groups_lmb_public\Projects\NCM\NCM_CP\Codes
% %% ---> if you want to copy the videos
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'avi');
% 
% %% ---> if you want to copy the pdf's
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'pdf');
% 
% %% ---> if you want to copy the vsk and mp files
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'vsk');
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'mp');
% 
% %% ---> if you want to copy the xls's
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'xlsx');
% % % may try with 'xls' instead of 'xlsx' for older measurements:
% % f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'xls');
% 
% %% ---> if you want to copy the mat file
% %       (matlab structure with protocoll and assessment informations)
if Copy_mat == 1
f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'mat');
end
% 
% %% ---> if you only want the representativ trial
% f_copyRepFile(Path_Patientfolder,Path_Patientfolder_new,'xlsx')
% % % may try with 'xls' instead of 'xlsx' for older measurements
% % f_copyRepFile(Path_Patientfolder,Path_Patientfolder_new,'xls');
% 
% f_copyRepFile(Path_Patientfolder,Path_Patientfolder_new,'c3d')

%% ---> copy of the c3d's files
%{
  You could copy all the c3d's files without any modifications.
  But if you want to further use the gait cycles with good kinetics or if
  you want only analysed trials (N..,K..,B..,L..,R..,static), you may have
  to run the second script (it will add some general event(s) to specify
  which gait cycles have good kinetics, especially for measurement made
  between 05.2014 and 08.2016)
%}

% % (1) ---> copy of all c3d's files
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'c3d');
% [outCheck,c3d_infos] = f_checkTrialType(Path_Patientfolder_new);

% (2) ---> copy of static and analysed (N..,K..,B..,L..,R..) c3d's files
% RepTrials won't be interpreted as analysed trial: you may have to rename
% it with one of the above letters in first place of the filename.

[outCheck,c3d_infos] = f_copyCheck_c3dFiles(Path_Patientfolder,Path_Patientfolder_new);

    %% stop the script if no c3d trials found
    if ~outCheck
        disp(' ')
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        % stop the script execution
        return
    else
        clear outCheck
    end
    
%% ---> obtain a list of the gait cycles
% if you want to delete some trials from the 'c3d_infos' list, you could
% delete per hand the corresponding row(s) in the Matlab workspace or write
% your own script for it
if Kinetics == 0
    % % (1) ---> if you are only interested in the kinematik or EMG (gait cycles with good
    % % kinetics are not important), run the following script
    out_collect = 1;
    disp(' ');
    for files = 1:length(c3d_infos)
        switch c3d_infos(files).Processed
            case {'KineticsUndefined','Kinetics','NoKinetics','Unknown'}
                c3d_acq = btkReadAcquisition([Path_Patientfolder_new '\' c3d_infos(files).filename]);
                disp(['--- ' c3d_infos(files).filename ': extract gait cycles ---']);
                [out_collect_GC,c3d_infos(files).gaitcycles] = ...
                    f_collect_gaitCycles_NoKinetics(c3d_acq);
                btkDeleteAcquisition(c3d_acq);
                out_collect = out_collect * out_collect_GC;
            otherwise
                continue
        end
    end
else
    % (2) ---> if you are only interested in the gait cycles with good kinetics, run the
    % following script
    % it is assumed that the data have kinetics...
    out_collect = 1;
    disp(' ');
    for files = 1:length(c3d_infos)
        switch c3d_infos(files).Processed
            case 'Kinetics'
                c3d_acq = btkReadAcquisition([Path_Patientfolder_new '\' c3d_infos(files).filename]);
                disp(['--- ' c3d_infos(files).filename ': extract gait cycles ---']);
                [out_collect_GC,c3d_infos(files).gaitcycles] = ...
                    f_collect_gaitCycles_Kinetics(c3d_acq);
                btkDeleteAcquisition(c3d_acq);
                out_collect = out_collect * out_collect_GC;
            otherwise
                continue
        end
    end
end
    %% stop the script if no c3d trials found
    if ~out_collect
        disp(' ')
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        % stop the script execution
        return
    else
        clear out_collect files c3d_acq out_collect_GC
    end

%% extract all the data for each c3d selected (from c3d_infos)
%% list of all the gait cycles
% information from EMG has to be determined: it is possible from param.mat
% or it has to be given from another source for older data
    % needs more adaptations: if no .mat...
    Params4_c3d = importdata([Path_Patientfolder '\' PatientFolder '_parameters.mat']);
    if ~isempty(Params4_c3d.EMG_Setup)
        EMG_recorded = 'y';
    else
        EMG_recorded = 'n';
    end
    %out_list = 1; %RV seems to be unused, check if it works like this
    [out_list,allGaitCycles] = f_GaitGycles_List(c3d_infos,EMG_recorded);
    %% stop the script if there is a problem to determine the informations
    if ~out_list
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else
        clear out_list
    end
    
%% makes structs with kinematics, kinetics, EMG, temporal-Distance parameters
    [out_label,StructAllGC,StructAllC3D,DataForCalc,Trials,TrialNamePlot] = ...
            f_loadC3d_buildStructs(Path_Patientfolder_new,allGaitCycles,EMG_recorded);
    %% stop the script if there is a problem with the marker labelling
    if ~out_label
            disp(' ');
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
            return
    else
        clear out_label
    end
    
%      %% get ETH parameters
%      % info - needed for furtehr calculations gait variability, does all
%      % patients at once
%      % Open_Gait_allfiles_Leon_Rosa(current_file,study,subject{1},StructAllC3D)
% addpath \\green-lmb.ethz.ch\green_groups_lmb_public\Projects\NCM\NCM_CP\Data\all_mat_LeonCode\
% master = '\\green-lmb.ethz.ch\green_groups_lmb_public\Projects\NCM\NCM_CP\Data\all_mat_LeonCode\';
% study = 'CP';
% DIR = dir(master);
% DIR_files = {DIR.name};
% 
% addpath \\green-lmb.ethz.ch\green_groups_lmb_public\Projects\NCM\NCM_CP\Code\1_Get_gait_parameters\Rosa_testing\ % add gait analysis files directory
% %choose which of the following you command based on which already exists
% %load Variability_Data_M05Y2018
% Variability_Data_M05Y2018 = struct;
% % find, calculate & store
% for n = 3:length(DIR_files)
%     subject = DIR_files(n);
%     current_file = strcat(master,'\',subject{1});
%     if isfield(Variability_Data_M05Y2018,[subject{1}]) % use to skip trials are already done
%         continue
%     end
%     [GaitSummary, normVD, VideoData, status]= Open_Gait_allfiles_Leon_Rosa(current_file,study,subject{1},StructAllC3D);
%     if status == 3
%         continue
%     end
%     
%     % find mean, std, covariance
%     clear total;
%     total.Freq = [];
%     total.FVA = [];
%     trials = fieldnames(GaitSummary);
%     for m = 1:length(trials)
%         % 34 parameters
%         analysis = fieldnames(eval(['GaitSummary.',trials{m}]));
%         for j = 1:length(analysis)
%             attempts = fieldnames(eval(['GaitSummary.',trials{m},'.',analysis{j}]));
%             
%             % extract and concatenate
%             for k = 1:length(attempts)
%                 params = fieldnames(eval(['GaitSummary.',trials{m},'.',analysis{j},'.',attempts{k},'.GaitParameters']));
%                 for p = 1:length(params)
%                     current_p = eval(['GaitSummary.',trials{m},'.',analysis{j},'.',attempts{k},'.GaitParameters.',params{p}]);
%                     current_p(isnan(current_p)) = [];
%                     if isempty(current_p)
%                         continue
%                     end
%                     clear comd;
%                     if ~isfield(eval(['total.',analysis{j}]),params{p})
%                         comd = ['total.',analysis{j},'.',params{p}, '= current_p;'];
%                         eval(comd);
%                     else
%                         comd = ['total.',analysis{j},'.',params{p},'= cat(2,total.',analysis{j},'.',params{p},',current_p);'];
%                         eval(comd);
%                     end
%                 end
%             end
%             % calculate mean, std
%             for p = 1:length(params)
%                 if isfield(eval(['total.',analysis{j}]),params{p})
%                     comd = ['Subject_data.',analysis{j},'.mean.', params{p}, ' = mean(total.',analysis{j},'.',params{p},');'];
%                     eval(comd);
%                     comd = ['Subject_data.',analysis{j},'.std.', params{p}, ' = std(total.',analysis{j},'.',params{p},');'];
%                     eval(comd);
%                     % calculate coefficient of variation
%                     comd = ['Subject_data.',analysis{j},'.CoV.', params{p}, ' = Subject_data.',analysis{j},'.std.', params{p} ...
%                         '/Subject_data.',analysis{j},'.mean.', params{p},';'];
%                     eval(comd);
%                 else
%                     comd = ['Subject_data.',analysis{j},'.mean.', params{p}, ' = [];'];
%                     eval(comd);
%                     comd = ['Subject_data.',analysis{j},'.std.', params{p}, ' = [];'];
%                     eval(comd);
%                     % calculate coefficient of variation
%                     comd = ['Subject_data.',analysis{j},'.CoV.', params{p}, ' = [];'];
%                     eval(comd)
%                 end
%             end
%         end
%         comd = ['Variability_Data_M05Y2018.',subject{1},'.',trials{m}, ' = Subject_data;'];
%         eval (comd);
%         clear Subject_data
%         save Variability_Data_M05Y2018 Variability_Data_M05Y2018
%     end
% end
%     trails = StructAllC3D;
%     trails = struct2cell(trails);
%     samplingRate = trails{1,1}.PIGunnormalised.Frequency.Vicon.Hertz.Dummy;
%     vis = 0; % visualization
%     
% %     for  files = 1:length(c3d_infos)
% %         switch c3d_infos(files).Processed
% %             case {'KineticsUndefined','Kinetics','NoKinetics','Unknown'}
% %                 
% %                 % Variable names needed for ETH Functions - !!!Needs to be tested and checked!!!
% %                 interpolatedVD.LANK.Values.x_coord = trails{1,files}.PIGunnormalised.Marker.AP.ANK.Left;
% %                 interpolatedVD.LANK.Values.y_coord = trails{1,files}.PIGunnormalised.Marker.Lateral.ANK.Left;
% %                 interpolatedVD.RANK.Values.x_coord = trails{1,files}.PIGunnormalised.Marker.AP.ANK.Right;
% %                 interpolatedVD.RANK.Values.y_coord = trails{1,files}.PIGunnormalised.Marker.Lateral.ANK.Right;
% %                 interpolatedVD.LHEE.Values.x_coord = trails{1,files}.PIGunnormalised.Marker.AP.HEE.Left;
% %                 interpolatedVD.LHEE.Values.y_coord = trails{1,files}.PIGunnormalised.Marker.Lateral.HEE.Left;
% %                 interpolatedVD.RHEE.Values.x_coord = trails{1,files}.PIGunnormalised.Marker.AP.HEE.Right;
% %                 interpolatedVD.RHEE.Values.y_coord = trails{1,files}.PIGunnormalised.Marker.Lateral.HEE.Right;
% %                 x_LTHL = interpolatedVD.LHEE.Values.x_coord;% Heel marker HEE, but named according to ETH markerset THL
% %                 y_LTHL = interpolatedVD.LHEE.Values.y_coord;
% %                 x_RTHL = interpolatedVD.RHEE.Values.x_coord;
% %                 y_RTHL = interpolatedVD.RHEE.Values.y_coord;
% %                 Toemarker_L = trails{1,files}.PIGunnormalised.Marker.AP.TOE.Left;
% %                 Toemarker_R = trails{1,files}.PIGunnormalised.Marker.AP.TOE.Right;
% %                 
% %                 % Gait events - needed for further calculations
% %                 if c3d_infos(1).gaitcycles{1,1}=='right'
% %                     HSleft = c3d_infos(files).gaitcycles{2,3}.FS_ipsi;
% %                     HSright = c3d_infos(files).gaitcycles{1,3}.FS_ipsi;
% %                     TOleft = c3d_infos(files).gaitcycles{2,3}.FO_ipsi;
% %                     TOright = c3d_infos(files).gaitcycles{1,3}.FO_ipsi;
% %                 elseif c3d_infos(1).gaitcycles{2,1}=='right'
% %                     HSleft = c3d_infos(files).gaitcycles{1,3}.FS_ipsi;
% %                     HSright = c3d_infos(files).gaitcycles{2,3}.FS_ipsi;
% %                     TOleft = c3d_infos(files).gaitcycles{1,3}.FO_ipsi;
% %                     TOright = c3d_infos(files).gaitcycles{2,3}.FO_ipsi;
% %                 end
% %                 
% %                 HSleftlocs = HSleft*samplingRate;
% %                 HSrightlocs = HSright*samplingRate;
% %                 TOleftlocs = TOleft*samplingRate;
% %                 TOrightlocs = TOright*samplingRate;
% %                 
% %                 GaitEvents.HSleft=HSleft;
% %                 GaitEvents.HSleftlocs=HSleftlocs;
% %                 GaitEvents.HSright=HSright;
% %                 GaitEvents.HSrightlocs=HSrightlocs;
% %                 GaitEvents.TOleft=TOleft;
% %                 GaitEvents.TOleftlocs=TOleftlocs;
% %                 GaitEvents.TOright=TOright;
% %                 GaitEvents.TOrightlocs=TOrightlocs;
% %                 
% %                 % Minimum toe clearance
% %                 
% %                 [MTCleft, MTCleftlocs]=get_mtc(TOleftlocs,HSleftlocs,Toemarker_L);
% %                 [MTCright, MTCrightlocs]=get_mtc(TOrightlocs,HSrightlocs,Toemarker_R);
% %                 
% %                 GaitParameters.MTCleftlocs=MTCleftlocs;
% %                 GaitParameters.MTCrightlocs=MTCrightlocs;
% %                 GaitParameters.MTCleft=MTCleft;
% %                 GaitParameters.MTCright=MTCright;
% %                 
% %                 % Kinematic mid-stance and mid-swing events
% %                 nHSleft = length(HSleft);
% %                 nTOleft = length(TOleft);
% %                 nHSright = length(HSright);
% %                 nTOright = length(TOright);
% %                 
% %                 [LmidStlocs, RmidStlocs] = findmidstance2(...
% %                     interpolatedVD.LANK.Values.x_coord, interpolatedVD.LANK.Values.y_coord,...
% %                     interpolatedVD.RANK.Values.x_coord, interpolatedVD.RANK.Values.y_coord,...
% %                     HSleftlocs, HSrightlocs, TOleftlocs, TOrightlocs, ...
% %                     samplingRate,vis);
% %                 
% %                 LmidSwlocs = RmidStlocs;
% %                 RmidSwlocs = LmidStlocs;
% %                 
% %                 GaitParameters.nHSleft=nHSleft;
% %                 GaitParameters.nHSright=nHSright;
% %                 GaitParameters.nTOleft=nTOleft;
% %                 GaitParameters.nTOright=nTOright;
% %                 GaitParameters.LmidStlocs=LmidStlocs;
% %                 GaitParameters.RmidStlocs=RmidStlocs;
% %                 GaitParameters.LmidSwlocs=LmidSwlocs;
% %                 GaitParameters.RmidSwlocs=RmidSwlocs;
% %                 
% %                 [midStOccTimeL, midStOccTimeR, midSwOccTimeL, midSwOccTimeR]= midtimes(...
% %                     LmidStlocs, RmidStlocs, HSleftlocs, HSrightlocs, TOleftlocs, TOrightlocs,...
% %                     LmidSwlocs, RmidSwlocs);
% %                 
% %                 GaitParameters.midStOccTimeL=midStOccTimeL;
% %                 GaitParameters.midStOccTimeR=midStOccTimeR;
% %                 GaitParameters.midSwOccTimeL=midSwOccTimeL;
% %                 GaitParameters.midSwOccTimeR=midSwOccTimeR;
% %                 
% %                 % Duration of gait cycle events(s)
% %                 % duration Gait cycle, duration Stance Phase, duration Swing Phase, duration of double limb support
% %                 
% %                 [durationGaitCycleL, durationGaitCycleR, durationStancePhL, ...
% %                     durationStancePhR, durationSwingPhL, durationSwingPhR, ...
% %                     dlsL, dlsR, ndlsL, ndlsR] = durationPhase(HSleft, HSright, ...
% %                     TOleft, TOright, HSleftlocs,HSrightlocs, TOleftlocs, TOrightlocs,...
% %                     samplingRate);
% %                 
% %                 % structure
% %                 GaitParameters.durationGaitCycleL=durationGaitCycleL;
% %                 GaitParameters.durationGaitCycleR=durationGaitCycleR;
% %                 GaitParameters.durationStancePhL=durationStancePhL;
% %                 GaitParameters.durationStancePhR=durationStancePhR;
% %                 GaitParameters.durationSwingPhL=durationSwingPhL;
% %                 GaitParameters.durationSwingPhR=durationSwingPhR;
% %                 GaitParameters.dlsL=dlsL;
% %                 GaitParameters.dlsR=dlsR;
% %                 GaitParameters.ndlsL=ndlsL;
% %                 GaitParameters.ndlsR=ndlsR;
% %                 
% %                 
% %                 % spatio-temporal parameters
% %                 % stride length, step length, step time, cadence, step width
% %                 [strideLengthL, strideLengthR, stepLengthL, stepLengthR, hs_matrix, ...
% %                     stepTimeL, stepTimeR, cadence] = ...
% %                     strLength(x_LTHL,y_LTHL, x_RTHL, y_RTHL,...
% %                     HSleft,HSright,...
% %                     HSleftlocs,HSrightlocs,...
% %                     samplingRate);
% %                 
% %                 [stepWidthL, stepWidthR] = ...
% %                     stepwidth(interpolatedVD.LHEE.Values.x_coord, ...
% %                     interpolatedVD.LHEE.Values.y_coord, interpolatedVD.RHEE.Values.x_coord, ...
% %                     interpolatedVD.RHEE.Values.y_coord, hs_matrix_new);
% %                 
% %                 GaitParameters.stepWidthL = stepWidthL;
% %                 GaitParameters.stepWidthR = stepWidthR;
% %                 GaitParameters.strideLengthL=strideLengthL;
% %                 GaitParameters.strideLengthR=strideLengthR;
% %                 GaitParameters.stepLengthL=stepLengthL;
% %                 GaitParameters.stepLengthR=stepLengthR;
% %                 GaitParameters.stepTimeL=stepTimeL;
% %                 GaitParameters.stepTimeR=stepTimeR;
% %                 GaitParameters.cadence=cadence;
% %                 
% %                 % gaitassymmetry
% %                 [GA_shortvslong, GA_leftvsright] = gaitasymmetry(durationSwingPhL, durationSwingPhR);
% %                 
% %                 GaitParameters.GaitAsymmetry_ShortvsLong = GA_shortvslong;
% %                 GaitParameters.GaitAsymmetry_LeftvsRight = GA_leftvsright;
% %                 
% %                 % phasecoordindex
% %                 [PCI_shortvslong, PCI_leftvsright] = phasecoordindex(durationSwingPhL, durationSwingPhR, ...
% %                     durationGaitCycleL, durationGaitCycleR, durationStancePhL, durationStancePhR);
% %                 
% %                 GaitParameters.PhaseCoordinationIndex_ShortvsLong = PCI_shortvslong;
% %                 GaitParameters.PhaseCoordinationIndex_LeftvsRight = PCI_leftvsright;
% %                 
% %                 GaitParameters = orderfields(GaitParameters);
% %                 
% %                 % Calculating dimensionless velocity
% %                 [walkingSpeed, dimlessSpeed] = dimensionlessVelocity(interpolatedVD, ...
% %                     HSleftlocs, HSrightlocs, VD.SF);
% %                 
% %                 GaitParameters.walkingSpeed = walkingSpeed;
% %                 GaitParameters.dimensionlessSpeed = dimlessSpeed;
% %                 
% %                 % foot angles
% %                 [GaitParameters.HSanglesLeft,FFleftlocs]= FootAngle(interpolatedVD.LHEE.Values,interpolatedVD.LTOE.Values.z_coord,HSleftlocs,samplingRate);
% %                 [GaitParameters.HSanglesRight,FFrightlocs]= FootAngle(interpolatedVD.RHEE.Values,interpolatedVD.LTOE.Values.z_coord,HSrightlocs,samplingRate);
% %                 
% %                 
% %                 %% meanSD calculation --> NOT WORKING JET
% %                 % can be used on any sort of continuous data, see article
% %                 % Dingwell et al. 2001 (Artcile_meanSD in NCM_CP folder)
% %                 
% %                 % markSD=std(markdata(:,1:i), [], 2);
% %                 % mSDl=mean(mean(markSDl,2));
% %                 
% %                 GaitEvents = orderfields(GaitEvents);
% %                 GaitParameters = orderfields(GaitParameters);
% %                 
% %             otherwise
% %                 continue
% %         end
% %     end


 

    %% save struct all kinematics, kinetics, EMG, temporal-Distance parameters
    PIGoutcomesNormalized = fullfile(Path_save, 'PIGoutcomesNormalized.mat');
    PIGoutcomesNonnormalized = fullfile(Path_save, 'PIGoutcomesNonnormalized.mat');
    save(PIGoutcomesNormalized, 'StructAllGC')
    save(PIGoutcomesNonnormalized, 'StructAllC3D')