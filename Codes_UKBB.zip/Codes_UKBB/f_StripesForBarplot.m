%{
*********************************************************************************
Function "f_StripesForBarplot" linked to script "Auswertung_mitFormularen"
       runs from function "f_Report_TemporalParameters"
                by Katrin Schweizer Feb. 2014
*********************************************************************************

Does the strips filling for the blue bars
 
            
INPUT: x1 = X-Axis left corner of the bar
       x2 = X-Axis right corner of the bar
       barEndpoint = y-axis value (mean of patient data)

OUTPUT: White strips on blue bars
%}

function f_StripesForBarplot(x1,x2,barEndpoint)

  %% bars extent to negative values 
   if barEndpoint < 0 
 
        y1 = -4; y2 = 0;

        m = 34.782608695652240;%(y2-y1) / (x2-x1);

        HalfWidth = (x2-x1)/2;

        IntersectBarEndpoint = (barEndpoint-y1)/m;

        xx1 = x1-abs(IntersectBarEndpoint);
        xx2 = x1+HalfWidth;

        tt = 1;
        yy2 = y1;
        Y1 = 0;
        
        if abs(barEndpoint)>4 %if bars are highter than 4%

            while yy2 > barEndpoint 

                  if Y1+y1 > barEndpoint %if length of beam is exceeded (bottom)
                     Y1 = Y1+y1;
                  else Y1 = barEndpoint;
                  end

                  if xx1 < x1; %if width of beam is exceeded to the left
                     X1 = x1;
                  else X1 = xx1;
                  end

                  if xx2 <= x2 %if length of beam is exceeded (top)
                     Y2 = y2;
                  else Y2 = yy2;
                       yy2 = yy2+y1;
                  end

                  if xx2 >= x2; %if width of beam is exceeded to the right
                     X2 = x2;          
                  else X2 = xx2;
                  end

                  line([X1 X2],[Y1 Y2],'Color','w')

                  xx1 = xx1+HalfWidth;
                  xx2 = xx2+HalfWidth;

                  tt = tt+1;
            end %WHILE yy2 > barEndpoint
            
        else %if bars are smaller than -4%
             xx1 = x1+abs(IntersectBarEndpoint);
             xx2 = x1+HalfWidth;
             
             line([xx1 xx2],[barEndpoint 0],'Color','w')
             line([xx1+HalfWidth x2],[barEndpoint 0],'Color','w')
        end %IF abs(barEndpoint)>4
        
        
   %% if bars extend to positive values     
   else 
        y1 = barEndpoint-4; y2 = barEndpoint;%y1 = 0; y2 = 4;

        m = 34.782608695652240;%(y2-y1) / (x2-x1);

        HalfWidth = (x2-x1)/2;

        IntersectBarEndpoint = (barEndpoint-4)/m;%(barEndpoint-y1)/m;

        xx1 = x1-abs(IntersectBarEndpoint);
        xx2 = x1+HalfWidth;

        tt = 1;
        yy2 = y2;
        Y1 = y2;
        
        if abs(barEndpoint)>4 %if bars are highter than 4%

            while yy2-4 > 0 

                  if Y1-4 < 0 %if length of beam is exceeded (bottom)
                     Y1 = 0;
                  else Y1 = Y1-4;
                  end

                  if xx1 < x1; %if width of beam is exceeded to the left
                     X1 = x1;
                  else X1 = xx1;
                  end

                  if xx2 <= x2 %if length of beam is exceeded (top)
                     Y2 = y2;
                  else 
                       yy2 = yy2-4;
                       Y2 = yy2;
                  end

                  if xx2 >= x2; %if width of beam is exceeded to the right
                     X2 = x2;          
                  else X2 = xx2;
                  end

                  line([X1 X2],[Y1 Y2],'Color','w')

                  xx1 = xx1+HalfWidth;
                  xx2 = xx2+HalfWidth;

                  tt = tt+1;
            end %WHILE yy2 > barEndpoint
            
        else %if bars are smaller than 4%
             xx1 = x1+abs(IntersectBarEndpoint);
             xx2 = x1+HalfWidth;
             
             line([xx1 xx2],[0 barEndpoint],'Color','w')
             line([xx1+HalfWidth x2],[0 barEndpoint],'Color','w')
        end %IF abs(barEndpoint)>4  
        
   end %IF barEndpoint < 0

end %FUNCTION    
