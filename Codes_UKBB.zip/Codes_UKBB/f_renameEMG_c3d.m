%{
*********************************************************************************
            Function "f_renameEMG_c3d" linked to 
(...) script "Auswertung_mitFormularen" & "Datenarchivierung_footmodel"
                       (...) runs from "f_load_c3d" & "f_Foot_load_c3d"
                     by Katrin Schweizer Sept 2014
adapted by Marie Freslier on July 2017
*********************************************************************************

Replace the old EMG name in Analogs read by btk with ('EMG_SideMusclename')
in c3d.
                                     
INPUT
  NewNameEMG = three-column cell 1. column is the original name in the c3d "Analog -> Descriptions" e.g. 'EMG1',
                                 2. column is the channel as numbered by matlab e.g. 'v1'
                                 3. column is the side and muscle name e.g. 'RGastrocMed'
  acq = handle to c3d (from btkReadAcquisition)

OUTPUT
  acq = handle to c3d with renamed EMG
%}

function acq = f_renameEMG_c3d(NewNameEMG,acq)

%     warning off all
%     acq = btkReadAcquisition(Path_c3d);
%     warning on all; warning('off','MATLAB:interp1:NaNinY')
    MetaData = btkGetMetaData(acq); % all subject measurements
    
     % Shows the descriptions of the analog data and includes the old names for EMG (e.g. 'Noraxon EMG 1.0.2.1::EMG1 [6,1]')
     Index_EMG = MetaData.children.ANALOG.children.DESCRIPTIONS.info.values;

     % loop over all proper muscle names (new names) 
     for i = 1:size(NewNameEMG,1) 
         
         %loop ober all old names (Descriptions) of Analog
         for j = 1:size(Index_EMG,1)         
            
             % if the EMG number (e.g. 'EMG1 ') is found in a row of the analog descriptions
             if ~isempty(strfind(Index_EMG{j,1},[NewNameEMG{i,1} ' ']))

                Index = j; %Row for current EMG channel in Analogs
              
            %% Replaces the old EMG name (e.g. 'Noraxon EMG 1.0.2.1::EMG1 [6,1]' by muscle name (e.g. 'RGastrocMed')
                btkSetAnalogLabel(acq,Index,['EMG_',NewNameEMG{i,3}]);

             end %IF ~isempty(strfind(Index_EMG{i,1},'EMG1 '))
             
         end %FOR j = 1:size(Index_EMG,1)
         
     end %FOR i = 1:size(NewNameEMG,1)

     
    %% Write the new Analog label into acquision
%     btkWriteAcquisition(acq,Path_c3d);
    
%     btkDeleteAcquisition(acq);
    
end %FUNCTION