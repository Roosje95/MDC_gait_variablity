%{ 
*********************************************************************************
              Function "f_calc_coordinateTibia" linked to 
             script "Auswertung" run from "f_write_StaticInfo"
                     by Katrin Bracht Dec. 2015
*********************************************************************************

Calculates the coordinate system of the tibia. 
1) z-vector = z-axis: a vector is span from the AJC to KJC. 
2) x-vector: a vector is span between the AJC and MAL. The x-axis  is 
             calculated perpendicular to the plane between the
             AJC-MAL vector and the AJC-KJC vector.
3) y-vector: the perpendicular vector to the x and z vectors.

INPUT
   AJC = ankle joint center (mean between two malleolie markers)
   KJC = knee joint center as calculated from Knee Alignment Device
   MAL = lateral malleolus marker
   sign = is 1 (positive) for left foot, -1 (negative) for the right side

OUTPUT
   Tib_nVec_X = x-vector of tibia segment, vector in anterior-posterior
                direction
   Tib_nVec_Y = y-vector of tibia segment, vector in lateral direction
   Tib_nVec_Z = z-vector of tibia segment, vector spanns from AJC to KJC
%}

function [Tib_nVec_X,Tib_nVec_Y,Tib_nVec_Z] = f_calc_coordinateTibia(AJC,KJC,MAL,sign); %,TIA,TIO,TIP,TIL);

%% calculate vectors
%1)
vec_AnkKnee = KJC-AJC; %vector tibia (vertical) = z
vec_AnkMal = (MAL-AJC)*sign; %positive for left

%2)
nVec_AP = cross(vec_AnkMal,vec_AnkKnee,2); %calculate perpendicular vector 
        % to plane between the AJC-MAL vector and the AJC-KJC vector.
        % = vector anterior posterior = x
%3)
nVec_ML = cross(vec_AnkKnee,nVec_AP,2); %calculate perpendicular vector 
        % to plane between the AJC-KJC vector and the x-vector = vector medio-lateral = y


%% norm vectors

% norm of vector
for i = 1:size(AJC,1)
    norm_nVec_AP(i,:) = norm(nVec_AP(i,:));
    norm_nVec_ML(i,:) = norm(nVec_ML(i,:));
    norm_nVec_AnkKnee(i,:) = norm(vec_AnkKnee(i,:));
end 

% norm vectors
Tib_nVec_X = nVec_AP./repmat(norm_nVec_AP,1,3);
Tib_nVec_Y = nVec_ML./repmat(norm_nVec_ML,1,3);
Tib_nVec_Z = vec_AnkKnee./repmat(norm_nVec_AnkKnee,1,3);


%% test
% PIG_X = TIA - TIO;
% PIG_Y = TIL - TIO;
% PIG_Z = TIP - TIO;
% 
% for i = 1:size(AJC,1)
%     norm_PIG_X(i,:) = norm(PIG_X(i,:));
%     norm_PIG_Y(i,:) = norm(PIG_Y(i,:));
%     norm_PIG_Z(i,:) = norm(PIG_Z(i,:));
% end 
% 
% normPIG_X = PIG_X./repmat(norm_PIG_X,1,3);
% normPIG_Y = PIG_Y./repmat(norm_PIG_Y,1,3);
% normPIG_Z = PIG_Z./repmat(norm_PIG_Z,1,3);


