%{ 
*********************************************************************************
Function "f_envelopEMG" linked to script "Auswertung_mitFormularen"
                runs from "f_timeNormalisiation"
                by Katrin Schweizer July 2014
*********************************************************************************

Inverts and envelops the EMG.
After that, the enveloped data are time normalised

INPUT: data = the filtered EMG-data (butterworth 4th order 20-700Hz) as a vector
       EV1 = first event in frames
       EV2 = second event in frames
       points = number of points to normalise to -1 (e.g. 99 if one wishes
                to normalise to 100 data points)
       freq = measurement frequency analog
       firstFrame = the first frame of the measurement analog (normally = 1, if cut
                    it can defer)

OUTPUT: envelopedEMG = Enveloped EMG time-normalised to a gait cycle
%}

function [envelopedEMG] = f_envelopEMG(data,EV1,EV2,points,freq,firstFrame)  %

                                
   %% Transfer events from seconds to frames 
    % As the first frame is subtracted, it doesn't matter if the trials were cut
    % beforehand or not
   EV1 = round(EV1 * freq - firstFrame + 2);
   EV2 = round(EV2 * freq - firstFrame + 2);
  
   EV_1 = 1; %first event is in first row
   EV_2 = EV2-EV1+1;

   
  %% invert EMG
  
   data_inver = abs(data); 

   
  %% Take envelope (smooth the data with the function filtfilt.m (take an envelop)
  
   b = ones(1,100)/100;
   data_env = filtfilt(b,1,data_inver);

   
  %% cut data to gait cycle
  
   dataEnvelopeNormalise = data_env(EV1:EV2,:);
   
   
  %% time normalisation of enveloped EMG  
   
   inc = (EV_2 - EV_1) / points; % increment to get data points-1
   
   x = 1:EV_2; 
   xi = 1:inc:EV_2;
   
   envelopedEMG = interp1(x,dataEnvelopeNormalise,xi)';   
   
      
end %FUNCTION