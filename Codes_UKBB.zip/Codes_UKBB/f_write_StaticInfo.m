%{
*********************************************************************************
               Function "f_write_StaticInfo" linked to 
                script "Auswertung_ChiBa15b"      
                  by Katrin Bracht Sept. 15
                adapted by Marie F. July 17 (without TibTorsion)
*********************************************************************************

Writes information on whether the wooden foot plate was used for the static 
trial to the c3d file.
                                     
INPUT
  Params4_c3d = Struct with all clinical measurements & measurement information form,
                NameParameter.Value (value is in string)
  acq = handle to c3d (from btkReadAcquisition)

OUTPUT
  acq = handle to c3d with renamed EMG
%}


function acq = f_write_StaticInfo(acq,Params4_c3d)

%     warning off all
%         acq = btkReadAcquisition(Path_c3d);
%     warning on all; warning('off','MATLAB:interp1:NaNinY')
    
    btkAppendMetaData(acq, 'PROCESSING', 'Static_T', ...
    btkMetaDataInfo('Char',{Params4_c3d.Static_T}));

    btkAppendMetaData(acq, 'PROCESSING', 'Assume_Horizontal', ...
    btkMetaDataInfo('Char',{Params4_c3d.Assume_Horizontal}));

    btkAppendMetaData(acq, 'PROCESSING', 'Gender', ...
    btkMetaDataInfo('Char',{Params4_c3d.Gender}));

    btkAppendMetaData(acq, 'PROCESSING', 'Age', ...
    btkMetaDataInfo('Char',{Params4_c3d.Age}));

%     btkWriteAcquisition(acq,Path_c3d);
    
    
%     %******************************************************************
%     %% Calculate tibia torsion from static trial 
%     %******************************************************************
%     
%     Markers = btkGetMarkers(acq); % all marker, joint centres and centre of mass
% 
%     %% Calculation in coordinate system of Tibia
% 
%     [AJC_le,KJC_le] = f_calc_jointCentres(Markers.LKNE,Markers.LKAX,...
%                                    Markers.LKD1,Markers.LKD2,...
%                                    Markers.LANK,Markers.LANKM,1,...
%                                    Params4_c3d.LKneeWidth,Markers.LFEO);
%     [AJC_ri,KJC_ri] = f_calc_jointCentres(Markers.RKNE,Markers.RKAX,...
%                                    Markers.RKD1,Markers.RKD2,...
%                                    Markers.RANK,Markers.RANKM,-1,...
%                                    Params4_c3d.RKneeWidth,Markers.RFEO);
% 
% 
%     %% Find Coorinate system for tibia
% 
%     [Tib_X_le,Tib_Y_le,Tib_Z_le] = f_calc_coordinateTibia(AJC_le,KJC_le,Markers.LANK,1);
% 
%     [Tib_X_ri,Tib_Y_ri,Tib_Z_ri] = f_calc_coordinateTibia(AJC_ri,KJC_ri,Markers.RANK,-1);
%     
% 
%     %% Transform Marker to tibia coordinate system
% 
%     [Trans_KneeMed_le,Trans_KneeLat_le,Trans_AnkleMed_le,Trans_AnkleLat_le] ...
%                = f_trans_MarkerToTibCoord(KJC_le,Markers.LKAX,Markers.LANKM,...
%                                           Markers.LANK,Tib_X_le,Tib_Y_le,Tib_Z_le);
% 
%     [Trans_KneeMed_ri,Trans_KneeLat_ri,Trans_AnkleMed_ri,Trans_AnkleLat_ri] ...
%                = f_trans_MarkerToTibCoord(KJC_ri,Markers.RKAX,Markers.RANKM,...
%                                           Markers.RANK,Tib_X_ri,Tib_Y_ri,Tib_Z_ri);
% 
% 
%     %% Tibia torsion calculation
% 
%     % 2D in coordinate system of room
%     [TibiaTorsion_2D_le] = f_calc_TibiaTorsion(KJC_le(:,1:2),Markers.LKAX(:,1:2),Markers.LANKM(:,1:2),...
%                                                Markers.LANK(:,1:2),-1);
%     Med_TibiaTorsion_2D_le = median(TibiaTorsion_2D_le);                                 
%     Min_TibiaTorsion_2D_le = min(TibiaTorsion_2D_le); 
%     Max_TibiaTorsion_2D_le = max(TibiaTorsion_2D_le); 
% 
%     [TibiaTorsion_2D_ri] = f_calc_TibiaTorsion(KJC_ri(:,1:2),Markers.RKAX(:,1:2),Markers.RANKM(:,1:2),...
%                                                Markers.RANK(:,1:2),1);
%     Med_TibiaTorsion_2D_ri = median(TibiaTorsion_2D_ri);                                 
%     Min_TibiaTorsion_2D_ri = min(TibiaTorsion_2D_ri); 
%     Max_TibiaTorsion_2D_ri = max(TibiaTorsion_2D_ri); 
% 
%     disp(' '); disp('------------------------------------------------'); disp('Tibia torsion from static trial (2D), external = positiv'); disp(' ')
%     disp(['left: ',num2str(Med_TibiaTorsion_2D_le),' (',num2str(Min_TibiaTorsion_2D_le),...
%          ', ',num2str(Max_TibiaTorsion_2D_le),'),  right: ',num2str(Med_TibiaTorsion_2D_ri),...
%          ' (Min: ',num2str(Min_TibiaTorsion_2D_ri),', Max: ',num2str(Max_TibiaTorsion_2D_ri),')'])
% 
% 
%     % 3D in coordinate system of tibia
% 
%     [TibiaTorsion_TIB_le] = f_calc_TibiaTorsion(Trans_KneeMed_le(:,1:2),Trans_KneeLat_le(:,1:2),Trans_AnkleMed_le(:,1:2),...
%                                                 Trans_AnkleLat_le(:,1:2),-1);
%     Med_TibiaTorsion_TIB_le = median(TibiaTorsion_TIB_le);                                 
%     Min_TibiaTorsion_TIB_le = min(TibiaTorsion_TIB_le); 
%     Max_TibiaTorsion_TIB_le = max(TibiaTorsion_TIB_le); 
% 
%     [TibiaTorsion_TIB_ri] = f_calc_TibiaTorsion(Trans_KneeMed_ri(:,1:2),Trans_KneeLat_ri(:,1:2),Trans_AnkleMed_ri(:,1:2),...
%                                                 Trans_AnkleLat_ri(:,1:2),1);
%     Med_TibiaTorsion_TIB_ri = median(TibiaTorsion_TIB_ri);                                 
%     Min_TibiaTorsion_TIB_ri = min(TibiaTorsion_TIB_ri); 
%     Max_TibiaTorsion_TIB_ri = max(TibiaTorsion_TIB_ri);
% 
%     disp(' '); disp('------------------------------------------------'); disp('Tibia torsion from static trial (TIB), external = positiv'); disp(' ')
%     disp(['left: ',num2str(Med_TibiaTorsion_TIB_le),' (',num2str(Min_TibiaTorsion_TIB_le),...
%          ', ',num2str(Max_TibiaTorsion_TIB_le),'),  right: ',num2str(Med_TibiaTorsion_TIB_ri),...
%          ' (Min: ',num2str(Min_TibiaTorsion_TIB_ri),', Max: ',num2str(Max_TibiaTorsion_TIB_ri),')'])
% 
%     
%     TibiaTorsion_static.roomCoordinate.left = Med_TibiaTorsion_2D_le;
%     TibiaTorsion_static.roomCoordinate.right = Med_TibiaTorsion_2D_ri;
%     TibiaTorsion_static.tibiaCoordinate.left = Med_TibiaTorsion_2D_le;
%     TibiaTorsion_static.tibiaCoordinate.right = Med_TibiaTorsion_2D_ri;
% %     TibiaTorsion_static.roomCoordinate.left = 0;
% %     TibiaTorsion_static.roomCoordinate.right = 0;
% %     TibiaTorsion_static.tibiaCoordinate.left = 0;
% %     TibiaTorsion_static.tibiaCoordinate.right = 0;
    
    %%
    
%     btkDeleteAcquisition(acq); % closes c3d-file (acq), otherwise MATLAB runs out of memory

end %FUNKTION 