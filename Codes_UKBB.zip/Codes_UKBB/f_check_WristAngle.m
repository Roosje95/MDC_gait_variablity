%{ 
*********************************************************************************
    Function "f_check_WristAngle" linked to script "Auswertung_mitFormularen"
                    by Katrin Schweizer April 2013
*********************************************************************************

Checks if the absolute difference between the median wrist angle of all 
trials of a patient and a single trial is more than 50� --> error

INPUT: 
  data_PA = patient wrist angles of all relevant trials
  Path_c3d = Names of c3d matching to columns of "data_PA"

OUTPUT: Error warnings

%}

function out = f_check_WristAngle(data_PA,Path_c3d)

    out = 1;
  % mean angle over time
  Left_PA = nanmean(data_PA.Left,1);
  Right_PA = nanmean(data_PA.Right,1);
  
  Med_left = nanmedian(Left_PA,2);
  Med_right = nanmedian(Right_PA,2);
  
  for i = 1:size(Left_PA,2)
       
     % if the absolute difference between the median of all trials of a
     % patient and a single trial more than 50� --> error
      if abs(Med_left-Left_PA(1,i)) > 50  
          
         disp(' '); disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
         disp(['Error in wrist labelling left hand in trial:',Path_c3d{i,1}])
         disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
         disp(' '); disp('Do you want to continue?')
         disp(' '); disp('no, stop script       -------->  0')
         disp(' '); disp('yes, ignore           -------->  ENTER')
         disp(' '); Wrist_left = input('Selection: ','s');
         Wrist_left = lower(Wrist_left); disp(' ')

         switch Wrist_left
             case {'0'} %  
                ERROR
             case {'1'} % if we used the patella set-up, use Patella set-up             
         end %SWITCH Wrist_left
               
      end %IF abs(Med_left-Left_PA(i,1)) > 50  
      
      if abs(Med_right-Right_PA(1,i)) > 50 
          
         disp(' '); disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
         disp(['Error in wrist labelling right hand in trial:',Path_c3d{i,1}])
         disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
         disp(' '); disp('Do you want to continue?')
         disp(' '); disp('no, stop script       -------->  0')
         disp(' '); disp('yes, ignore           -------->  ENTER')
         disp(' '); Wrist_right = input('Selection: ','s');
         Wrist_right = lower(Wrist_right); disp(' ')

         switch Wrist_right
             case {'0'} %  
                 out = 0;
                % stop the script execution
                return
%                 ERROR
             case {'ENTER'}             
         end %SWITCH Wrist_right    
         
      end %IF abs(Med_right-Right_PA(i,1)) > 50  
  
  end %FOR i = 1:size(Mean_left,2)
  
    %%
    disp(' ');
    disp('++++++++++++++++++++')
    disp('Wrist angles checked --> no errors')
    disp(Path_c3d)
    disp('++++++++++++++++++++')

end %FUNKTION