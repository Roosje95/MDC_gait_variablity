%{ 
*********************************************************************************
Function "f_filterEMG" linked to script "Auswertung_mitFormularen"
                runs from "f_timeNormalisiation"
                by Katrin Schweizer July 2014
*********************************************************************************

Runs a butterworth 4th order high and lowpassfilter (20-500Hz)

INPUT: data = the EMG-data to normalise (vector)
       freq = Measurement frequency of analogue data
       Highpass = Number for highpass filter (HZ), e.g. 20 Hz
       Lowpass = Number for lowpass filter (HZ), e.g. 700 Hz

OUTPUT: filteredEMG = filtered EMG data
%}

function [filteredEMG] = f_filterEMG(data,freq,Highpass,Lowpass)

   
 %% filter EMG highpass of 20HZ and lowpass with 700Hz

   [b,a] = butter(2,Highpass/(freq/2),'high'); %Highpass filter
   y = filter(b,a,data);
   [b,a] = butter(2,Lowpass/(freq/2)); %low pass filter
   filteredEMG = filter(b,a,y);

      
end %FUNCTION