function [out,c3d_infos] = f_checkTrialType(path_trials)
%{
by M. Freslier, July. 2017

Function to define the type of the c3d files in a folder from the filename:
 - B... -> KineticsUndefined
 - L... -> KineticsUndefined
 - R... -> KineticsUndefined
 - K... -> Kinetics
 - N... -> NoKinetics
 - static... -> static
 - ... -> Unknown

INPUT
    path_trials = path where the data are stored

OUTPUT
    out = 1 if all ok, 0 if there is a problem ... 
    c3d_infos = struct with informations about the files
        .filename = the new filename of the copied c3d
        .Processed = the type of the file (i.e. static, NoKinetics or
        Kinetics)
%}
    out = 1;
    list_c3dFiles = dir([path_trials,'\*.c3d']);
    if isempty(list_c3dFiles)
        out = 0;
        disp(' ');
        disp('!!! error in f_copyCheck_c3dFiles: !!!');
        disp(['!!! There isn''t any c3d files in the given folder: ',path_trials,' !!!']);
    else
        index = 0;
        for files = 1:length(list_c3dFiles)
            switch list_c3dFiles(files).name(1)
                case {'B','L','R'}
                    index = index + 1;
                    c3d_infos(index).filename = list_c3dFiles(files).name;
                    c3d_infos(index).Processed = 'KineticsUndefined';
                case 'K'
                    index = index + 1;
                    c3d_infos(index).filename = list_c3dFiles(files).name;
                    c3d_infos(index).Processed = 'Kinetics';
                case 'N'
                    index = index + 1;
                    c3d_infos(index).filename = list_c3dFiles(files).name;
                    c3d_infos(index).Processed = 'NoKinetics';
                case 's'
                    index = index + 1;
                    c3d_infos(index).filename = list_c3dFiles(files).name;
                    c3d_infos(index).Processed = 'static';
                otherwise
                    index = index + 1;
                    c3d_infos(index).filename = list_c3dFiles(files).name;
                    c3d_infos(index).Processed = 'Unknown';
            end
        end
    end
end