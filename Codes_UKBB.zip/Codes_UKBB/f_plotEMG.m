%{ 
*********************************************************************************
     Function "f_plotEMG" linked to script "Auswertung_mitFormularen"
                      run from "f_Report_EMG"
                     by Katrin Schweizer March 2014
*********************************************************************************

Plots:
- the control group in grey rectangles
- the EMG of the six muscles of the left leg (RepTrial left)
- the same six muscles of the right leg (RepTrial right)
- the foot-off of the patients in horizontal line.
The plots are scared to 0-100% of a gait cycle on the x-achsis and 
to +/- 1% above/below the maximum/minimum of the data

INPUT
   PA_data = Vector with EMG data of one muscle
   CG_Muscle = X-Values when muscle is active
   titlePlot = title for sublot (e.g. 'Gastrocnemius med.')
   Yaxis = lable for y-achsis (e.g. {'[mVolt]'};)   
   Color_band = Color for rectangels of the control group (e.g. grey)
   FootOff = Frame of foot-off
   Color_Signal = Color for the EMG signal (e.g. red = left, blue = right)
%}

function f_plotEMG(PA_data,CG_Muscle,titlePlot,Yaxis,Color_band,FootOff,Color_Signal)

    % Transfer EMG-signal from Volt to milliVolt           
    PA_data = PA_data.*1000; 
     
    
   %% Define Y-axis limits
    Min = min(min(PA_data,[],1),[],2)*100; %*100 so that we can use floor/ceil later on
    Max = max(max(PA_data,[],1),[],2)*100;

    Percent = (Max-Min)*0.05;    
    MinPlot = floor(Min-Percent)/100; %/100 to reset *100 earlier on
    MaxPlot = ceil(Max+Percent)/100;
    
    %We want the Min and Max of the Y-axis to be the same, so that zero is centred
    if MinPlot > MaxPlot
       MaxPlot = MinPlot*-1;
    elseif MinPlot < MaxPlot
       MinPlot = MaxPlot*-1;
    end
    
    
    if sum(isnan(PA_data)) >= 1%if no data were measured
       MinPlot = -0.5;
       MaxPlot = 0.5;
    end %IF sum(~isnan(PA_data)) >= 1
    
    Y = MinPlot:0.01:MaxPlot;
    
%% Use if we want fix Min and Max for Y-axis    
%     MinPlot = -1;
%     MaxPlot = 1;    
%     Y = MinPlot:MaxPlot;

     
    %% Plot control group band %f_buildStructForPatch_EMG_CG"
    
    % Create struct as input for "patch"
    [struct_for_patch] = f_buildStructForPatch_EMG_CG(CG_Muscle,length(PA_data),Color_band,MinPlot,MaxPlot);
    
    % Plot the grey rectangles for the norm EMG
    patch(struct_for_patch,'LineStyle','none'); hold all

     
    %% plot patients first side (left, continous line)

    plot(PA_data,'Color',Color_Signal,'LineWidth',1); hold all; %plot EMG data
     
    % plot foot-off line   
    if Color_Signal == 'r'
        plot(repmat(FootOff,size(Y)),Y,'Color',Color_Signal,'LineWidth',1.5); %plot foot-off left side
    elseif Color_Signal == 'b'
        plot(repmat(FootOff,size(Y)),Y,'Color',Color_Signal,'LineWidth',1.5,'LineStyle','--'); %plot foot-off right side dashed
    end     
 
    
   %% Set general figure parameter
   
    XTICK = [1,length(PA_data)*0.2,length(PA_data)*0.4,length(PA_data)*0.6,length(PA_data)*0.8,length(PA_data)];
    XTICKLABEL = {'0','20','40','60','80','100'};
    
    set(gca,'XTickLabel',XTICKLABEL,'XTick',XTICK,'FontSize',9);
    xlabel('% Gait cycle','LineWidth',0.1,'FontSize',9);
    ylabel(Yaxis,'LineWidth',0.1,'FontSize',9);
    title(titlePlot,'FontWeight','demi','FontSize',11); 
    
    plot(zeros(size(PA_data,1),1)','Color','k','LineWidth',1); % plot zero line  

    % Set limits for X- & Y-axis
    xlim([1 size(PA_data,1)])
    ylim([MinPlot MaxPlot]) %y-limit is min-1% and max+1%
      
    % Draw box around each subplot
    box on
    set(gca, 'Layer','top') % draw box on top
    
end % FUNCTION

