%{ 
*********************************************************************************
              Function "f_calc_TibiaTorsion" linked to 
             script "Auswertung" run from "f_write_StaticInfo"
                     by Katrin Bracht Dec. 2015
*********************************************************************************

Calculates the tibia torsion in 2D:

INPUT
   KneeMed = knee joint centre
   KneeLat = KAX-Marker of Knee Alignment Device
   AnkleMed = medial malleolus marker
   AnkleLat = lateral malleolus marker
   sign_side = is 1 (positive) for left foot, -1 (negative) for the right side

OUTPUT
   TibiaTorsion = in 2D and in degrees
%}


function [TibiaTorsion] = f_calc_TibiaTorsion(KneeMed,KneeLat,AnkleMed,AnkleLat,sign_side)

%% 2D calculation

    VectKnee = KneeLat - KneeMed; %Vector between Knee Markers
    VectAnkle = AnkleLat - AnkleMed; %Vector between Ankle Markers

    for i = 1:size(AnkleLat,1)
        
        if VectAnkle(i,1)*VectKnee(i,2) - VectAnkle(i,2)*VectKnee(i,1) >= 0;
            Sign = 1;
        else Sign = -1;
        end

        TibiaTorsion(i,:) = round(acosd(dot(VectAnkle(i,:),VectKnee(i,:))/...
            (norm(VectAnkle(i,:))*norm(VectKnee(i,:))))) * Sign * sign_side;
    end
    
end %FUNCTION f_calc_TibiaTorsion
