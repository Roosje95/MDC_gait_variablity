function f_copyRepFile(path_origin,path_new,extension)
%{
by M. Freslier, July. 2017

Function to copy only the representativ file(s) with the given extension

INPUT
    path_Origin = path where the data are stored
    path_new = path where the data will be copied
    extension = extension of the file type (e.g. avi,pdf,vsk,mp...)

OUTPUT
    out = 1 if all ok, 0 if there is a problem ... (script
    will be stopped)
%}
list_files = dir([path_origin,'\Rep*.',extension]);
if isempty(list_files)
    disp(' ')
    disp(['!!! there isn''t any ',extension,' representativ file to copy from '...
        ,path_origin,'. !!!']);
else
    for file=1:length(list_files)
        copyfile([path_origin,'\',list_files(file).name],...
            [path_new,'\',list_files(file).name]);
        disp(['--- ',list_files(file).name,' file copied into ',...
            path_new,'. ---'])
    end
end