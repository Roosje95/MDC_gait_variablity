function [out,gaitCycles_infos] = f_collect_gaitCycles_NoKinetics(acq)
%{
by M. Freslier, Mar. 2017

collects the events for all gait cycles from a trial.
The trial has no kinetics: the gait cycles are determined from the events.

INPUT
    acq = handle to the trial (obtain from btkReadAcquisition)
OUTPUT
    gaitCycles_infos = a cell array with informations of the gait cycles:
        {x,1} = side
        {x,2} = 'FP0' (no kinetics)
        {x,3} = a struct with the events (FS ipsi&contra, FO ipsi&contra)
        {x,4} = step number (=0 if undetermined)
        {x,5} = step number, obtained from the 1st gait cycle defined in 
                the trial
    out = 1 if all ok, 0 if there is a problem to determine the
    informations
%}

    out = 1;
    gaitCycles_infos = {};
    
    %% remove subject name in event description and read events
    for t = 1 : btkGetEventNumber(acq)
        btkSetEventSubject(acq, t, '');
    end
    clear t
    events_struct = btkGetEvents(acq);

    
    % test if event is present
    if  ~isempty(struct2cell(events_struct))
        
        event_names = {};
        event_s = {};
        
        %% get the events and their names (Left/Right,Strike/Off), sort it in time order
        events_fields = fieldnames(events_struct);
        
        for evt_index = 1 : numel(events_fields)
            if ~strncmpi(events_fields(evt_index), 'General_Event', 13)
                [event_s, event_names] = get_event(evt_index, events_struct,...
                    events_fields, event_s, event_names);
            end  % if
        end  % for
        side = cell(size(event_names,1),1);
        type = cell(size(event_names,1),1);
        for evts = 1: size(event_names,1)
            type_evt = regexp(event_names{evts,1},{'Left|Right';'Strike|Off'},'match');
            side{evts,1} = type_evt{1,1};
            type{evts,1} = type_evt{2,1};
        end
            
        list_events = sortrows([event_s, side, type],1);
        
        %% get the foot Off events
        event_names = {};
        event_s = {};
        for evt_index = 1 : numel(events_fields)
            footOff = regexp(events_fields(evt_index),'Right_Foot_Off|Left_Foot_Off','once');
            if ~isempty(footOff{1,1})
                [event_s, event_names] = get_event(evt_index, events_struct,...
                    events_fields, event_s, event_names);
            end  % if
        end  % for
        list_FOs = sortrows([event_s, event_names],1);
        
        clear events_fields event_s event_names side type footOff
        
        %% get the general events and their description
        [evtValues,label,descript] = btkGetEventsValues(acq);
        events_infos = sortrows([num2cell(evtValues),label,descript], 1);
        TO_4thStep = 0;
        for evt_index = 1:size(events_infos,1)
            if strcmp(events_infos{evt_index,2},'Event') % it's a general events
                % infos from the description
                type_genEvt=regexp(events_infos{evt_index,3},'Toe Off','match');
                switch char(type_genEvt{1,1})
                    case 'Toe Off'
                        TO_4thStep = events_infos{evt_index,1}; % is a number, not a cell
                    otherwise
                        disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                        disp('!!! the description of general events is incomplete !!!');
                end
            end
        end
        clear general_index evt_index type_genEvt evtValues label descript events_infos
        if ~out
            return
        end
        
        %% search the gait cycles: a gait cycle is Ok only if all the events are present
        gaitCycle = 0;
        GC_length = 0;
        for evts = 1: size(list_events,1)-4
            % size(list_events,1)-4: a full gait cycle need 4 events after
            % the 1st FS (FO_ipsi, 2nd FS_ipsi, FO&FS_contra)
            out_GC = 1;
            if strcmp(list_events{evts,3},'Strike')
                GC_side = list_events{evts,2}{1,1};
                GC_FSipsi(1) = list_events{evts,1};
                % 2nd FS ipsi
                [out_FS2ipsi,GC_FSipsi(2),FS2_index] = ...
                    find_event(list_events(evts+1:size(list_events,1),:),GC_side,'Strike');
                FS2_index = FS2_index + evts;
                if out_FS2ipsi
                    % is this stride realistic?
                    % test is: not > the last stride length and half
                    stride_length = GC_FSipsi(2) - GC_FSipsi(1);
                    if GC_length == 0
                        GC_length = stride_length;
                    end
                    if stride_length < 1.5*GC_length
                        GC_length = stride_length;
                        % FOipsi
                        [out_FOipsi,GC_FOipsi,~] = ...
                            find_event(list_events(evts+1:FS2_index,:),GC_side,'Off');
                        if ~out_FOipsi % there is a problem
                            disp('!!! error in f_collect_gaitCycles_NoKinetics.m: !!!');
                            disp(['!!! the ' GC_side ' gait cycle from ' num2str(GC_FSipsi(1))...
                                's to ' num2str(GC_FSipsi(2)) 's hasn''t any ipsilateral foot off.' ...
                                ' Please have a look !!!']);
                            out_GC = 0;
                        end
                        % FOcontra
                        switch GC_side
                            case 'Left'
                                contra = 'Right';
                            case 'Right'
                                contra = 'Left';
                        end
                        [out_FOcontra,GC_FOcontra,~] = ...
                            find_event(list_events(evts+1:FS2_index,:),contra,'Off');
                        if ~out_FOcontra % there is a problem
                            disp('!!! error in f_collect_gaitCycles_NoKinetics.m: !!!');
                            disp(['!!! the ' GC_side ' gait cycle from ' num2str(GC_FSipsi(1))...
                                's to ' num2str(GC_FSipsi(2)) 's hasn''t any contralateral foot off.' ...
                                ' Please have a look !!!']);
                            out_GC = 0;
                        end
                        % FScontra
                        [out_FScontra,GC_FScontra,~] = ...
                            find_event(list_events(evts+1:FS2_index,:),contra,'Strike');
                        if ~out_FScontra % there is a problem
                            disp('!!! error in f_collect_gaitCycles_NoKinetics.m: !!!');
                            disp(['!!! the ' GC_side ' gait cycle from ' num2str(GC_FSipsi(1))...
                                's to ' num2str(GC_FSipsi(2)) 's hasn''t any contralateral foot strike.' ...
                                ' Please have a look !!!']);
                            out_GC = 0;
                        end
                        if out_GC
                            gaitCycle = gaitCycle + 1;
                            gaitCycles_infos{gaitCycle,1} = lower(GC_side);
                            gaitCycles_infos{gaitCycle,2} = 'FP0';
                            events.FS_ipsi = GC_FSipsi;
                            events.FO_ipsi = GC_FOipsi;
                            events.FO_contra = GC_FOcontra;
                            events.FS_contra = GC_FScontra;
                            gaitCycles_infos{gaitCycle,3} = events;
                        end
                    else
                        disp('stride too long');
                        continue
                    end % if stride_length < 1.5*GC_length
                end % if out_FS2ipsi
            else % this event can't be the 1st event of a gait cycle
                continue
            end % if strcmp(list_events{evts,3},'Strike')
        end % for evts = 1: size(list_events,1)-4
        
        if gaitCycle == 0
            disp('!!! error in f_collect_gaitCycles_NoKinetics.m: !!!');
            disp('!!! No one proper gait cycle in term of events were found in the c3d !!!');
            out = 0;
        else
            %% look for the step number (from 4th step)
            if TO_4thStep % the value is different from initialisation to 0
                list_FO_values = cell2mat(list_FOs(:,1));
                [out_4thStep,ind_4thStep] = find_index(list_FO_values,TO_4thStep);
                if out_4thStep
                    %%% give a step number to each foot off
                    list_FOs{ind_4thStep,3} = 4;
                    % steps after the 4th
                    step = 4;
                    for i = ind_4thStep+1:length(list_FO_values)
                        side_i = list_FOs{i,2}(1:4);
                        side_before = list_FOs{i-1,2}(1:4);
                        if ~strcmp(side_i,side_before)
                            step = step + 1;
                        else
                            step = step + 2;
                        end
                        list_FOs{i,3} = step;
                    end
                    % steps before the 4th
                    if ind_4thStep > 1
                        i = ind_4thStep - 1;
                        step = 4;
                        while i >=1
                            side_i = list_FOs{i,2}(1:4);
                            side_after = list_FOs{i+1,2}(1:4);
                            if ~strcmp(side_i,side_after)
                                step = step - 1;
                            else
                                step = step - 2;
                            end
                            list_FOs{i,3} = step;
                            i = i - 1;
                        end
                    end
                    %%% make a connection between the foot offs and the gait cycles
                    for gaitCycle = 1:size(gaitCycles_infos,1)
                        [~,ind_gc] = find_index(list_FO_values,...
                            gaitCycles_infos{gaitCycle,3}.FO_ipsi);
                        gaitCycles_infos{gaitCycle,4} = list_FOs{ind_gc,3};
                    end
                else
                    disp('!!! error in f_collect_gaitCycles_Kinetics.m: !!!');
                    disp(['!!! the given general event for the 4th step doesn''t '...
                        'correspond to any foot off event !!!']);
                    out = 0;
                end % if out_4thStep
            else
                for gaitCycle = 1:size(gaitCycles_infos,1)
                    gaitCycles_infos{gaitCycle,4} = 0;
                end
            end % if TO_4thStep
           %% look for the step number
            list_FO_values = cell2mat(list_FOs(:,1));
            % the second FO is the one of the 1st step
            step = 1;
            list_FOs{2,3} = step;
            for i=3:length(list_FO_values)
                side_i = list_FOs{i,2}(1:4);
                side_before = list_FOs{i-1,2}(1:4);
                if ~strcmp(side_i,side_before)
                    step = step + 1;
                else
                    step = step + 2;
                end
                list_FOs{i,3} = step;
            end
            %%% make a connection between the foot offs and the gait cycles
            for gaitCycle = 1:size(gaitCycles_infos,1)
                [~,ind_gc] = find_index(list_FO_values,...
                    gaitCycles_infos{gaitCycle,3}.FO_ipsi);
                gaitCycles_infos{gaitCycle,5} = list_FOs{ind_gc,3};
            end
        end
    else
        disp('!!! error in f_collect_gaitCycles_NoKinetics.m: !!!');
        disp('!!! There is''nt any events in the c3d. !!!');
        out = 0;
    end % if  ~isempty(struct2cell(events_struct))
end

function [events, event_names] = get_event(event_index, events_list, events_field, events, event_names)
% get the events from the field 'events_field' out of the struct
% 'events_list' and convert the values into a cell format 'events'
% event_names is a struct with corresponding types of the events:
% X_Foot_Strike or X_Foot_Off

    events_s = events_list.(events_field{event_index});

    if numel(events_s) > 1
        event_names = [event_names; repmat(events_field(event_index), 1, numel(events_s))'];
        events = [events; num2cell(events_s)'];
    else
        event_names = [event_names; events_field(event_index)];
        events = [events; num2cell(events_s)];
    end  % if
end  % function

function [out,event,index] = find_event(listEvents,sideEvt,typeEvt)
% search a corresponding event in the given list, for given side and type
% 
% INPUT
%     listEvents = list of all events (cell with 1st col = events time, 2nd
%         col = events side (Left/Right), 3rd col = events type (Strike/Off)
%     sideEvt = side for the event to find
%     typeEvt = type for the event to find
    out = 1;    
    index = 1;
    
    while index <= size(listEvents,1) && ...
            (~strcmp(listEvents{index,2},sideEvt) || ...
            ~strcmp(listEvents{index,3},typeEvt))
        index = index + 1;
    end
    if index <= size(listEvents,1) % event found
        event = listEvents{index,1};
    else
        out = 0;
        event = 0;
    end
end

function [out,index] = find_index(list_values,value)
% find the index of the given value in the list_values
% if no corresponding value found -> index = 0 and out = 1
    out = 1;
    index = 1;
    while index <= length(list_values)
        if value == list_values(index)
            break
        else
            index = index + 1;
        end
    end
    if index > length(list_values)
        out = 0;
        index = 0;
    end
end

