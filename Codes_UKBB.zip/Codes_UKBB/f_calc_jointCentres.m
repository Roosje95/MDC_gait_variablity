function [AJC,KJC] = f_calc_jointCentres(KNE_Pig,KAX,KD1,KD2,ANK,ANKM,sign,KneeWidth,KJC_Pig)

%% Calculate Knee Marker and joint centre

BasePrism = cat(3,KAX,KD1,KD2);
CenterBasePrism = mean(BasePrism,3);

VecKAX_KD1 = KD1-KAX; 
VecKD2_KAX = KAX-KD2;

% calculate orthogonal vector from plain KAD-Markers to direction knee marker
n_vec_BasePrism = cross(VecKAX_KD1, VecKD2_KAX) * sign; % * sign to account for body side

for i = 1:size(KD1,1)
    n(i,:) = norm(n_vec_BasePrism(i,:));
end 
norm_n_vec_BasePrism = n_vec_BasePrism./repmat(n,1,3); 

% calculation of Euclidean distance between Centre of prism base and KAX marker
squareDist = (CenterBasePrism - KAX).^2;
Length_A = sqrt(sum(squareDist,2)); % calculate Euclidean distance 


% length of hypotenuse
squareDist = (KD1 - KD2).^2;
Length_KD1_KD2 = sqrt(sum(squareDist,2)); % calculate Euclidean distance

% calculate length of stick on KAD, a^2 + b^2 = c^2 (with c = Length_KD1_KD2)
% since a^2 = b^2 (all stick on KAD have same length) -> a^2 + a^2 = c^2 -> a = c/sqrt(2)
Length_C = Length_KD1_KD2/sqrt(2);

% calculate hight prism
HightPrism = sqrt(Length_C.^2 - Length_A.^2); %

% calculate knee marker
KNE = CenterBasePrism + (norm_n_vec_BasePrism .* repmat(abs(HightPrism),1,3));

half_KneeWidth = str2double(KneeWidth)/2;

KneeAxis_vec = KNE - KAX; 

for i = 1:size(KD1,1)
    nn(i,:) = norm(KneeAxis_vec(i,:));
end 
norm_KneeAxis_vec = KneeAxis_vec./repmat(nn,1,3);  

KJC = KNE + (norm_KneeAxis_vec * abs(half_KneeWidth+6.5)); % knee joint centre

% figure; hold all
% scatter3(KAX(1,1),KAX(1,2),KAX(1,3),'MarkerEdgeColor','b')
% scatter3(KD1(1,1),KD1(1,2),KD1(1,3),'MarkerEdgeColor','r')
% scatter3(KD2(1,1),KD2(1,2),KD2(1,3),'MarkerEdgeColor','r')
% scatter3(CenterBasePrism(1,1),CenterBasePrism(1,2),CenterBasePrism(1,3),'Marker','.');
% 
% scatter3(KNE_Pig(1,1),KNE_Pig(1,2),KNE_Pig(1,3),'Marker','*','MarkerEdgeColor','k')
% scatter3(KNE(1,1),KNE(1,2),KNE(1,3),'Marker','o','MarkerEdgeColor','c')
% scatter3(KJC_Pig(1,1),KJC_Pig(1,2),KJC_Pig(1,3),'Marker','+','MarkerEdgeColor','k')
% scatter3(KJC(1,1),KJC(1,2),KJC(1,3),'Marker','o','MarkerEdgeColor','c')


%% calculate ankle joint centre

AJC = mean(cat(3,ANK,ANKM),3); %ankle joint center as mean between malleoli
% 
% figure; hold all
% scatter3(ANK(:,1),ANK(:,2),ANK(:,3),'MarkerEdgeColor','b')
% scatter3(ANKM(:,1),ANKM(:,2),ANKM(:,3),'MarkerEdgeColor','k')
% scatter3(AJC(:,1),AJC(:,2),AJC(:,3),'MarkerEdgeColor','c')

end %FUNCTION f_calc_jointCentres
