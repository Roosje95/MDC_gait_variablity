%{ 
*********************************************************************************
   Function "f_makeTextbox" linked to script "Auswertung_mitFormularen"
   run from "f_Report_clinicalTests" and "f_Report_TemporalParameters"
                     by Katrin Schweizer April 2014
*********************************************************************************

Plots textboxes into a pre-defined figure.

INPUT
  figure1 = figures handle where the textbox is meant to go
  String = string for the textbox
  Xpos = X-axis position of the textbox (lower left corner)
  Ypos = Y-axis position (lower left corner)
  Width = width of the textbox
  Height = hight of the textbox
  FrontSize = size of the text
  BackgroundColor = background color of the textbox (e.g. grey)
  HorizontalAlignment = alignment of the text (e.g. "left","right","center")
%}


function f_makeTextbox(figure1,String,Xpos,Ypos,Width,Height,FrontSize,...
                       BackgroundColor,HorizontalAlignment)


   annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',String,...
              'FontWeight','light','FontSize',FrontSize,'VerticalAlignment','middle',...
              'FitBoxToText','off','LineStyle','none', 'EdgeColor','none',...
              'BackgroundColor',BackgroundColor,'HorizontalAlignment',HorizontalAlignment);
          
end %FUNCTION