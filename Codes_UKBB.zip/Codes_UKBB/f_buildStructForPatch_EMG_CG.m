%{ 
*********************************************************************************
Function "f_buildStructForPatch_EMG_CG" linked to script "Auswertung_mitFormularen"
                     runs from "f_plotEMG"
                     by Marie Freslier March 2014
*********************************************************************************

INPUT
   muscleNorm = X vector from the CG_EMG struct (eg: [0;44;96;100] : muscle 
                is activ from 0 to 44% and from 96 to 100%)
   emgLength = length of the emg signal
   Color = Definition of the color for the patch (e.g. grey [0.8 0.8 0.8]
   Ymin = Value for minimum on Y achsis to define the placment of the bottom of recangles
   Ymax = Value for maximum on Y achsis to define the placment of the top of recangles

OUTPUT
   struct_for_patch = struct which is to pass in argument for the function: 
                      patch(struct_for_patch,'LineStyle','none') 

%}
function [struct_for_patch] = f_buildStructForPatch_EMG_CG(muscleNorm,emgLength,Color,Ymin,Ymax)

    % number of faces (activ phases)
    nbFaces = floor(length(muscleNorm)/2);

    % vertices of the rectangle(s) to show
    verts = zeros(4*nbFaces,2); % 4 vertices per face, 2 coordinates per vertex

    % faces: connect the vertices to create the faces
    faces = zeros(nbFaces,4); % nbFaces faces, 4 vertices per face
    
    for i=1:nbFaces
        % begin and end of the ith activ phase
        beginActiv = round (muscleNorm(2*(i-1)+1)*(emgLength-1)/100) + 1;
        endActiv = round (muscleNorm(2*(i-1)+2)*(emgLength-1)/100) + 1;
        
        % 1st vertex
        verts(4*(i-1)+1,1) = beginActiv;
        verts(4*(i-1)+1,2) = Ymin;
        % 2nd vertex
        verts(4*(i-1)+2,1) = endActiv;
        verts(4*(i-1)+2,2) = Ymin;
        % 3rd vertex
        verts(4*(i-1)+3,1) = endActiv;
        verts(4*(i-1)+3,2) = Ymax;
        % 4th vertex
        verts(4*(i-1)+4,1) = beginActiv;
        verts(4*(i-1)+4,2) = Ymax;
        
        % connect the 4 vertices of the ith face (indeces of the vertices 
        % from the verts vertor)
        faces(i,:) = [4*(i-1)+1 4*(i-1)+2 4*(i-1)+3 4*(i-1)+4];
    end

    struct_for_patch.Vertices = verts;
    struct_for_patch.Faces = faces;
    struct_for_patch.FaceColor = Color;

end %FUNCTION