function [normData] = f_Normalise_RV(data,EV1,EV2,points,freq,firstFrame)

   %% Transfer events from seconds to frames 
    % As the first frame is subtracted, it doesn't matter if the trials were cut
    % beforehand or not
   EV1 = round(EV1 * freq - firstFrame + 2);
   EV2 = round(EV2 * freq - firstFrame + 2);
  
   EV_1 = 1; %first event is in first row
   EV_2 = EV2-EV1+1;
   dataNormalise = data(EV1:EV2,:); %cut data --> keep data between the events
      
   
   %% normalise  
   
   inc = (EV_2 - EV_1) / points; % increment to get data points-1
   
   x = 1:EV_2; 
   xi = 1:inc:EV_2;
   
   normData = interp1(x,dataNormalise,xi)';   

end % FUNCTION

