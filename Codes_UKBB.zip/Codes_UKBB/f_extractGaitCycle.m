%{ 
*********************************************************************************
Function "f_extractGaitCycle" linked to script "Auswertung_mitFormularen"
            by Katrin Schweizer Dez. 2013
*********************************************************************************

Cut the measured data to a gait cycle (not normalised yet)

INPUT: data = entire data as captured
       events = events struct as output of c3d
       freq = measurement frequency (e.g. 120HZ
       firstFrame = first frame of the measurement (necessary, if the data were
                    cut at the beginning)

OUTPUT: gaitCycleValues = the values cut to the gait cycle
%}


function gaitCycleValues = f_extractGaitCycle(data,events,freq,firstFrame)

% transfer the events from seconds to frames
FS1 = events(1) * freq +1 - firstFrame + 1;
FS2 = events(2) * freq +1 - firstFrame + 1;

% Cut data to the time from heel strike to heel strike
gaitCycleValues = data(floor(FS1):floor(FS2));

end %FUNCTION