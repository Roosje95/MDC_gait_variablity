%{ 
*********************************************************************************
Function "f_load_c3d" linked to script "Auswertung_..."
         by Katrin Bracht March 2018
*********************************************************************************

- Loads the c3d-file
    - Test if files were processed in Nexus
    - correct moments to Nm instead of Nmm 
- Adds fields with NaN if they are missing (e.g. upper body markers)
- Zero-Level EMG
- Correct gait direction
- Calculate tibia angle absolute to lab coordinate
- Rotate Sole angle so that 0 = flat foot, pos = dorsiflex
- Built struct with unnormalised data 

INPUT: Path_c3d = Path to the c3d-file
       EMG_recorded = Info on whether EMG was recorded ('y')or not ('n') 

OUTPUT: Resuct = Struct: {Model}.{Measure}.{Plane}.{Joint}.{Side} (e.g PIGunnormalised.Angles.Sagittal.Knee.Left)
        videoFront = String for Video name e.g. 'AP_posterior'
        videoSagitt = String for Video name e.g. 'Sagittal_left'
        Markers_GaitDirecCorrect = Struct with all markers similar to
                                   output from c3d but with corrected gait direction
%}

function [Resuct,videoFront,videoSagitt,Markers_GaitDirecCorrect] = f_load_c3d(Path_c3d,EMG_recorded)

    warning off all
        acq = btkReadAcquisition(Path_c3d);
    warning on all; warning('off','MATLAB:interp1:NaNinY')  

    % sometimes the patient ID is in the events name, therefore it has to be corrected    
    %     Eventnr = btkGetEventNumber(acq);   
    for t = 1:btkGetEventNumber(acq)
        btkSetEventSubject(acq,t,'');
    end
    events = btkGetEvents(acq);


%************************************************************************** 
    %% Load data from c3d
%**************************************************************************

    freq = btkGetPointFrequency(acq); % frequency kinematic (Vicon)
    freqAnalog = btkGetAnalogFrequency(acq); % frequency analog (EMG, forces)
    firstFrame = btkGetFirstFrame(acq); % first frame of the measurement (in case the trial was cut)
    firstFrameAnalog = firstFrame*(freq\freqAnalog)-(freq\freqAnalog)+1;
          %firstFrameAnalog ist nicht gleich firstFrame Vicon, da andere
          %Aufnahmefrequenz   
          
    Markers = btkGetMarkers(acq); % all marker, joint centres and centre of mass
    
    Angles = btkGetAngles(acq); % all angles
        

%% Marie -> noch ben�tigt???
 
    % Test if files were processed in Nexus
    if isempty(fieldnames(Angles))
       disp(' '); disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
       disp(['File    ',Path_c3d,'    not processed in Nexus'])
       disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
       ERROR
    end %isempty(fieldnames(Angles))
     
%%
    Analog_allFields = btkGetAnalogs(acq); 
    Forces = btkGetForces(acq); % all forces at the joints, ground reaction forces, normalised GRF
    Powers = btkGetPowers(acq); % all powers at the joints
    Moments = btkGetMoments(acq);
        
    % correct moments to Nm instead of Nmm
    Moments = structfun(@(x) (x./1000),Moments,'UniformOutput', false);


%**************************************************************************    
    %% Add non-existing fields (e.g. upper body markers to struct) and fill
    %  with NaN "f_add_NaNfields"
%**************************************************************************

    Markers_all = {'LBAK','LFIN','LWRA','LWRB','LELB','LFHD','LBHD','LSHO',... %all PiG Marker
                   'CLAV','STRN','C7','T10','RFIN','RWRA','RWRB','RELB','RFHD',...
                   'RBHD','RSHO','SACR',... 
                   'LPSI','LTRO','LDTIB','LTUB','LDTHI','LPTHI',... %additional ChiBa Marker
                   'LTPR','LSITA','LPMT5','LDMT5','LHLX','LDMT1','LPMT1','LCUN',...
                   'RPSI','RTRO','RDTIB','RTUB','RDTHI','RPTHI',... 
                   'RTPR','RSITA','RPMT5','RDMT5','RHLX','RDMT1','RPMT1','RCUN',...       
                   'RFOO','RFOA','RFOL','RFOP', 'RFEO','RFEA','RFEL','RFEP', 'RTIO','RTIA','RTIL','RTIP',...%coordinate systems of PiG
                   'RCLO','RCLA','RCLL','RCLP', 'RHUO','RHUA','RHUL','RHUP', 'RRAO','RRAA','RRAL','RRAP',...
                   'LFOO','LFOA','LFOL','LFOP', 'LFEO','LFEA','LFEL','LFEP', 'LTIO','LTIA','LTIL','LTIP',...
                   'LCLO','LCLA','LCLL','LCLP', 'LHUO','LHUA','LHUL','LHUP', 'LRAO','LRAA','LRAL','LRAP',...
                   'HEDO','HEDA','HEDL','HEDP'}'; 
               
    Angles_LB = {'LAnkleAngles','LAbsAnkleAngles','LKneeAngles','LHipAngles',...
                 'LPelvisAngles','LFootProgressAngles','LTibiaAngles',...
                 'RAnkleAngles','RAbsAnkleAngles','RKneeAngles','RHipAngles',...
                 'RPelvisAngles','RFootProgressAngles','RTibiaAngles'}';

    Angles_UB = {'LWristAngles','LElbowAngles','LHeadAngles','LNeckAngles',...
                 'LShoulderAngles','LThoraxAngles','LSpineAngles','LPelvisAngles',...
                 'RWristAngles','RElbowAngles','RHeadAngles','RNeckAngles',...
                 'RShoulderAngles','RThoraxAngles','RSpineAngles','RPelvisAngles'}';
        
    Forces_LB = {'LGroundReactionForce','RGroundReactionForce','LNormalisedGRF',...
              'RNormalisedGRF','LAnkleForce','RAnkleForce','LKneeForce','RKneeForce',...
              'LHipForce','RHipForce'}';
    Forces_UB = {'LWaistForce','RWaistForce','LNeckForce',...
              'RNeckForce','LShoulderForce','RShoulderForce','LElbowForce',...
              'RElbowForce','LWristForce','RWristForce'}';
          
    Moments_LB = {'LGroundReactionMoment','RGroundReactionMoment','LAnkleMoment',...
               'RAnkleMoment','LKneeMoment','RKneeMoment','LHipMoment','RHipMoment'}';
    Moments_UB = {'LWaistMoment','RWaistMoment','LNeckMoment','RNeckMoment','LShoulderMoment',...
               'RShoulderMoment','LElbowMoment','RElbowMoment','LWristMoment','RWristMoment'}';

    Powers_LB = {'LAnklePower','RAnklePower','LKneePower','RKneePower','LHipPower','RHipPower'}';
    Powers_UB = {'LWaistPower','RWaistPower','LNeckPower','RNeckPower','LShoulderPower',...
               'RShoulderPower','LElbowPower','RElbowPower','LWristPower','RWristPower'}';
            
    if EMG_recorded == 'y'
       Anaolog_EMG = {'v','v1','v10','v11','v12','v13','v14','v15','v2','v3','v4','v5','v6','v7','v8','v9'}'; 
    else  Anaolog_EMG = {'EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN',...
                         'EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN',...
                         'EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN','EMG_NaN'}'; 
    end   
         
           
    Markers_withUpperBody = f_add_NaNfields(Markers,Markers_all,{'noDeletion'});
    Angles_withUpperBody = f_add_NaNfields(Angles,Angles_LB,{'noDeletion'});
    Angles_withUpperBody = f_add_NaNfields(Angles_withUpperBody,Angles_UB,{'noDeletion'});
    Moments_allFields = f_add_NaNfields(Moments,Moments_LB,Moments_UB);
    Powers_allFields = f_add_NaNfields(Powers,Powers_LB,Powers_UB);
    Forces_allFields = f_add_NaNfields(Forces,Forces_LB,Forces_UB);

        
%**************************************************************************    
    %% Zero-level EMG and set data to NaN when no EMG was measured "f_zerolevelEMG"
%**************************************************************************

    Analog_allFields = f_zerolevelEMG(Analog_allFields,EMG_recorded);

   
%**************************************************************************    
    %% Correct gait direction with function "f_correctGaitDirection"
%**************************************************************************

    [Markers_GaitDirecCorrect,Forces_1,videoFront,videoSagitt] = f_correctGaitDirection(Markers_withUpperBody,...
                                                                              Forces_allFields);
    Forces_GaitDirecCorrect = Forces_allFields;
    Forces_GaitDirecCorrect.LGroundReactionForce = Forces_1.LGroundReactionForce;
    Forces_GaitDirecCorrect.RGroundReactionForce = Forces_1.RGroundReactionForce;
    
    Forces_GaitDirecCorrect.LNormalisedGRF = Forces_1.LNormalisedGRF;
    Forces_GaitDirecCorrect.RNormalisedGRF = Forces_1.RNormalisedGRF;

    %medio-lateral GRF for left side *-1
    Forces_GaitDirecCorrect.RGroundReactionForce(:,2) = Forces_GaitDirecCorrect.RGroundReactionForce(:,2) * -1;

    Forces_GaitDirecCorrect.LNormalisedGRF(:,1) = Forces_GaitDirecCorrect.LNormalisedGRF(:,1) * -1;
    Forces_GaitDirecCorrect.RNormalisedGRF(:,1) = Forces_GaitDirecCorrect.RNormalisedGRF(:,1) * -1;
  
    
%**************************************************************************    
    %% Calculate tibia angle absolute to lab coordinate "f_calc_absAngles_GroodSuntay"
%**************************************************************************
 
   % create vectors of tibia coordinate system
    tibXvectLeft = Markers_GaitDirecCorrect.LTIA - Markers_GaitDirecCorrect.LTIO;
    tibYvectLeft = Markers_GaitDirecCorrect.LTIL - Markers_GaitDirecCorrect.LTIO;
    tibZvectLeft = Markers_GaitDirecCorrect.LTIP - Markers_GaitDirecCorrect.LTIO;

    tibXvectRight = Markers_GaitDirecCorrect.RTIA - Markers_GaitDirecCorrect.RTIO;
    tibYvectRight = Markers_GaitDirecCorrect.RTIL - Markers_GaitDirecCorrect.RTIO;
    tibZvectRight = Markers_GaitDirecCorrect.RTIP - Markers_GaitDirecCorrect.RTIO;

   % calculate Tibia position in space
    [tibFlexLeft,tibVarLeft,tibRotLeft] = ...
        f_calc_absAngles_GroodSuntay(tibXvectLeft,tibYvectLeft,tibZvectLeft,'L');    
    [tibFlexRight,tibVarRight,tibRotRight] = ...
        f_calc_absAngles_GroodSuntay(tibXvectRight,tibYvectRight,tibZvectRight,'R');
    
    Angles_withUpperBody_Tibia = Angles_withUpperBody;

    Angles_withUpperBody_Tibia.LTibiaAngles(:,1) = tibFlexLeft;
    Angles_withUpperBody_Tibia.LTibiaAngles(:,2) = tibVarLeft;
    Angles_withUpperBody_Tibia.LTibiaAngles(:,3) = tibRotLeft;
    Angles_withUpperBody_Tibia.RTibiaAngles(:,1) = tibFlexRight;
    Angles_withUpperBody_Tibia.RTibiaAngles(:,2) = tibVarRight;
    Angles_withUpperBody_Tibia.RTibiaAngles(:,3) = tibRotRight;

    
%**************************************************************************    
   %% Sole angle so that 0 = flat foot, pos = dorsiflex
%**************************************************************************

    Angles_withUpperBody_Tibia.LFootProgressAngles(:,1) = (Angles_withUpperBody_Tibia.LFootProgressAngles(:,1) +90) *-1;
    Angles_withUpperBody_Tibia.RFootProgressAngles(:,1) = (Angles_withUpperBody_Tibia.RFootProgressAngles(:,1) +90) *-1;   
     


%**************************************************************************    
    %% Build struct with function "f_build_Struct"
%**************************************************************************

    [Struct] = f_build_Struct(Angles_withUpperBody_Tibia,'Angle',[]); 
    Resuct.PIGunnormalised.Angle = Struct.Angle;
 
    [Struct] = f_build_Struct(Moments_allFields,'Moment',[]);
    Resuct.PIGunnormalised.Moment = Struct.Moment;
    
    [Struct] = f_build_Struct(Powers_allFields,'Power',[]);
    Resuct.PIGunnormalised.Power = Struct.Power;
    
    [Struct] = f_build_Struct(Forces_GaitDirecCorrect,'Force',[]);
    Resuct.PIGunnormalised.Force = Struct.Force;
    
    [Struct] = f_build_Struct(Markers_GaitDirecCorrect,'Marker',[]);
    Resuct.PIGunnormalised.Marker = Struct.Marker;
    
    [Struct] = f_build_Struct(Analog_allFields,'EMG',[]);
    %***/
    if ~isempty(fieldnames(Struct)) %***/
        Resuct.PIGunnormalised.EMG = Struct.EMG;
    end
    
    [Struct] = f_build_Struct(events,'Events',[]);
    Resuct.PIGunnormalised.Events = Struct.Events;
    
    Resuct.PIGunnormalised.Frequency.Vicon.Hertz.Dummy = freq;
    Resuct.PIGunnormalised.Frequency.Analog.Hertz.Dummy = freqAnalog;
    Resuct.PIGunnormalised.FirstFrame.Vicon.Dummy.Dummy = firstFrame;
    Resuct.PIGunnormalised.FirstFrame.Analog.Dummy.Dummy = firstFrameAnalog;
    
    Resuct.PIGunnormalised.Marker.AP = rmfield(Resuct.PIGunnormalised.Marker.AP,'BAK');
    Resuct.PIGunnormalised.Marker.Lateral = rmfield(Resuct.PIGunnormalised.Marker.Lateral,'BAK');
    Resuct.PIGunnormalised.Marker.Vertical = rmfield(Resuct.PIGunnormalised.Marker.Vertical,'BAK');
      
    btkDeleteAcquisition(acq); % closes c3d-file (acq), otherwise MATLAB runs out of memory  
    
end % FUNCTION

