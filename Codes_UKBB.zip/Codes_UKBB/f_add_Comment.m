%{
*********************************************************************************
               Function "f_add_Comment" linked to 
                          main script      
                  by Marie Freslier June 18
*********************************************************************************

Holds some comments from user to print into the first page of the pdf
                                     
INPUT
  Params4_c3d = Struct with all clinical measurements & measurement information form,
                NameParameter.Value (value is in string)
  EMG_recorded = 'y' or 'n'
 
OUTPUT
  commentToPrint = cell array with the comments
%}

function commentToPrint = f_add_Comment(Params4_c3d, EMG_recorded)
    %%% Bemerkungen:
    Measure_comment = strrep(Params4_c3d.Measure_comment,'; ','\n');
    EMG_comment = strrep(Params4_c3d.EMG_comment,'; ','\n');
    clinical_exam_comment = strrep(Params4_c3d.clinical_exam_comment,'; ','\n');
    % Data
    x = 1;
    defaultText = 'Compliance in der klinische Untersuchung: ';
    if ~strcmp(Params4_c3d.clinical_exam_comment,'')
       defaultText = [defaultText clinical_exam_comment];
       Comment_default{1,x} = defaultText;
    else
        defaultText = [defaultText 'OK'];
        Comment_default{1,x} = defaultText;
    end %IF ~strcmp(Param.clinical_exam_comment,'')
    x = x+1;

    defaultText = [defaultText '\n\nCompliance in der Ganganalyse: '];
    if ~strcmp(Params4_c3d.Measure_comment,'')
       defaultText = [defaultText Measure_comment];
       Comment_default{1,x} = ['Compliance in der Ganganalyse: ',Measure_comment];
    else
        defaultText = [defaultText 'OK'];
        Comment_default{1,x} = ['Compliance in der Ganganalyse: OK'];
    end %IF ~strcmp(Param.Measure_comment,'')
    x = x+1;

    defaultText = [defaultText '\n\nDaten Qualit�t:'];
    Comment_default{1,x} = ['Daten Qualit�t:'];
    x = x+1;
    defaultText = [defaultText '\n   Marker Probleme: keine'];
    Comment_default{1,x} = ['Marker Probleme: keine'];
    x = x+1;
    defaultText = [defaultText '\n   Konsistenz: OK'];
    Comment_default{1,x} = ['Konsistenz: OK'];
    x = x+1;

    if EMG_recorded == 'y'
        defaultText = [defaultText '\n   EMG Qualit�t: '];
        if ~strcmp(Params4_c3d.EMG_comment,'')
           defaultText = [defaultText EMG_comment];
           Comment_default{1,x} = ['EMG Qualit�t: ' EMG_comment];
        else
            defaultText = [defaultText 'OK'];
           Comment_default{1,x} = ['EMG Qualit�t: OK'];
        end %IF ~strcmp(Param.EMG_comment,'')
    end %IF EMG_recorded ~= 0

    defaultText = [defaultText '\n   Auff�llige Daten:'];
    defaultText = [defaultText '\n\nGenerelle Bemerkungen:'];

    defaultText_dialogBox{1} = sprintf(defaultText);

    %%%Dialog Box
    Title_dialogBox = 'Data quality';
    text_dialogBox = 'Please enter a text to describ the data quality of the measurement';
    size_dialogBox = [8 100];
    Comment = inputdlg(text_dialogBox,Title_dialogBox,size_dialogBox,defaultText_dialogBox);
    if size(Comment)
        [nbLines,nbCols] = size(Comment{1});
        for lines =1:nbLines
            index = nbCols;
            while index >=1 && strcmp(Comment{1}(lines,index),' ')
                index = index - 1;
            end
            commentToPrint{lines} = Comment{1}(lines,1:index);    
        end
%         annotation(fig_firstPage,'textbox',[0.06 0.24 0.88 0.02],'String',commentToPrint,...
%                         'FontSize',11,'FitBoxToText','off','LineStyle','none');
    else
        commentToPrint = Comment_default;
%         annotation(fig_firstPage,'textbox',[0.06 0.24 0.88 0.02],'String',Comment_default,...
%                         'FontSize',11,'FitBoxToText','off','LineStyle','none');
    end
end