%{
********************************************************************************* 
  Function "f_Report_ConsistencyEMG" linked to script "Auswertung_mitFormularen"
                    by Katrin Schweizer Aug. 2014
*********************************************************************************

Plot all trials of each muscle below each other --> consistency for report.

INPUT: dataStruct = Struct with all trials (StructAllTrials)
       Title = Title for page ('Consistency: Electromyographic activity (20-700Hz bandpass)')
       Subtitle = Names for muscle in plot
       Fildnames_EMG = Names for muscle in struct
       PageNum = Number for page
       RepTrial_left/RepTrial_right = name of representative trial (e.g. B4)
       Kinetic_4orMore = Is one if more than 4 kinetics are good, if not = 0
       TrialNamePlot = The trial names with dots inbetween
 
OUTPUT: PageNum = Input page number + 2

%}

function PageNum = f_Report_ConsistencyEMG_4FP(dataStruct,Title,Subtitle,...
                                            Fildnames_EMG,PageNum,RepTrial_left,...
                                            RepTrial_right,Kinetic_4orMore,TrialNamePlot)
    
    warning('off','MATLAB:warn_r14_stucture_assignment')
    
    Fieldnames = fieldnames(dataStruct);
    
    % Get measurement frequency analog and first frame analog
    Freq = dataStruct.(Fieldnames{1,1}).PIGunnormalised.Frequency.Analog.Hertz.Dummy;

    %if odd number of muscles add an Dummy-Muscle
    if mod(length(Subtitle),2)
       Subtitle{end+1,1} = 'Empty';
       Fildnames_EMG {end+1,1} = 'Dummy';  
    end 
  
    %% Separate left and right side
    
    for ii = 1:size(Fieldnames,1)  
        Le(ii,:) = ismember('L',Fieldnames{ii,1});
        Ri(ii,:) = ismember('R',Fieldnames{ii,1});     
    end
    
    Fieldnames_Left = Fieldnames(Le,:);
    TrialNamePlot_left = TrialNamePlot(Le,:);
    
    Fieldnames_Right = Fieldnames(Ri,:);    
    TrialNamePlot_right = TrialNamePlot(Ri,:);   
    
%**************************************************************************    
%% Left side
%**************************************************************************

   % predefine figure
    Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                 'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                 'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]
    annotation(Fig,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
                     'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                     'VerticalAlignment','middle','LineStyle','none');
    annotation(Fig,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
                     'FontSize',11,'FitBoxToText','off','LineStyle','none',...
                     'VerticalAlignment','middle','HorizontalAlignment','right'); 
    annotation(Fig,'textbox',[0.06 0.935 0.09 0.04],'String','Left',...
                   'FontWeight','bold','FontSize',11,'FitBoxToText','off',...
                   'LineStyle','none','Color','r');

               
   %% Make tight subplots with "f_tightSubplot"      
   
    numTrials_Left = length(Fieldnames_Left);
    Rows = numTrials_Left*2+2; %Number rows for subplots +2 as two will be deleted to have space for headings
    Columns = length(Subtitle)/2;% %Number columns for subplots
    ToDelete = Rows*Columns/2; %Half of number of the subplots
    
    ha = f_tightSubplot(Rows,Columns,[0 .01],[.05 .01],[0.12 0.089]); 
    %delete the first row and one row between the first 3/4 muscles and the other
    delete(ha([1:Columns,ToDelete+1:ToDelete+Columns]));
    

    %% Cut EMG data to gait cycle and transfer from Volt to mVolt
    
    MIN = zeros(size(Fieldnames_Left,1),size(Fildnames_EMG,1)); %Predfine MIN
    MAX = zeros(size(Fieldnames_Left,1),size(Fildnames_EMG,1)); %Predfine MAX
    
    for i = 1:size(Fieldnames_Left,1)
        
        FirstFrame = dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.FirstFrame.Analog.Dummy.Dummy;
        
        % Transfere events from seconds to data points
        EV1 = round(dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.Events_currentGC.InSeconds. ...
                                FootStrike.dummy(1) * Freq - FirstFrame + 2);
        EV2 = round(dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.Events_currentGC.InSeconds. ...
                                FootStrike.dummy(2) * Freq - FirstFrame + 2);

       % Cut data to gait cycle and find Min/Max for y-axis
       for j = 1:size(Fildnames_EMG,1)
          
           if ~isfield(dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.EMG. ...
                       mVolt, Fildnames_EMG{j,1})
              dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.EMG. ...
                       mVolt.(Fildnames_EMG{j,1}) = struct; %Fildnames_EMG{j,1};
           end
           if ~isfield(dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.EMG. ...
                       mVolt.(Fildnames_EMG{j,1}),'Left')
              dataStruct.(Fieldnames_Left{i,1}).PIGunnormalised.EMG. ...
                          mVolt.(Fildnames_EMG{j,1}).Left = NaN(EV2,1);          
           end %IF ~isfield...
           
           data.(Fieldnames_Left{i,1}).(Fildnames_EMG{j,1}) = dataStruct. ...
                       (Fieldnames_Left{i,1}).PIGunnormalised.EMG. ...
                       mVolt.(Fildnames_EMG{j,1}).Left(EV1:EV2,1);
        
           MIN(i,j) = floor(min(data.(Fieldnames_Left{i,1}).(Fildnames_EMG{j,1})*100))/100;
           MAX(i,j) = ceil(max(data.(Fieldnames_Left{i,1}).(Fildnames_EMG{j,1})*100))/100;
           
       end %FOR j = 1:size(Fildnames_EMG,1)       
       
    end %FOR i = 1:size(Fieldnames_Left,1)
    
    MinMax = min(MIN,[],1);
    MinMax(2,:) = max(MAX,[],1);
    
    MinMax_Abs = max(abs(MinMax),[],1);
    %replace NaNs with ones
    MinMax_Abs(:,isnan(MinMax_Abs)) = 1;
    
    
   %% Plot data into subplots
    x = 0;
    hold all
    
    for i = 1:size(Fieldnames_Left,1)
        
        %If its the representative trial plot it bold
        if strcmp(Fieldnames_Left{i,1},RepTrial_left)
           LineWidth = 1.5;
        else LineWidth = 0.5;
        end
        
        %for all columns to plot
        for j = 1:Columns
            
            %Plot the first three/four muscles in the upper fields
            plot(ha(i+Columns+j-1+x),data.(Fieldnames_Left{i,1}).(Fildnames_EMG{j,1}),'Color','r','LineWidth',LineWidth);
            set(ha(i+Columns+j-1+x),'ylim',[-MinMax_Abs(1,j) MinMax_Abs(1,j)])
         
            %Plot the second three/four muscles in the lower fields
            plot(ha(i+ToDelete+Columns+j-1+x),data.(Fieldnames_Left{i,1}).(Fildnames_EMG{j+Columns,1}),'Color','r','LineWidth',LineWidth);
            set(ha(i+ToDelete+Columns+j-1+x),'ylim',[-MinMax_Abs(1,j+Columns) MinMax_Abs(1,j+Columns)])
            
            
            xlabel(ha(i+ToDelete+Columns+j-1+x),'Gait cycle') % gait cycle to y-axis
            set(ha([i+Columns+j-1+x,i+ToDelete+Columns+j-1+x]),...
               'XLim',[1 size(data.(Fieldnames_Left{i,1}).(Fildnames_EMG{1,1}),1)],...
               'box','on') %set x-limits and box
           
        end %FOR j = 1:Columns
        
        ylabel(ha(i+Columns+x),TrialNamePlot_left{i,1},'FontSize',7.5) % write trial number to x-axis for upper fields
        ylabel(ha(i+ToDelete+Columns+x),TrialNamePlot_left{i,1},'FontSize',7.5) % write trial number to x-axis for lower fields
        
        x = x+Columns-1;

    end %FOR i = 1:size(Fieldnames_Left,1)

    %Remove X and Y-lables
    set(ha([Columns+1:ToDelete,ToDelete+Columns+1:ToDelete*2],1),'XTickLabel',''); 
    set(ha([Columns+1:ToDelete,ToDelete+Columns+1:ToDelete*2],1),'YTickLabel','');
        
   %Create title 
    x = 1;
    for j = [Columns+1:Columns+Columns,ToDelete+Columns+1:ToDelete+Columns+Columns];
        title(ha(j),Subtitle{x,1},'FontWeight','demi','FontSize',11);        
        x = x+1;
    end %FOR j = [Columns+1:Columns+Columns,ToDelete+Columns+1:ToDelete+Columns+Columns];

   %Page Number
    f_makeTextbox(Fig,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
    PageNum = PageNum + 1;

    
  
%**************************************************************************
    %% Right side
%**************************************************************************

    % Predefine figure
    Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                 'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                 'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]
    annotation(Fig,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
                     'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                     'VerticalAlignment','middle','LineStyle','none');
    annotation(Fig,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
                     'FontSize',11,'FitBoxToText','off','LineStyle','none',...
                     'VerticalAlignment','middle','HorizontalAlignment','right'); 
    annotation(Fig,'textbox',[0.06 0.935 0.09 0.04],'String','Right',...
                   'FontWeight','bold','FontSize',11,'FitBoxToText','off',...
                   'LineStyle','none','Color','b');
  
               
   %% Make tight subplots with "f_tightSubplot"  
   
    numTrials_Right = length(Fieldnames_Right);
    Rows = numTrials_Right*2+2;
   
    Columns = length(Subtitle)/2;% %Number columns for subplots
    ToDelete = Rows*Columns/2; %Half of number of the subplots
    
    ha = f_tightSubplot(Rows,Columns,[0 .01],[.05 .01],[0.12 0.089]); 
    %delete the first row and one row between the first 3/4 muscles and the other
    delete(ha([1:Columns,ToDelete+1:ToDelete+Columns]));    
    
    
    %% Cut EMG data to gait cycle and transfer from Volt to mVolt
    
    MIN = zeros(size(Fieldnames_Right,1),size(Fildnames_EMG,1));
    MAX = zeros(size(Fieldnames_Right,1),size(Fildnames_EMG,1));
    
    for i = 1:size(Fieldnames_Right,1)
        
        FirstFrame = dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.FirstFrame.Analog.Dummy.Dummy;
        
        % Transfere events from seconds to data points
        EV1 = round(dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.Events_currentGC.InSeconds. ...
                                FootStrike.dummy(1) * Freq - FirstFrame + 2);
        EV2 = round(dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.Events_currentGC.InSeconds. ...
                                FootStrike.dummy(2) * Freq - FirstFrame + 2);

       % Cut data to gait cycle and find Min/Max for y-axis
       for j = 1:size(Fildnames_EMG,1)
           
           if ~isfield(dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.EMG. ...
                       mVolt, Fildnames_EMG{j,1})
              dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.EMG. ...
                       mVolt.(Fildnames_EMG{j,1}) = struct; %Fildnames_EMG{j,1};
           end
           if ~isfield(dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.EMG. ...
                       mVolt.(Fildnames_EMG{j,1}),'Right')
              dataStruct.(Fieldnames_Right{i,1}).PIGunnormalised.EMG. ...
                          mVolt.(Fildnames_EMG{j,1}).Right = NaN(EV2,1);
           end %IF ~isfield...
           
           data.(Fieldnames_Right{i,1}).(Fildnames_EMG{j,1}) = dataStruct. ...
                       (Fieldnames_Right{i,1}).PIGunnormalised.EMG. ...
                       mVolt.(Fildnames_EMG{j,1}).Right(EV1:EV2,1);
        
           MIN(i,j) = floor(min(data.(Fieldnames_Right{i,1}).(Fildnames_EMG{j,1})*100))/100;
           MAX(i,j) = ceil(max(data.(Fieldnames_Right{i,1}).(Fildnames_EMG{j,1})*100))/100;
           
       end %FOR j = 1:size(Fildnames_EMG,1)       
       
    end %FOR i = 1:size(Fieldnames_Right,1)
    
    MinMax = min(MIN,[],1);
    MinMax(2,:) = max(MAX,[],1);
    
    MinMax_Abs = max(abs(MinMax),[],1);
    %replace NaNs with ones
    MinMax_Abs(:,isnan(MinMax_Abs)) = 1; 
    
    
   %% Plot data into subplots
    x = 0;
    hold all
    
    for i = 1:size(Fieldnames_Right,1)
        
       %If its the representative trial plot it bold
        if strcmp(Fieldnames_Right{i,1},RepTrial_right)
           LineWidth = 1.5;
        else LineWidth = 0.5;
        end   
        
       
        %for all columns to plot
        for j = 1:Columns
            
            %Plot the first three muscles in the upper fields
            plot(ha(i+Columns+j-1+x),data.(Fieldnames_Right{i,1}).(Fildnames_EMG{j,1}),'Color','b','LineWidth',LineWidth);
            set(ha(i+Columns+j-1+x),'ylim',[-MinMax_Abs(1,j) MinMax_Abs(1,j)])
         
            %Plot the second three muscles in the lower fields
            plot(ha(i+ToDelete+Columns+j-1+x),data.(Fieldnames_Right{i,1}).(Fildnames_EMG{j+Columns,1}),'Color','b','LineWidth',LineWidth);
            set(ha(i+ToDelete+Columns+j-1+x),'ylim',[-MinMax_Abs(1,j+Columns) MinMax_Abs(1,j+Columns)])
            
            
            xlabel(ha(i+ToDelete+Columns+j-1+x),'Gait cycle') % gait cycle to y-axis
            set(ha([i+Columns+j-1+x,i+ToDelete+Columns+j-1+x]),...
               'XLim',[1 size(data.(Fieldnames_Right{i,1}).(Fildnames_EMG{1,1}),1)],...
               'box','on') %set X-limits and box
           
        end %FOR j = 1:Columns

        ylabel(ha(i+Columns+x),TrialNamePlot_right{i,1},'FontSize',7.5) % write trial number to x-axis for upper fields
        ylabel(ha(i+ToDelete+Columns+x),TrialNamePlot_right{i,1},'FontSize',7.5) % write trial number to x-axis for lower fields
        
        x = x+Columns-1;

    end %FOR i = 1:size(Fieldnames_Right,1)            
               
    %Remove X and Y-lables
    set(ha([Columns+1:ToDelete,ToDelete+Columns+1:ToDelete*2],1),'XTickLabel',''); 
    set(ha([Columns+1:ToDelete,ToDelete+Columns+1:ToDelete*2],1),'YTickLabel','');
        
   %Create title 
    x = 1;
    for j = [Columns+1:Columns+Columns,ToDelete+Columns+1:ToDelete+Columns+Columns];
        title(ha(j),Subtitle{x,1},'FontWeight','demi','FontSize',11);        
        x = x+1;
    end %FOR j = [Columns+1:Columns+Columns,ToDelete+Columns+1:ToDelete+Columns+Columns];
               
    
   %% Page Number
   
    f_makeTextbox(Fig,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
    PageNum = PageNum + 1;   

        
end %FUNCTION