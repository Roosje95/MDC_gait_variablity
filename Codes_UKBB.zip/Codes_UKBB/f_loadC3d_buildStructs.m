%{ 
*********************************************************************************
       Function "loadC3d_buildStructs" linked to script "Auswertung..."
                       Katrin Bracht March 2018
*********************************************************************************

 1) Load c3d-Data with btk-toolbox & built struct "StructAllC3D" with "f_load_c3d"
 2) Create struct "StructAllGC" with gait cycles "f_load_GC"
 3) Gait Parameter non-dimensional according to Hof 1996 with "f_nonDimens_TemporalParameters"
 4) Built a matrice for each parameter with each trial in a column "DataForCalc"
 5) Check wrist angle with "f_check_WristAngle"


INPUT:

  Path_PatientFolder_temp
  allGaitCycles = a cell array with information of the gait cycles:
                  {x,1} = name of the c3d
                  {x,2} = side
                  {x,3} = 'FP0' (no kinetics)
                  {x,4} = a struct with the events (FS ipsi&contra, FO ipsi&contra)
                  {x,5} = step number, obtained from the definition of the 4th
                          step, 0 if undetermined
                  {x,6} = trial number (obtained from the c3d name)
                  {x,7} = step number, obtained from the 1st gait cycle defined
                          in the trial, -1 if impossible to determine
  EMG_recorded = Info on whether EMG was recorded ('y')or not ('n')

OUTPUT: 
  out = 0 if some errors in labelling
  Trials = Side of gait cycle (L/R), Number of c3d _ number of gait cycle within this trial _ number of step within this trial (e.g. 'L3_GC1_ST0')
  TrialNamePlot = Side of gait cycle (L/R), Number of c3d . number of gait cycle within this trial (e.g. 'L3.GC1')
%}


% function [StructAllGC,StructAllC3D,DataForCalc,Trials,TrialNamePlot] = f_loadC3d_buildStructs(Path_PatientFolder_temp,allGaitCycles,EMG_recorded,Params4_c3d)   % altes  f_Archive_c3d_4FP_2017               
function [out,StructAllGC,StructAllC3D,DataForCalc,Trials,TrialNamePlot] = f_loadC3d_buildStructs(Path_PatientFolder_temp,allGaitCycles,EMG_recorded)   % altes  f_Archive_c3d_4FP_2017               
    out = 1;
    % hold the leg length
    listc3ds = dir([Path_PatientFolder_temp '\*.c3d']);
    acq = btkReadAcquisition([Path_PatientFolder_temp '\' listc3ds(1).name]);
    metaData = btkGetMetaData(acq);
    if isfield(metaData.children,'PROCESSING')
        LLegLength = metaData.children.PROCESSING.children.LLegLength.info.values;
        RLegLength = metaData.children.PROCESSING.children.RLegLength.info.values;
    else
        listmps = dir([Path_PatientFolder_temp '\*.mp']);
        [LLegLength,RLegLength] = f_legLengthFromMP([Path_PatientFolder_temp '\' listmps(1).name]);
    end

    %%**************************************************************************   
    %% Go through all relevant gait cycles
    %%**************************************************************************   

    allGaitCycles = sortrows(allGaitCycles,6);
    StructC3D = struct;

    for i = 1:size(allGaitCycles,1) 
  
        
    %%**************************************************************************   
    %% Load c3d-Data with btk-toolbox & built struct with "f_load_c3d"
    %%************************************************************************** 
           
        if i==1 || allGaitCycles{i,6} ~= allGaitCycles{i-1,6} %if it is a new c3d file 

            [StructC3D,videoFront,videoSagitt,MarkersC3D,] = f_load_c3d([Path_PatientFolder_temp '\' allGaitCycles{i,1}],...
                                                             EMG_recorded);

                                                     
           %%Create struct of same size as StructC3D where all kinetic data are set to NaN at the beginning                                            
 
            StructNaNKinetic = StructC3D;

            SizeKinetic = size(StructC3D.PIGunnormalised.Force.AP.GroundReaction.Left,1);
            [StructNaNKinetic.PIGunnormalised] = f_setKinetic_NaN(StructNaNKinetic.PIGunnormalised,'Left',1,SizeKinetic);
            [StructNaNKinetic.PIGunnormalised] = f_setKinetic_NaN(StructNaNKinetic.PIGunnormalised,'Right',1,SizeKinetic);


           %%If the videos are not already renamed or if videos exist at all
            % add the side from which it was filmed to the file name
            if ~isempty(dir([Path_PatientFolder_temp '\' allGaitCycles{i,1}(1:end-4),'_AP.avi']))
                movefile([Path_PatientFolder_temp '\' allGaitCycles{i,1}(1:end-4),'_AP.avi'],...
                [Path_PatientFolder_temp '\' allGaitCycles{i,1}(1:end-4),'_',videoFront,'.avi'])
            end %IF ~isempty(dir([Path_PatientFolder_temp '\' New_c3d_Files{i,1}(1:end-4),'_AP.avi']))

            if ~isempty(dir([Path_PatientFolder_temp '\' allGaitCycles{i,1}(1:end-4),'_Sagittal.avi']))
               movefile([Path_PatientFolder_temp '\' allGaitCycles{i,1}(1:end-4),'_Sagittal.avi'],...
                        [Path_PatientFolder_temp '\' allGaitCycles{i,1}(1:end-4),'_',videoSagitt,'.avi'])
            end %IF dir([Path_PatientFolder_temp '\' New_c3d_Files{i,1}(1:end-4),'_Sagittal.avi'])

        end %IF i==1 || allGaitCycles{i,6} ~= allGaitCycles{i-1,6}

 
        
    %%**************************************************************************       
    %% For all gait cycles 
    %%**************************************************************************   
    
%        [StructC3D,StructGC,StructNaNKinetic] = f_load_GC(StructC3D,allGaitCycles(i,:),MarkersC3D,StructNaNKinetic,Params4_c3d);
       %[out_GC,StructC3D,StructGC,StructNaNKinetic] = f_load_GC(StructC3D,allGaitCycles(i,:),MarkersC3D,StructNaNKinetic,LLegLength,RLegLength);
       [out_GC,StructC3D,StructGC,StructNaNKinetic] = f_load_GC_UKBBfrom2015(StructC3D,allGaitCycles(i,:),MarkersC3D,StructNaNKinetic,LLegLength,RLegLength,EMG_recorded);
       out = out * out_GC;
       if out_GC == 1
           StructAllC3D.(['trial_',num2str(allGaitCycles{i,6})]) = StructNaNKinetic;

           if strcmp(allGaitCycles{i,2},'left') == 1;
              Side = 'L';
           else Side = 'R';
           end

           KMP = strsplit(allGaitCycles{i,1},'_');% '_' or '.'
           
           StructAllGC.([KMP{1,1},'_',Side,num2str(allGaitCycles{i,3}(3)),'_GC',num2str(allGaitCycles{i,7}),'_ST',num2str(allGaitCycles{i,5})]) = StructGC;

           Trials{i,1} = [KMP{1,1},'_',Side,num2str(allGaitCycles{i,3}(3)),'_GC',num2str(allGaitCycles{i,7}),'_ST',num2str(allGaitCycles{i,5})];
           TrialNamePlot{i,1} = [KMP{1,1},'.GC',num2str(allGaitCycles{i,7}),'.ST',num2str(allGaitCycles{i,5})];
       end
       
    end % FOR i = 1:size(allGaitCycles,1)

    if ~out
        DataForCalc=struct;
        return
    end
    
    disp('  ');
    disp('Code of "StructAllGC": Kinetik good or not (K/N), _ Number of c3d _ Side of gait cycle (L/R), number of force plate that was hit _ number of gait cycle within this trial _ number of step within this trial')
    disp('  ');

    
    
    %%**************************************************************************       
       %% built a matrix for each parameter with each trial in a column
    %%**************************************************************************   
    
    Fieldnames2 = fieldnames(StructAllGC);

       for j = 1:size(Fieldnames2,1)
           Fieldnames3 = fieldnames(StructAllGC.(Fieldnames2{j,:}));

           for jj = 2:size(Fieldnames3,1) %starting from 2, as 1 = PIGunnormalised and it's not necessary/possible
               Fieldnames4 = fieldnames(StructAllGC.(Fieldnames2{j,:}).(Fieldnames3{jj,:}));

               for jjj = 1:size(Fieldnames4,1)%8 
                   Fieldnames5 = fieldnames(StructAllGC.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}));

                   for jjjj = 1:size(Fieldnames5,1)
                       Fieldnames6 = fieldnames(StructAllGC.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}));
%                         Fieldnames6 = {'TOE','HEE'};
                       for jjjjj = 1:size(Fieldnames6,1)   
                           DataForCalc.(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:}).Left(:,j) = ...
                                      StructAllGC.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:}).Left;
                           DataForCalc.(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:}).Right(:,j) = ...
                                      StructAllGC.(Fieldnames2{j,:}).(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:}).Right;
                            
                           SGC = strsplit(Fieldnames2{j,1},'_');
                           if  strcmp(SGC{1,2}(1,1),'L') %if it is a left gait cycle
                              DataForCalc.(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:}).Right(:,j) = NaN;
                           else DataForCalc.(Fieldnames3{jj,:}).(Fieldnames4{jjj,:}).(Fieldnames5{jjjj,:}).(Fieldnames6{jjjjj,:}).Left(:,j) = NaN;                              
                           end %IF it is a left gait cycle      
                                                                   
                       end %FOR jjjjj = = 1:size(Fieldnames6,1)                      
                   end %FOR jjjj = 1:size(Fieldnames5,1)
               end %FOR jjj = 1:size(Fieldnames4,1)
           end %FOR jj = 1:size(Fieldnames3,1)
        end %FOR Fieldnames2 = fieldnames(StructAllGC);

    clearvars j* Fieldnames*
  
    
    
    %%**************************************************************************     
      %% Check wrist angle with "f_check_WristAngle"
    %%************************************************************************** 
    
    out = f_check_WristAngle(DataForCalc.PIGnormalised_100.Angle.Transversal.Wrist,...
              allGaitCycles(:,1));
                   

end %FUNCTION
