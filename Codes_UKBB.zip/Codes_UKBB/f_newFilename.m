%{ 
*********************************************************************************
Function "f_newFilename" linked to funktion "f_newFlename"
            by Katrin Schweizer Nov. 2013
       adapted by Marie Freslier Mar. 2017
*********************************************************************************

Creat new filenames to copy c3d-files to endserver "L"

INPUT: trial_infos = infos about the trial (name, type, if kinetic is)

OUTPUT: Filename_copyTo = e.g. "K7.c3d" if kinetic was good for one or more forceplate,
                               N7.c3d = no kinetics, 
                               static.c3d = if it is a static trial
                               Rennen7 or Orthese7
%}

function Filename_copyTo = f_newFilename(trial_infos)

    ID_trial = regexp(trial_infos.filename,'(\d)+','match'); % extracts ID-Nr and trial-nr.
                     %e.g.  '3456'   '03'  in string
    trial_Nr = str2double(ID_trial(1,2)); % Trial-Nr. in double
         
    switch trial_infos.Processed
        case 'static'
            Filename_copyTo = 'static';
        case 'vid_running'
            Filename_copyTo = ['Rennen',num2str(trial_Nr)];
        case 'vid_orthosis'
            Filename_copyTo = ['Orthese',num2str(trial_Nr)];
        otherwise
            switch trial_infos.kinetic{1,1}
                case 'none'
                    Filename_copyTo = ['N',num2str(trial_Nr)];
                otherwise
                Filename_copyTo = ['K',num2str(trial_Nr)];
            end
    end % SWITCH Kinetik

end % FUNCTION