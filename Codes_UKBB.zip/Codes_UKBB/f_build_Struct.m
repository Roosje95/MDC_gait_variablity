%{
 *********************************************************************************
      Function "f_build_Struct" linked to script "Auswertung_mitFormularen"
                        run from "f_load_c3d"
                    by Katrin Schweizer Dez. 2013
*********************************************************************************

Creates struct {Measure}.{Plane}.{Joint}.{Side} (e.g Angles.Sagittal.Knee.Left)

INPUT: data = e.g. Markers/Angles/Moments... in struct as derived by c3d   
       namefield2 = name for second field in end-struct (e.g. 'Marker')
       NewNameEMG = three-column cell 1. column is the original name in the c3d "Analog -> Descriptions" e.g. 'EMG1',
                                      2. column is the channel as numbered by matlab e.g. 'v1'
                                      3. column is the side and muscle name e.g. 'RGastrocMed'

OUTPUT: structData = {Measure}.{Plane}.{Joint}.{Side} (e.g Angles.Sagittal.Knee.Left)

%}

function [structData] = f_build_Struct(data,namefield2,NewNameEMG)

     Fields = fieldnames(data); % names of input struct (e.g. SACR,RASI,...)
     
     %****/
     structData = struct;
     %****/
     %% We want the EMG data only, so all other fields are not needed
     % if the imput is EMG, we don�t need all analog data, therefore the
     % fieldnames of Analog are replaced by the EMG fieldnames
     
     if strcmp(namefield2,'EMG')
        for i = 1:size(Fields,1) 
            a = strsplit(Fields{i,1},'_');
            [noEMG(i,1)] = ~strcmp('EMG',a(1,1));
        end
        Fields(noEMG,:) = [];
     end %IF strcmp(namefield2,'EMG')
     
     
     %% Loop over all fields in struct from c3d
     
     for i = 1:size(Fields,1)
    
         namefield4 = regexprep(Fields{i,:}(2:end),[namefield2,'s'],''); %name for parameter with the side excluded (e.g. FIN,WRA...)
         namefield4 = regexprep(namefield4,namefield2,''); %name for parameter (e.g. SACR,FIN,...)
         
         namefield5 = Fields{i,:}(1); % Body side (e.g. L/R)
        
         dataForStruct = data.(Fields{i,:}); % the current data, endfield of input struct
         
         
     %% For angles
     
         if strcmp(namefield2,'Angle') %define fields for angles 
            namefield3 = {'Sagittal','Coronal','Transversal'}';
            
            %For the wrist (unlike all other angles) the flexion/extension
            %is in the second column and the ab/adductin in the first 
            % --> is corrected here
            if strcmp(namefield4,'Wrist')
               dataForStruct = dataForStruct(:,[2,1,3]);
            end
    
            
     %% For moments

         elseif strcmp(namefield2,'Moment') %define fields for moments
            namefield3 = {'Sagittal','Coronal','Transversal'}';
            
        
     %% For power     

         elseif strcmp(namefield2,'Power') %define fields for powers
            namefield3 = {'Multiplane'}'; 
            dataForStruct = dataForStruct(:,3); % only the third column contains data
                                                %--> keep only this column
          
            
     %% For marker  

         elseif strcmp(namefield2,'Marker') %define fields for markers
            namefield3 = {'AP','Lateral','Vertical'}'; 

            
     %% For forces     

         elseif strcmp(namefield2,'Force') %define fields for forces
            namefield3 = {'AP','Lateral','Vertical'}';

            
     %% For EMG

          elseif strcmp(namefield2,'EMG') %define fields for EMG

             namefield3 = {'InVolt','InVolt','InVolt','InVolt','InVolt','InVolt',...
                           'InVolt','InVolt','InVolt','InVolt','InVolt','InVolt',}';
          
             namefield4 = Fields{i,1}(6:end);%NewNameEMG{i,2}(6:end); % Muscle name (e.g. GastrocnemiusMed)
             namefield5 = Fields{i,1}(5); % Body side (e.g. L/R)
             
              
     %% For Gait Parameter

         elseif strcmp(namefield2,'GaitParam') %define fields for gait parameter

            namefield3 = {'Dummy'}';
                         
            if namefield5 == 'L';%strcmp(namefield5,'L')                         
               namefield4 = regexprep(namefield4,'eft_','');
            elseif namefield5 == 'R'; %strcmp(namefield5,'R')                         
               namefield4 = regexprep(namefield4,'ight_','');
            end %IF namefield5 == 'L';
            
            
     %% For events

         elseif strcmp(namefield2,'Events') %define fields for events
           
            if ~isempty(findstr(namefield4,'Strike'))
               namefield4 = 'FootStrike';
            elseif ~isempty(findstr(namefield4,'Off'))
                namefield4 = 'FootOff';
            else namefield4 = 'GeneralEvent';
            end %IF ~isempty(findstr(namefield4,'Strike'))
       
            namefield3 = {'InSeconds','InSeconds'}';
            dataForStruct = dataForStruct';

         end %IF strcmp(namefield2,'Angle')

         
        %% Write struct

         for j = 1:size(dataForStruct,2)
           
             if namefield5 == 'L'; %strcmp(namefield5,'L') %for the left side
                structData.(namefield2).(namefield3{j,:}).(namefield4).('Left') = dataForStruct(:,j);
                
             elseif namefield5 == 'R'; %strcmp(namefield5,'R') %for the right side
                structData.(namefield2).(namefield3{j,:}).(namefield4).('Right') = dataForStruct(:,j);
                
             elseif sum(namefield5 == 'GeneralEvent')>0; %if general event
                structData.(namefield2).(namefield3{j,:}).(namefield4).('General') = dataForStruct(:,j); 
                
             else %for markers that belong to both sides (e.g. CLAV)  
                structData.(namefield2).(namefield3{j,:}).([namefield5,namefield4]).('Left') = dataForStruct(:,j);
                structData.(namefield2).(namefield3{j,:}).([namefield5,namefield4]).('Right') = dataForStruct(:,j);
                
             end %IF strcmp(namefield5,'L')
             
         end %FOR j = 1:size(dataForStruct,2)
         
     end %FOR i = 1:size(Fields,1)    
 
     %***/
     if ~isempty(fieldnames(structData)) && strcmp(namefield2,'EMG') %***/
        MuslceNames = fieldnames(structData.EMG.InVolt);
        for i = 1:size(MuslceNames,1)
            Sides = fieldnames(structData.EMG.InVolt.(MuslceNames{i,1}));
            if size(Sides,1) < 2
               if strcmp(Sides{1,1},'Left')
                  structData.EMG.InVolt.(MuslceNames{i,1}).('Right') = NaN(size(structData.EMG.InVolt.(MuslceNames{i,1}).Left));
               else structData.EMG.InVolt.(MuslceNames{i,1}).('Left') = NaN(size(structData.EMG.InVolt.(MuslceNames{i,1}).Right));
               end %IF strcmp(Sides{1,1},'Left')
            end %IF size(Sides,1) < 2                      
        end %FOR i = 1:size(fieldnames(struct.EMG.InVolt),1)
     end %IF strcmp(namefield2,'EMG')
     
end %Function f_builtStruct