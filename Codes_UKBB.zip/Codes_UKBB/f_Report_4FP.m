%{ 
*********************************************************************************
            Function "f_Report" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer Dez. 2013
*********************************************************************************

Plots the control group in a grey band, the left side of the patients in a
continous line (red), the right side in a dashed line (blue). It also plots the foot-off
of the patients in horizontal line.
The plots are scaled to 0-100% of a gait cycle on the x-achsis and 
to +/- 1% above/below the maximum/minimum of the data

INPUT
  PA_data = Data of patients from struct (e.g. "DataForCalc.PIGnormalised_101.Angle")
  Title = Titel for plot (e.g. "Consistency plots Joint rotation angles - Upper body")
  CG_RangeLB = Lower bound of control goup data
  CG_RangeUB = Upper bound of control goup data
  Subtitle = Titles for subplots (e.g. "Spine tilt")
  name_Y = Names for Y-Axis (e.g. "post  degrees  ant")
  DataName = Names of fields to get the data (e.g. "Angle,Sagittal,Spine")
  rows_subplot = number of rows for subplots
  YLim = the standard y-axis-limits (e.g. [-10 10]
  XTICK = [1 21 41 61 81 101]
  XTICKLABEL = X-Axis lables{'0','20','40','60','80','100'}
  Color_band = Color for band of controls
  FootOff_Left = Left foot off for patients
  FootOff_Right = Right foot off for patients
  TrialStr = = Cell with name of trial that are plotted {'L4',R5'}
  Color_Left/Color_Right = Colour for the left/right (red/blue) side of the curves
  LineWidth_side1/LineWidth_side2 = Line width for the curves
  columnRepTrial_left/columnRepTrial_right = Column in which the representative Trial
                                             is found in the matrix
  PageNum = actual page number for report

OUTPUT
  PageNum = new actual page number for report
%}

function PageNum = f_Report_4FP(PA_data,Title,CG_RangeLB,CG_RangeUB,...
                            Subtitle,name_Y,DataName,rows_subplot,...
                            YLim,XTICK,XTICKLABEL,Color_band,FootOff_Left,...
                            FootOff_Right,TrialStr,Color_Left,Color_Right,...
                            LineWidth_side1,LineWidth_side2,columnRepTrial_left,...
                            columnRepTrial_right,PageNum)                          


   DataGood_L = sum(~isnan(PA_data.(DataName{1,1}).(DataName{1,2}).(DataName{1,3}).Left(1,:)));
   DataGood_R = sum(~isnan(PA_data.(DataName{1,1}).(DataName{1,2}).(DataName{1,3}).Right(1,:)));
   
   %if there are data either for the left or the right side 
   if DataGood_L >= 1 || DataGood_R >= 1 
       
      % Predefine figure
      Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                   'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                   'PaperPosition', [0.5,1,20.48,27.68]); %'PaperPosition', [0.5,0,20.48,28.18]);  
     
      annotation(Fig,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
                 'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                 'VerticalAlignment','middle','LineStyle','none'); %Title
      annotation(Fig,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
                 'FontSize',11,'FitBoxToText','off','LineStyle','none',...
                 'VerticalAlignment','middle','HorizontalAlignment','right'); %Patient ID
      
          
      LineWidth_side1 = LineWidth_side1(columnRepTrial_left,1);
      LineWidth_side2 = LineWidth_side2(columnRepTrial_right,1);      
       
      LeFootOff_repTrial = FootOff_Left(1,columnRepTrial_left);
      RiFootOff_repTrial = FootOff_Right(1,columnRepTrial_right);
      
      for i = 1:size(DataName,1)

          PA_Left = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Left(:,columnRepTrial_left);
          PA_Right = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Right(:,columnRepTrial_right);
       
          CG_LB = CG_RangeLB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
          CG_UB = CG_RangeUB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});   
          
          % for the last three subplots X-Achsis lable is Gait cycle
          if i > size(DataName,1)-3
             name_X = '% gait cycle';
          else
             name_X = '';
          end %i > size(DataName,1)-3
          
          
          %% Use "f_plotData" to plot the data
          
          figure(Fig)
          subplot(rows_subplot,3,i)
          
          f_plotData(CG_LB,CG_UB,PA_Left,PA_Right,Subtitle{i,1},name_Y{i,1},name_X,...
                     Color_band,YLim(i,:),XTICK,XTICKLABEL,LeFootOff_repTrial,RiFootOff_repTrial,...
                     Color_Left,Color_Right,LineWidth_side1,LineWidth_side2)                    

      end %FOR i = 1:size(DataName,1)

           
      %% Make legend
      TrialStr = strrep(TrialStr, '_', '.');
      Legend{1,:} = ['Left (' TrialStr{columnRepTrial_left,1} ')'];
      Legend{2,:} = ['Right (' TrialStr{columnRepTrial_right,1} ')'];

      if size(DataName,1) == 15;
         legend(Legend ,'Orientation','horizontal','Position',[0.3429 0.03 0.3663 0.02553]);%[0.3429 0.04362 0.3663 0.02553])
      else 
         legend(Legend ,'Orientation','horizontal','Position',[0.3429 0.24 0.3663 0.02553])
      end %IF rows_subplot == 3;
      set(legend,'Box','off')
      

      %% Page Number
      
      f_makeTextbox(Fig,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
      PageNum = PageNum + 1;

   
   end %IF DataGood >= 1

end %FUNCTION