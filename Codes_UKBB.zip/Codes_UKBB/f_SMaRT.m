%{
*********************************************************************************
Function "f_SMaRT" linked to script "Auswertung_mitFormularen"
            by Katrin Schweizer Feb. 2014
*********************************************************************************

Selection method to find a representative trial (SMaRT) according to 
Schweizer K. J Biomech. 2012 Aug 31;45(13):2306-9
 
            
INPUT: data = dataPCA:[number_of_datapoints x number_of_features x number_of_trials]

OUTPUT: repTrial_nr = Trial number of the representative trial as found in 3rd
                      dimension of original data
        sort_dist = Matrix with euclidean distances in first column and rows of trials in second
%}

function [rowRepTrial_nr,sort_dist] = f_SMaRT(data)

testNaN = isnan(data); %search for NaN in data
sumNaN = sum(testNaN,1); %calculate sum across n data points
searchNaNTrial = sum(sumNaN,2); %sum across n parameters
% NaNTrial = find(searchNaNTrial > 0); %if there are any NaN in the                                            %
NaNTrial = searchNaNTrial > 0; %if there are any NaN in the data sum will be larger than 0

data(:,:,NaNTrial) = []; %cut the trial with NaN for PCA

RowTrialNr = find(searchNaNTrial(:) == 0); %numbers the trials across 3rd 
                 %dimension of data & cut the trial number with NaN for PCA


%predefine matrix
EuclDist = NaN(size(data,3),1);
 
%% For all features
number_of_features = size(data,2);
 
  for k = 1 : number_of_features
      
     %% apply principal component analysis (PCA)

      [~,pcScores] = pca(squeeze(data(:,k,:))');
        %pcScores = PC-scores; Number_of_Trials x (Number_of_Trials-1)

     %% calculate median of PC-scores
 
        MedScores = median(pcScores,1); %median across columns of pcScores
    
     %% calculation of Euclidean distance of PC-scores to median score
        squareDist = (pcScores - (repmat(MedScores,size(pcScores,1),1))).^2;
 
        EuclDist(:,k) = sqrt(sum(squareDist,2)); % calculate Euclidean distance 
                           % between median and PC-scores (y=trials, x=angles) 
         
 
  end %FOR k = 1 : number_of_features
 
%% sort
 
sum_dist = nansum(EuclDist,2); %sum distances across angles
sum_dist(:,2) = RowTrialNr; %write trial number in second column
sort_dist = sortrows(sum_dist); %arrange trials according to distances in decreasing order

%% number of the representative trial for output

rowRepTrial_nr = sort_dist(1,2); %shows the number of the representative trial

   
 
 


