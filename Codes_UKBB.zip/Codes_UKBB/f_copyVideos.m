function out = f_copyVideos(Path_data,Path_new,patName_new,trials_infos)
%{
adapted from f_copyVideos() from K. Schweizer
by M. Freslier, Mar 2017

copy the needed videos in the temporary folder:
- static, dynamic and running trials: videos of both sides
(frontal&sagittal)
- orthosis trial: only video from sagittal side

actuel (for Nexus2.5): ID frontal = '.63867199'
                       ID sagittal = '.61030208'

INPUT
    Path_data = path where the original data are saved
    patName = name of the original data
    Path_new = path where the data are to be copied
    patName_new = name of the new data
    trials_infos = struct of the information of the trials, fields are
        filename, Processed (='static','vid_running','vid_orthosis' or
        'dynamic'), kinetic, newName

OUTPUT
    out = 1 if all ok, 0 if there is a problem to copy some file (main 
    script will be stopped)
%}
out =1 ;

vidID_frontal = '.63867199';
vidID_sagittal = '.61030208';

for trialNumber = 1:length(trials_infos)
    % look for the video files for this trial
    Frontal = dir([Path_data,'\',trials_infos(trialNumber).filename,...
        vidID_frontal,'*.avi']);
    Sagittal = dir([Path_data,'\',trials_infos(trialNumber).filename,...
        vidID_sagittal,'*.avi']);
    
    switch trials_infos(trialNumber).Processed
        case {'static','dynamic'}
            % Copy and rename videos
            if ~isempty(Frontal)
                [status,message] = copyfile([Path_data,'\',Frontal.name],...
                    [Path_new,'\',trials_infos(trialNumber).newName,'_',patName_new,'_AP.avi']);
                out = out*status;
                if ~status
                    disp(' ');
                    disp('!!! error in f_copyVideos: !!!');
                    disp(['!!! ',Frontal.name,' couldn''t be copied: ' message ' !!!']);
                end
            else
                disp(' ');
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                disp(['No frontal video available for file ',trials_infos(trialNumber).filename])
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            end %IF ~isempty(Frontal)

            if ~isempty(Sagittal)
                [status,message] = copyfile([Path_data,'\',Sagittal.name],...
                    [Path_new,'\',trials_infos(trialNumber).newName,'_',patName_new,'_Sagittal.avi']);
                out = out*status;
                if ~status
                    disp(' ');
                    disp('!!! error in f_copyVideos: !!!');
                    disp(['!!! ',Sagittal.name,' couldn''t be copied: ' message ' !!!']);
                end
            else
                disp(' ');
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                disp(['No sagittal video available for file ',trials_infos(trialNumber).filename])
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            end %IF ~isempty(Sagittal)
            
        case 'vid_running'
            if ~isempty(Frontal)
                [status,message] = copyfile([Path_data,'\',Frontal.name],...
                    [Path_new,'\',trials_infos(trialNumber).newName,'_',patName_new,'_AP.avi']);
                out = out*status;
                if ~status
                    disp(' ');
                    disp('!!! error in f_copyVideos: !!!');
                    disp(['!!! ',Frontal.name,' couldn''t be copied: ' message ' !!!']);
                end
            else
                disp(' ');
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                disp(['No frontal video available for file ',trials_infos(trialNumber).filename])
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            end %IF ~isempty(Frontal)
            
            if ~isempty(Sagittal)
                [status,message] = copyfile([Path_data,'\',Sagittal.name],...
                    [Path_new,'\',trials_infos(trialNumber).newName,'_',patName_new,'_Sagittal.avi']);
                out = out*status;
                if ~status
                    disp(' ');
                    disp('!!! error in f_copyVideos: !!!');
                    disp(['!!! ',Sagittal.name,' couldn''t be copied: ' message ' !!!']);
                end
            else
                disp(' ');
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                disp(['No Sagittal video available for file ',trials_infos(trialNumber).filename])
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            end %IF ~isempty(Sagittal)
        case 'vid_orthosis'
            if ~isempty(Sagittal)
                [status,message] = copyfile([Path_data,'\',Sagittal.name],...
                    [Path_new,'\',trials_infos(trialNumber).newName,'_',patName_new,'_Sagittal.avi']);
                out = out*status;
                if ~status
                    disp(' ');
                    disp('!!! error in f_copyVideos: !!!');
                    disp(['!!! ',Sagittal.name,' couldn''t be copied: ' message ' !!!']);
                end
            else
                disp(' ');
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                disp(['No Sagittal video available for file ',trials_infos(trialNumber).filename])
                disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            end %IF ~isempty(Sagittal)
    end % switch trials_infos(trialNumber).Processed
end % for trialNumber = 1:length(trials_infos)















