%{ 
 Script for the analysis of routine measurements


 0) Select measure folder
 1) Extract informations from �Messprotokoll� and clinical examination,
 extract information on EMG
 2) Extract infos which trials were processed and where kinetic is good from enf-files
 3) Create new patient folder in end server "L" & copy, rename videos
 4) copy, rename c3d-files, mp & vsk files
    for static file write informations in c3d about the position of the subject
    Rename EMG channels in c3d with muscle names (in Analog data)
    Write clinical data (RoM, Strength testing...) to c3d
    Write marker diameter to c3d (POINT > DESCRIPTIONS)
 5) set the general events for the clean force plate (only for trials with
 kinetic) in the c3d
 6) check the informations about the gait cycles
 7) define the gait cycles that are taken for the PiG analysis
 8) write infos on kinetic to parameters.mat and save it

List of functions:

f_whichEMG (1)
f_extractTrials (2)
    - f_checkKinetic
    - f_newFilename
f_copyVideos (3)
f_copyFiles (4)
    - f_renameEMG_c3d
    - f_write_StaticInfo
    - f_clinic2_c3d
    - f_extractMarkerDiameter
    - f_Marker2_c3d
f_defineGaitCycles (5)
f_collect_gaitCycles_Kinetics (6)
f_collect_gaitCycles_NoKinetics (6)
f_checkGaitCycles_FootKin (7)
f_checkGaitCycles (7)

Adaptations
August 2018 - Rosa Visscher - Adapted to ETH use
%}
%% define work path
clear
Path_AuswertungETH = 'P:\Projects\NCM\NCM_CP\Codes\script_basel';
cd(Path_AuswertungETH);
Path_BenoetigteDateien = [Path_AuswertungETH,'\BenoetigteDateien']; %path to excel template and logo
Path_analysisTemp = [Path_AuswertungETH,'\tempAnalysis']; % temporary save of the analysed data
dbstop if error
% Turn warnings off
warning('off','MATLAB:interp1:NaNinY')

%% define paths for analysis
Path_measurements = ('\\green-lmb.ethz.ch\green_groups_lmb_public\Projects\NCM\NCM_CP\Data\UKBB_Gait_from2015\processedData_from2015');
Path_Final = '\\green-lmb.ethz.ch\green_groups_lmb_public\Projects\NCM\NCM_CP\Data\Analysed_UKBB_Gait_from2015';

%% Select patient folder
Path_Patientfolder = uigetdir(Path_measurements);
if ~Path_Patientfolder
    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
    % stop the script execution
    return
end
pathDetailed = strsplit(Path_Patientfolder,'\');
PatientFolder = pathDetailed{size(pathDetailed,2)};

clear pathDetailed
%% define name of analysed data (temporary folder)
PatientFolder_temp = lower(PatientFolder);
Path_PatientFolder_temp = [Path_analysisTemp '\' PatientFolder_temp];

%% Load database data (parameter.mat file)
Params4_c3d = importdata([Path_Patientfolder '\' PatientFolder '_parameters.mat']);
[NewNameEMG,Titel_EMG,Param_EMG,EMG_recorded] = f_whichEMG(Params4_c3d);

%% search for to analysed trials (.enf files)
[out,trials_infos,Params4_c3d] = f_extractTrials(Path_Patientfolder,Params4_c3d);
if ~out % if out == 0
    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
    % stop the script execution
    return
else clear out
end
% same trial several times in the list ?
doubles = 1;
for j=1:(size(trials_infos,2)-1)
    if strcmp(trials_infos(j).filename,trials_infos(j+1).filename)
        fileInDouble{doubles} = trials_infos(j).filename;
        doubles = doubles + 1;
    end
end
if doubles > 1 % one or more files are found in two copies
    disp(' ');
    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    disp('!!! error in Analysis_clinic: !!!');
    disp('For the following trials two .enf files were found.')
    disp('Please remove the wrong .enf file and relaunch the script.')
    for k = 1:size(fileInDouble,2)
        disp(['    ' fileInDouble{k}])
    end
    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
    % stop the script execution
    return
else clear doubles j
end

%% copy the files (.avi,.c3d,.vsk,.mp) in a the temporary folder
if isempty(dir(Path_PatientFolder_temp))
    mkdir(Path_PatientFolder_temp) %make a folder
else %if the patient folder already exists
    delete([Path_PatientFolder_temp,'\*.*'])
end
%%% mat file with parameters %%%
[status,message] = copyfile([Path_Patientfolder '\' PatientFolder '_parameters.mat'],...
         [Path_PatientFolder_temp,'\' PatientFolder_temp '_parameters.mat']); 
if status
    disp(' ');
    disp('--- mat file copied ---');
else
    disp(' ');
    disp('!!! error in Analysis_clinic: !!!');
    disp(['!!! mat file couldn''t be copied: ' message ' !!!']);
    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
    return
end
clear status message

% If only video and no kinematic/kinetic data => vsk&mp&c3d files don't copied
if strcmp(Params4_c3d.Meas_Type_1,'Video') && isempty(Params4_c3d.Meas_Type_2) 
    VideoOnly = 1;   
else
    VideoOnly = 0;
end

%%% avi files %%%
out_copy = f_copyVideos(Path_Patientfolder,Path_PatientFolder_temp,...
    PatientFolder_temp,trials_infos);
if ~out_copy
    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
    disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
    return
else clear out_copy
end

%%% copy vsk,mp,c3d files %%%
% replace also EMG names in c3d
if ~VideoOnly % data with kinematic/kinetic
    [out_copy,trials_infos,TibiaTorsion_static] = f_copyFiles(Path_Patientfolder,PatientFolder,...
        Path_PatientFolder_temp,PatientFolder_temp,trials_infos,Params4_c3d);
    if ~out_copy
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    end

    %% set the general events for the clean force plate (only for trials with kinetic)
    out_defGaitCycles = f_defineGaitCycles(Path_PatientFolder_temp,trials_infos);
    if ~out_defGaitCycles
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else clear out_defGaitCycles
    end

    %% from the files saved in temporary folder, hold the informations about kinetic
    list_c3dFiles = dir([Path_PatientFolder_temp,'\*.c3d']);
    fileTypeOK = 1;
    for files = 1:length(list_c3dFiles)
        c3d_infos(files).filename = list_c3dFiles(files).name;
        switch list_c3dFiles(files).name(1)
            case 's'
                c3d_infos(files).Processed = 'static';
            case 'N'
                c3d_infos(files).Processed = 'NoKinetics';
            case 'K'
                 c3d_infos(files).Processed = 'Kinetics';
            otherwise
                fileTypeOK = 0;
                disp(' ');
                disp(['!!! the type of the ' list_c3dFiles(files).name ...
                    ' trial is unknown. Please have a look. !!!']);
        end % switch list_c3dFiles(files).name(1)
    end
    if ~fileTypeOK
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else clear fileTypeOK files list_c3dFiles
    end

    %% for each c3d file in the list, check the informations about the gaitcycles
    out_collect = 1;
    disp(' ');
    for files = 1:length(c3d_infos)
        switch c3d_infos(files).Processed
            case 'Kinetics'
                c3d_acq = btkReadAcquisition([Path_PatientFolder_temp '\' c3d_infos(files).filename]);
                disp(['--- ' c3d_infos(files).filename ': extract gait cycles ---']);
                [out_collect_GC,c3d_infos(files).gaitcycles] = ...
                    f_collect_gaitCycles_Kinetics(c3d_acq);
                btkDeleteAcquisition(c3d_acq);
                out_collect = out_collect * out_collect_GC;
            case 'NoKinetics'
                c3d_acq = btkReadAcquisition([Path_PatientFolder_temp '\' c3d_infos(files).filename]);
                disp(['--- ' c3d_infos(files).filename ': extract gait cycles ---']);
                [out_collect_GC,c3d_infos(files).gaitcycles] = ...
                    f_collect_gaitCycles_NoKinetics(c3d_acq);
                btkDeleteAcquisition(c3d_acq);
                out_collect = out_collect * out_collect_GC;
        end
    end
    if ~out_collect
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else clear out_collect out_collect_GC files c3d_acq
    end

    %% list of all the gait cycles
    out_list = 1;
    [out_list,allGaitCycles] = f_GaitGycles_List(c3d_infos,EMG_recorded);
    if ~out_list
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else clear out_list
    end
    
    %% define the gait cycles that are taken for the PiG analysis
    % pour l'instant c'est bon pour les essais avec cin�tique
    % pour ceux sans cin�tique, on reste avec 2 cycles par fichier (L&R)
    % le but serait de pouvoir d�finir plusieurs cycles par fichier et de les
    % utiliser s�par�ment, mais je ne sais pas encore comment ce serait g�r�
    % par le programme de Katrin
    out_GCs = 1;
    if strcmp(Params4_c3d.Meas_Type_5,'Druckverteilung')
        [out_GCs,list_gc_selected,Kinetic_4orMore] = ...
            f_checkGaitCycles_FootKin(allGaitCycles);
    else
        [out_GCs,list_gc_selected,Kinetic_4orMore] = ...
            f_checkGaitCycles(allGaitCycles);
    end
    if ~out_GCs
        disp(' ');
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else clear out_GCs
    end

    %**************************************************************************
    %% build data structs
    %**************************************************************************
    [out_label,StructAllGC,StructAllC3D,DataForCalc,Trials,TrialNamePlot] = f_loadC3d_buildStructs...
                                                                (Path_PatientFolder_temp,list_gc_selected,EMG_recorded);
    if ~out_label
        disp(' ');
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else clear out_label
    end
    clear StructAllC3D
    
    %**************************************************************************
    %% Load norm data for plots
    %**************************************************************************
    CG_Mean = importdata([Path_BenoetigteDateien,'\CG_MeanStruct.mat']);
    CG_RangeLB = importdata([Path_BenoetigteDateien,'\CG_LB_1CI.mat']);
    CG_RangeCI = importdata([Path_BenoetigteDateien,'\CG_CI_struct.mat']);
    
    %**************************************************************************
    %% Variabel for plots
    %**************************************************************************
    XTICK = [1 20 40 60 80 100];
    XTICKLABEL = {'0','20','40','60','80','100'};

    Color_band = [0.8 0.8 0.8]; %color for norm data

    Color_Left = [0 0 0;0.875 0 0 ; 1 0.708 0; 0 0 1; 0 0.7619 0.6190;1 0 1;0.478 0.0627 0.8941;0 0.5 0;0.5 0.5 0.5;0.2 0.3 0.49;1 0.375 0;0.6 0.2 0];
    Color_Right = [0 0 0;0.875 0 0 ; 1 0.708 0; 0 0 1; 0 0.7619 0.6190;1 0 1;0.478 0.0627 0.8941;0 0.5 0;0.5 0.5 0.5;0.2 0.3 0.49;1 0.375 0;0.6 0.2 0];

    LineWidth_Left = ones(size(Trials,1),1)*2;
    LineWidth_Right = ones(size(Trials,1),1)*2;

    FootOff_Left = DataForCalc.PIGnormalised_100.GaitParam.Dummy.Foot_Off.Left; 
    FootOff_Right = DataForCalc.PIGnormalised_100.GaitParam.Dummy.Foot_Off.Right;
    
    %**************************************************************************
    %% Consistency
    %**************************************************************************
    %% Plot lower body angles
    Title = {['Consistency plots: Joint rotation angles - Lower body    ',PatientFolder_temp]};

    Titel_kinem_LB = {'Pelvic tilt';'Pelvic obliquity';'Pelvic rotation';...
                      'Hip flex/extension';'Hip add/abduction';'Hip rotation';...
                      'Knee flex/extension';'Knee varus/valgus';'Knee rotation';...
                      'Ankle dorsiflexion';'Tibia-Vertical varus';'Foot rotation';...
                      'Foot-Floor angle';'Tibia-Vertical sagittal tilt';'Foot progression'};

    name_Y_kinem_LB = {'post  [�]  ant';'down  [�]  up';'ext   [�]   int';...
                       'ext   [�]   flex';'abd   [�]   add';'ext   [�]   int';...
                       'ext   [�]   flex';'val   [�]   var';'ext   [�]   int';...
                       'plan   [�]   dors';'val   [�]   var';'ext   [�]   int';...
                       'plan   [�]   dors';'post  [�]  ant';'ext   [�]   int'};

    Ylim_kinem_LB = [-10 30;-20 20;-30 30;-20 80;-30 30;-30 30;...
                     -10 80;-20 20;-20 30;-50 40; -15 15; -45 45;...
                     -100 30; -30 70; -30 45];

    Angles_LB = {'Angle','Sagittal','Pelvis'; 'Angle','Coronal','Pelvis'; 'Angle','Transversal','Pelvis';...
                 'Angle','Sagittal','Hip'; 'Angle','Coronal','Hip'; 'Angle','Transversal','Hip';...
                 'Angle','Sagittal','Knee'; 'Angle','Coronal','Knee'; 'Angle','Transversal','Knee';...
                 'Angle','Sagittal','Ankle'; 'Angle','Coronal','Tibia'; 'Angle','Transversal','Ankle';...
                 'Angle','Sagittal','FootProgress'; 'Angle','Sagittal','Tibia'; 'Angle','Transversal','FootProgress'};

    lineSubplot_LB = 5;

    f_checkPlot_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                            CG_RangeCI.PIGnormalised_100,Titel_kinem_LB,name_Y_kinem_LB,Angles_LB,...
                            lineSubplot_LB,Ylim_kinem_LB,...
                            XTICK,XTICKLABEL,Color_band,FootOff_Left,...
                            FootOff_Right,TrialNamePlot,Color_Left,Color_Right,...
                            LineWidth_Left,LineWidth_Right)
                        
    %% Plot upper body kinematics
    Title = {['Consistency plots: Joint rotation angles - Upper body    ',PatientFolder_temp]};

    Titel_kinem_UB = {'Thorax tilt';'Thorax lateroflexion';'Thorax rotation';...
                      'Spine tilt';'Spine lateroflex.';'Spine rotation';...
                      'Shoulder flex/extension';'Shoulder abd/adduction';'Elbow flexion';...
                      'Wrist extension';'Wrist deviation';'Wrist rotation';...
                      'Head tilt';'Head lateroflexion';'Head rotation';...
                      'Neck tilt';'Neck lateroflexion';'Neck rotation'};

    name_Y_kinem_UB = {'post   [�]   ant';'ipsi  [�]  contra';'ext   [�]   int';...
                       'ext  [�]  flex';'contra  [�]  ipsi';'int   [�]   ext';...
                       'ext   [�]   flex';'add   [�]   abd';'ext   [�]   flex';...
                       'flex   [�]   ext';'radial [�]  ulnar';'sup   [�]   pro';...
                       'ext   [�]   flex';'contra  [�]  ipsi';'ext   [�]   int';...
                       'ext   [�]   flex';'contra  [�]  ipsi';'ext   [�]   int'};

    Ylim_kinem_UB = [-20 20;-10 10;-15 15;-40 30;-15 15;-15 15;...
                     -50 50;-10 40;-10 80;-10 50;-10 50;50 180;...
                     -20 50;-10 10;-20 20;-50 20;-20 20;-20 20];

    Angles_UB = {'Angle','Sagittal','Thorax';'Angle','Coronal','Thorax';'Angle','Transversal','Thorax';...
                 'Angle','Sagittal','Spine';'Angle','Coronal','Spine';'Angle','Transversal','Spine';...
                 'Angle','Sagittal','Shoulder';'Angle','Coronal','Shoulder';'Angle','Sagittal','Elbow';...
                 'Angle','Sagittal','Wrist';'Angle','Coronal','Wrist';'Angle','Transversal','Wrist';...
                 'Angle','Sagittal','Head';'Angle','Coronal','Head';'Angle','Transversal','Head';...             
                 'Angle','Sagittal','Neck';'Angle','Coronal','Neck';'Angle','Transversal','Neck'};

    lineSubplot_UB = 6;  

    f_checkPlot_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                            CG_RangeCI.PIGnormalised_100,Titel_kinem_UB,name_Y_kinem_UB,Angles_UB,...
                            lineSubplot_UB,Ylim_kinem_UB,XTICK,XTICKLABEL,Color_band,...
                            FootOff_Left,FootOff_Right,TrialNamePlot,Color_Left,Color_Right,...
                            LineWidth_Left,LineWidth_Right)
    
    %% Plot kinetic
    if sum(~isnan(DataForCalc.PIGnormalised_100.Moment.Sagittal.GroundReaction.Left(1,:))) > 0 %if NOT all trials are without kinetics  %NoKinetics ~= length(Kinetic) %if NOT all trials are without kinetics
       Title = {['Consistency plots: Kinetics    ',PatientFolder_temp]};

       Titel_kinet = {'Hip flexion moment';'Knee flexion moment';'Ankle dorsi. moment';...
                      'Total hip power';'Total knee power';'Total ankle power';...            
                      'GRF ant/post [%BW]';'GRF mediolateral [%BW]';'GRF vertical [%BW]'};

       name_Y_kinet = {'ext  [Nm/kg]  flex';'ext  [Nm/kg]  flex';'plant   [Nm/kg]   dorsi';...
                       'abs   [W/kg]   gen';'abs   [W/kg]   gen';'abs   [W/kg]   gen';...
                       'post   % body weight   ant';'lat  % body weight  med';'down   % body weight   up'};

       Ylim_kinet = [-1 2;-1 2;-1 2;-2 4;-2 4;-2 6;-28 28;-7 7;-15 125];

       Param_Kinetic = {'Moment','Sagittal','Hip';'Moment','Sagittal','Knee';'Moment','Sagittal','Ankle';...
                        'Power','Multiplane','Hip';'Power','Multiplane','Knee';'Power','Multiplane','Ankle';...
                        'Force','AP','NormalisedGRF';'Force','Lateral','NormalisedGRF';'Force','Vertical','NormalisedGRF'};
       lineSubplot_Kinet = 3;

       f_checkPlot_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                               CG_RangeCI.PIGnormalised_100,Titel_kinet,name_Y_kinet,Param_Kinetic,...
                               lineSubplot_Kinet,Ylim_kinet,XTICK,XTICKLABEL,Color_band,...
                               FootOff_Left,FootOff_Right,TrialNamePlot,Color_Left,Color_Right,...
                               LineWidth_Left,LineWidth_Right)
       clear name_Y_kinet lineSubplot_Kinet

    end %IF NoKinetics ~= length(Kinetic) %if NOT all trials are without kinetics                    

    %% Plot EMG
    if EMG_recorded == 'y' % if EMG was recorded 
       Title = {'Consistency EMG: 20-500Hz filtered & enveloped'};

       NumberMuscle = size(fieldnames(DataForCalc.PIGnormalised_100.EMG.mVolt),1);

       name_Y_EMG = repmat({'[mVolt]'},NumberMuscle,1);

       Param_EMGall = repmat({'EMG','mVolt'},NumberMuscle,1);
       Param_EMGall(:,3) = Param_EMG;

       Ylim_EMG = repmat([0 0.2],NumberMuscle,1);

       lineSubplot_EMG = 3;

       f_checkPlot_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                            CG_RangeCI.PIGnormalised_100,Titel_EMG,name_Y_EMG,Param_EMGall,...
                            lineSubplot_EMG,Ylim_EMG,XTICK,XTICKLABEL,Color_band,...
                            NaN(size(FootOff_Left)),NaN(size(FootOff_Right)),TrialNamePlot,Color_Left,Color_Right,...
                            LineWidth_Left,LineWidth_Right)  
       clear NumberMuscle Param_EMGall Ylim_EMG
    end %IF EMG_recorded ~= 0
    
    %% Ask for quality Consistency
    disp(' '); disp('Is consistency ok, do you want to continue')
    disp(' '); disp('No, stop script          -------->  0')
    disp(' '); disp('Yes, continue            -------->  ENTER')
    disp(' '); ConsistencyEval = input('Selection: ','s');
    ConsistencyEval = lower( ConsistencyEval); disp(' ')
    
    switch ConsistencyEval
        case {'0'}
            disp(' ');
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
            return
        case {''}  % if consistency is good continue
            close all
            
            %**************************************************************************     
            %% Choose representative trial (SMaRT)
            %**************************************************************************
            ParameterSMaRT = {'Angle','Sagittal','Hip';'Angle','Sagittal','Knee';'Angle','Sagittal','Ankle';
                              'Angle','Transversal','Ankle'};

            disp(['**********','Input SMaRT: Sag. ankle, knee, hip; Foot rotation','*********'])

            for i = 1:size(ParameterSMaRT,1)
                dataSMaRT_left(1:100,i,:) = DataForCalc.PIGnormalised_100.(ParameterSMaRT{i,1}).(ParameterSMaRT{i,2}).(ParameterSMaRT{i,3}).Left;
                dataSMaRT_right(101:200,i,:) = DataForCalc.PIGnormalised_100.(ParameterSMaRT{i,1}).(ParameterSMaRT{i,2}).(ParameterSMaRT{i,3}).Right;    
            end

            [rowRepTrial_left,sort_dist_left] = f_SMaRT(dataSMaRT_left);
            [rowRepTrial_right,sort_dist_right] = f_SMaRT(dataSMaRT_right);

            RepTrial_left = Trials{rowRepTrial_left};
            RepTrial_right = Trials{rowRepTrial_right};  

            %Trial names
            TrialsSMaRT_left = Trials(sort_dist_left(:,2),1)';
            TrialsSMaRT_right = Trials(sort_dist_right(:,2),1)';

            %Struct with rep trial PIG unnormalised
            PA_left = StructAllGC.(RepTrial_left).PIGunnormalised;
            PA_left.GaitParam = StructAllGC.(RepTrial_left).PIGnormalised_100.GaitParam;
            PA_right = StructAllGC.(RepTrial_right).PIGunnormalised;
            PA_right.GaitParam = StructAllGC.(RepTrial_right).PIGnormalised_100.GaitParam;

            RepTrialsName = {RepTrial_left,RepTrial_right};

            clear dataSMaRT_left dataSMaRT_right sort_dist_left sort_dist_right i
            
            %**************************************************************************
            %% Calculate basic statistics across all trials (Mean, standard deviation, 95% confidence intervall)
            %**************************************************************************    
            [MeanStruct,SD_struct,CI_struct] = f_calc_BasicStats(DataForCalc);

            clear SD_struct
            
            %**************************************************************************     
            %% plot clinic report
            %**************************************************************************    
            %% Create overview sheet for gaitlab folder
            %if there exists a "protocol.mat" in the current folder
            if ~isempty(dir([Path_Patientfolder,'\' PatientFolder '_protocol.mat']));
                Protocol = importdata([Path_Patientfolder,'\' PatientFolder '_protocol.mat']);
                f_OverviewProtocol(Protocol,TibiaTorsion_static)          
                isProtocol = 1;
            else
                isProtocol = 0;
            end
            clear Protocol
               
            %% Patient information (1st page)
            ID = ['ID: ',PatientFolder_temp];
            fig_firstPage = f_Report_firstPage_2017(Path_BenoetigteDateien,Params4_c3d,PatientFolder_temp);
 
            %% Clinical Measurements (2nd page)
            f_Report_clinicalTest(ID,Params4_c3d)
  
            %% Temporal parameters (3rd page)
            f_Report_TemporalParameters_4FP(DataForCalc.PIGnormalised_100.GaitParam.Dummy,...
                                            MeanStruct.PIGnormalised_100.GaitParam_nonDim.Dummy,...
                                            CI_struct.PIGnormalised_100.GaitParam_nonDim.Dummy,...
                                            CG_Mean.PIGnormalised_100,...
                                            CG_RangeCI.PIGnormalised_100,...
                                            rowRepTrial_left,rowRepTrial_right,ID,RepTrialsName)
                                        
            %% Lower body angles (4th page)
            Color_Left = repmat([1 0 0],length(Color_Left),1);
            Color_Right = repmat([0 0 1],length(Color_Right),1);

            LineWidth_Left = ones(size(Trials,1),1)*1;
            LineWidth_Right = ones(size(Trials,1),1)*1;

            LineWidth_Left(rowRepTrial_left) = 1.5;
            LineWidth_Right(rowRepTrial_right) = 1.5;

            PageNum = 4;

            Title = {'Representative trial: Joint rotation angles - Lower body',ID};

            PageNum = f_Report_4FP(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                               CG_RangeCI.PIGnormalised_100,Titel_kinem_LB,name_Y_kinem_LB,Angles_LB,...
                               lineSubplot_LB,Ylim_kinem_LB,XTICK,XTICKLABEL,Color_band,FootOff_Left,...
                               FootOff_Right,TrialNamePlot,Color_Left,Color_Right,...
                               LineWidth_Left,LineWidth_Right,rowRepTrial_left,...
                               rowRepTrial_right,PageNum);

            % Write tibia torsion into kinematic plot              
            annotation(gcf,'textbox',[0.678 0.24 0.198 0.027],'String',{'clinical Tibia torsion le/ri: '},...
            'FitBoxToText','off','EdgeColor','none','Color','k','FontSize',9);  %[0.69 0.041 0.165 0.027]                 
            annotation(gcf,'textbox',[0.853 0.24 0.05 0.027],'String',{[Params4_c3d.LTibialTorsion_Grad,'�/']},...%
            'FitBoxToText','off','EdgeColor','none','Color','r','FontSize',9,'FontWeight','bold');
            annotation(gcf,'textbox',[0.882 0.24 0.058 0.027],'String',{[Params4_c3d.RTibialTorsion_Grad,'�']},...%
            'FitBoxToText','off','EdgeColor','none','Color','b','FontSize',9,'FontWeight','bold');
    
            %% Sagittal plane kinetics (5th page)
            if sum(~isnan(DataForCalc.PIGnormalised_100.Moment.Sagittal.GroundReaction.Left(1,:))) > 0 %if NOT all trials are without kinetics
                Title = {'Representative trial: Sagittal kinematics, external moments, power',ID};

                Titel_kinet2 = {'Hip flex/extension';'Knee flex/extension';'Ankle dorsiflexion';...
                               'Hip flexion moment';'Knee flexion moment';'Ankle flexion moment';...
                               'Total hip power';'Total knee power';'Total ankle power'};

                name_Y_kinet2 = {'ext   [�]   flex';'ext   [�]   flex';'plan   [�]   dors';...
                                'ext  [Nm/kg]  flex';'ext  [Nm/kg]  flex';'plant   [Nm/kg]   dorsi';...
                                'abs   [W/kg]   gen';'abs   [W/kg]   gen';'abs   [W/kg]   gen'};

                Ylim_kinet2 = [-20 80;-10 80;-50 40;-1 2;-1 2;-1 2;-2 4;-2 4;-2 6];

                Param_Kinetic2 = {'Angle','Sagittal','Hip';'Angle','Sagittal','Knee';'Angle','Sagittal','Ankle';...
                                 'Moment','Sagittal','Hip';'Moment','Sagittal','Knee';'Moment','Sagittal','Ankle';...
                                 'Power','Multiplane','Hip';'Power','Multiplane','Knee';'Power','Multiplane','Ankle'};

                PageNum = f_Report_4FP(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                                         CG_RangeCI.PIGnormalised_100,Titel_kinet2,name_Y_kinet2,Param_Kinetic2,...
                                         lineSubplot_LB,Ylim_kinet2,XTICK,XTICKLABEL,Color_band,...
                                         FootOff_Left,FootOff_Right,TrialNamePlot,Color_Left,Color_Right,...
                                         LineWidth_Left,LineWidth_Right,rowRepTrial_left,rowRepTrial_right,...
                                         PageNum);
                clear Titel_kinet2 name_Y_kinet2 Ylim_kinet2 Param_Kinetic2
                
                %% Moments (6th page)
                Title = {'Representative trial: External joint moments',ID};

                Titel_moments = {'Hip flexion moment';'Hip adduction moment';'Hip rotation moment';
                                'Knee flexion moment';'Knee adduction moment';'Knee rotation moment';
                                'Ankle flexion moment';'Ankle adduction moment';'Ankle rotation moment'};

                name_Y_moments = {'ext  [Nm/kg]  flex';'abd  [Nm/kg]  add';'ext  [Nm/kg]  int';
                                 'ext  [Nm/kg]  flex';'val  [Nm/kg]  var';'ext  [Nm/kg]  int'
                                 'plant   [Nm/kg]   dorsi';'val  [Nm/kg]  var';'ext  [Nm/kg]  int'};

                Ylim_moments = [-1 2;-1 2;-0.5 0.5;-1 2;-1 2;-0.5 0.5;-1 2;-0.5 0.5;-0.5 0.5];

                Param_moments = {'Moment','Sagittal','Hip';'Moment','Coronal','Hip';'Moment','Transversal','Hip';
                                'Moment','Sagittal','Knee';'Moment','Coronal','Knee';'Moment','Transversal','Knee';
                                'Moment','Sagittal','Ankle';'Moment','Coronal','Ankle';'Moment','Transversal','Ankle'};

                PageNum = f_Report_4FP(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                              CG_RangeCI.PIGnormalised_100,Titel_moments,name_Y_moments,Param_moments,...
                              lineSubplot_LB,Ylim_moments,XTICK,XTICKLABEL,Color_band,...
                              FootOff_Left,FootOff_Right,TrialNamePlot,Color_Left,Color_Right,...
                              LineWidth_Left,LineWidth_Right,rowRepTrial_left,rowRepTrial_right,...
                              PageNum);
                clear Titel_moments name_Y_moments Ylim_moments Param_moments
            end %IF sum(~isnan(DataForCalc.PIGnormalised_100.Moment.Sagittal.GroundReaction.Left(1,:))) > 0 %if NOT all trials are without kinetics
            
            %% EMG data (7th page)
            % if EMG was recorded
            if EMG_recorded == 'y'
                CG_EMG = importdata([Path_BenoetigteDateien,'\CG_EMG.mat']);

                Title = {'Rep. trial: Electromyographic Activity (20-700Hz bandpass)',ID};

                lineSubplot_EMG = 4;

                PageNum = f_Report_EMG_4FP(PA_left,PA_right,Title,CG_EMG,Titel_EMG,name_Y_EMG,...
                                           Param_EMG,lineSubplot_EMG,Color_band,RepTrialsName,PageNum);
                clear CG_EMG lineSubplot_EMG
            end %IF EMG_recorded ~= 0

            %% Consistency for report
            % Lower body angles (8th page)
            LineWidth_Left(rowRepTrial_left) = 2.5;
            LineWidth_Right(rowRepTrial_right) = 2.5;

            Title = {'Consistency: Joint rotation angles - Lower body',ID};

            Titel_kinem_ReportLB = {'Pelvic tilt';'Hip flex/extension';'Knee flex/extension';'Ankle dorsiflexion';....
                              'Pelvic obliquity';'Hip add/abduction';'Knee varus/valgus';'Foot progression';
                              'Pelvic rotation';'Hip rotation';'Knee rotation';'Foot rotation'};

            name_Y_kinem_ReportLB = {'post [�] ant';'ext [�] flex';'ext [�] flex';'plan [�] dors';...
                               'down [�] up';'abd [�] add';'val [�] var';'ext [�] int';....
                               'ext [�] int';'ext [�] int';'ext [�] int';'ext [�] int'};    

            Ylim_kinem_ReportLB = [-10 30;-20 80;-10 80;-50 40;-20 20;-30 30;...
                                   -20 20;-30 45;-30 30;-30 30;-20 30;-45 45];           

            Angles_ReportLB = {'Angle','Sagittal','Pelvis';'Angle','Sagittal','Hip';'Angle','Sagittal','Knee';'Angle','Sagittal','Ankle';...
                         'Angle','Coronal','Pelvis'; 'Angle','Coronal','Hip';'Angle','Coronal','Knee';'Angle','Transversal','FootProgress';...
                         'Angle','Transversal','Pelvis';'Angle','Transversal','Hip';'Angle','Transversal','Knee';'Angle','Transversal','Ankle'};           

            lineSubplot_ReportLB = 6;  columnSubplot_LB = 4;
            PageNum = f_Report_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                                      CG_RangeCI.PIGnormalised_100,Titel_kinem_ReportLB,name_Y_kinem_ReportLB,Angles_ReportLB,...
                                      lineSubplot_ReportLB,columnSubplot_LB,Ylim_kinem_ReportLB,XTICK,XTICKLABEL,Color_band,FootOff_Left,...
                                      FootOff_Right,Color_Left,Color_Right,...
                                      LineWidth_Left,LineWidth_Right,PageNum);

            clear Titel_kinem_ReportLB name_Y_kinem_ReportLB Ylim_kinem_ReportLB Angles_ReportLB
            clear lineSubplot_ReportLB columnSubplot_LB
    
            % kinetic (9th page)
            if sum(~isnan(DataForCalc.PIGnormalised_100.Moment.Sagittal.GroundReaction.Left(1,:))) > 0 %if NOT all trials are without kinetics
               Title = {'Consistency:',ID};

               Titel_kinet = {'Foot-Floor angle';'Hip flexion moment';'Knee flexion moment';'Ankle dorsi. moment';...
                              'Tibia-Vertical sagittal tilt';'Total hip power';'Total knee power';'Total ankle power';...            
                              'Tibia-Vertical varus';'GRF ant/post [%BW]';'GRF mediolateral [%BW]';'GRF vertical [%BW]'};

               Ylim_kinet = [-100 30;-1 2;-1 2;-1 2;...
                             -30 70;-2 4;-2 4;-2 6;...
                             -15 15;-28 28;-7 7;-15 125];

               Param_Kinetic = {'Angle','Sagittal','FootProgress';'Moment','Sagittal','Hip';'Moment','Sagittal','Knee';'Moment','Sagittal','Ankle';...
                                'Angle','Sagittal','Tibia';'Power','Multiplane','Hip';'Power','Multiplane','Knee';'Power','Multiplane','Ankle';...
                                'Angle','Coronal','Tibia';'Force','AP','NormalisedGRF';'Force','Lateral','NormalisedGRF';'Force','Vertical','NormalisedGRF'};

               name_Y_kinetReport = {'plan    dors';'ext    flex';'ext    flex';'plant    dorsi';...
                                     'post    ant';'abs    gen';'abs    gen';'abs    gen';...
                                     'val    var';'post    ant';'med    lat';'down    up'};

               lineSubplot_KinetConsist = 6;  columnSubplot_Kinet = 4;

               PageNum = f_Report_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                                         CG_RangeCI.PIGnormalised_100,Titel_kinet,name_Y_kinetReport,Param_Kinetic,...
                                         lineSubplot_KinetConsist,columnSubplot_Kinet,Ylim_kinet,XTICK,XTICKLABEL,Color_band,...
                                         FootOff_Left,FootOff_Right,Color_Left,Color_Right,...
                                         LineWidth_Left,LineWidth_Right,PageNum);

               annotation(gcf,'textbox',[0.13 0.94 0.805 0.05],'String','Kinematics',...
                          'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                          'VerticalAlignment','middle','LineStyle','none'); %Title for figure
               annotation(gcf,'textbox',[0.56 0.94 0.805 0.05],'String','Kinetics',...
                          'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                          'VerticalAlignment','middle','LineStyle','none'); %Title for figure
               annotation(gcf,'line',[0.553 0.317],[0.96 0.96]);
               annotation(gcf,'line',[0.316 0.316],[0.96 0.94]);
               annotation(gcf,'line',[0.916 0.67],[0.96 0.96]);
               annotation(gcf,'line',[0.917 0.917],[0.96 0.94]);
            else
               Title = {'Consistency: Joint rotation angles - Lower body',ID};

               Titel_kinet = {'Foot-Floor angle';'Tibia-Vertical sagittal tilt';'Tibia-Vertical varus'};

               Ylim_kinet = [-100 30;-30 70;-15 15];

               Param_Kinetic = {'Angle','Sagittal','FootProgress';...
                                'Angle','Sagittal','Tibia';'Angle','Coronal','Tibia'};

               name_Y_kinetReport = {'plan    dors';'post    ant';'val    var'};

               lineSubplot_KinetConsist = 4;  columnSubplot_Kinet = 3;

               PageNum = f_Report_Consistency(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                                         CG_RangeCI.PIGnormalised_100,Titel_kinet,name_Y_kinetReport,Param_Kinetic,...
                                         lineSubplot_KinetConsist,columnSubplot_Kinet,Ylim_kinet,XTICK,XTICKLABEL,Color_band,...
                                         FootOff_Left,FootOff_Right,Color_Left,Color_Right,...
                                         LineWidth_Left,LineWidth_Right,PageNum);
            end %IF sum(~isnan(DataForCalc.PIGnormalised_100.Moment.Sagittal.GroundReaction.Left(1,:))) > 0 %if NOT all trials are without kinetics
            clear lineSubplot_KinetConsist name_Y_kinetReport
            
            % Upperbody angles (10th,11th & 12th pages)
            if sum(~isnan(DataForCalc.PIGnormalised_100.Angle.Sagittal.Thorax.Left(1,:))) > 0; 
                Title = {'Consistency: Joint rotation angles - Upper body',ID};

                PageNum = f_Report_ConsistencyUB(DataForCalc.PIGnormalised_100,Title,CG_RangeLB.PIGnormalised_100,...
                                                 CG_RangeCI.PIGnormalised_100,Titel_kinem_UB,name_Y_kinem_UB,Angles_UB,...
                                                 lineSubplot_UB,3,Ylim_kinem_UB,XTICK,XTICKLABEL,Color_band,...
                                                 FootOff_Left,FootOff_Right,Color_Left,Color_Right,...
                                                 LineWidth_Left,LineWidth_Right,PageNum);
            end %~isnan(DataForCalc.PIGnormalised_100.Angle.Sagittal.Thorax.Left(1,1));

            % EMG (13th & 14th pages)
            if EMG_recorded == 'y'
               Title = {'Consistency: Electromyographic activity (20-700Hz bandpass)',ID}; 
               PageNum = f_Report_ConsistencyEMG_4FP(StructAllGC,Title,Titel_EMG,...
                                                     Param_EMG,PageNum,RepTrial_left,RepTrial_right,...
                                                     Kinetic_4orMore,TrialNamePlot);
            end %IF EMG_recorded ~= 0
            clear Title PageNum
            
            %% Data Quality comments for the first page
            commentToPrint = f_add_Comment(Params4_c3d,EMG_recorded);
            annotation(fig_firstPage,'textbox',[0.06 0.24 0.88 0.02],'String',commentToPrint,...
                'FontSize',11,'FitBoxToText','off','LineStyle','none');
            clear commentToPrint
            
            %**************************************************************************
            %% Create PDF
            %**************************************************************************
            % Ask for replacement in figures
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!');
            disp('If you want to make some changes in the figures')
            disp('before the conversion in pdf, please do it now.')
            input('Press Enter when finished: ','s');

            % Make PDF to save
            AllFigs = findall(0,'type','figure');
            AllFigs = [1:size(AllFigs,1)]';
            AllFigs = sortrows(AllFigs);

            % if there exists a protocol.mat in the subject folder
            if isProtocol == 1
               OverviewSheet = AllFigs(1,1);
               AllFigs(1,:) = [];             

               f_createPDF(OverviewSheet,Path_PatientFolder_temp,PatientFolder_temp,'_PiG_toPrint',Path_BenoetigteDateien)
            end %isProtocol == 1

            f_createPDF(AllFigs,Path_PatientFolder_temp,PatientFolder_temp,'_PiG',Path_BenoetigteDateien)

            %PDF for secretary
            [NamePDF,NamePatient] = f_namePDFs(Params4_c3d,PatientFolder_temp);
            
            % Make PDF to print
            if EMG_recorded == 'n' && Kinetic_4orMore == 0 %if no EMG and no kinetics
               AllFigs_ToPrint = cat(1,AllFigs(1:4,1),AllFigs(1:4,1),AllFigs(1:4,1),AllFigs(5,1)); 
            elseif EMG_recorded == 'y' && Kinetic_4orMore == 0 %If EMG but no kinetics
               AllFigs_ToPrint = cat(1,AllFigs(1:5,1),AllFigs(1:5,1),AllFigs(1:5,1),AllFigs(6,1));
            elseif EMG_recorded == 'n' && Kinetic_4orMore == 1 %If no EMG but kinetics
               AllFigs_ToPrint = cat(1,AllFigs(1:6,1),AllFigs(1:6,1),AllFigs(1:6,1),AllFigs(7:8,1));
            elseif EMG_recorded == 'y' && Kinetic_4orMore == 1 %If EMG but no kinetics
               AllFigs_ToPrint = cat(1,AllFigs(1:7,1),AllFigs(1:7,1),AllFigs(1:7,1),AllFigs(8:9,1));
            end %EMG_recorded == 'n' && Kinetic_4orMore == 0

            f_createPDF(AllFigs_ToPrint,Path_PatientFolder_temp,PatientFolder_temp,'_GA_temp',Path_BenoetigteDateien)

            close all
            clear OverviewSheet AllFigs AllFigs_ToPrint
            
            %**************************************************************************
            %% Write Excel files f�r �rzte & copy rep. trial c3d
            %**************************************************************************
            Params4_excel = importdata([Path_Patientfolder '\' PatientFolder '_excel.mat']);

            %Names for EMG
            MuscleName = fieldnames(DataForCalc.PIGnormalised_51.EMG.mVolt);

            for i = 1:size(MuscleName,1) %check if not all data are NaN
                DataAcquired = sum(~isnan(DataForCalc.PIGnormalised_51.EMG.mVolt.(MuscleName{i,1}).Left(1,:)));
                if DataAcquired >=1
                   EMG_Excel{i,1} =  Titel_EMG{i,1};
                end
                DataAcquired = sum(~isnan(DataForCalc.PIGnormalised_51.EMG.mVolt.(MuscleName{i,1}).Right(1,:)));
                if DataAcquired >=1
                   EMG_Excel{i,2} =  Titel_EMG{i,1};
                end
            end %FOR for i = 1:size(DataName,1)

            if EMG_recorded == 'n';
                EMG_Excel(1,1:2) = {'NaN','NaN'};
            end %IF 
            % writes Excel files
            Path_xlsx_Template = [Path_BenoetigteDateien,'\ExcelTemplate.xlsx']; %Path of template %ADAPT !!!!!!!!!!!  
            for i = 1:size(Trials,1)

                Path_xlsx = [Path_PatientFolder_temp,'\',Trials{i,1},'_',PatientFolder_temp,'.xlsx']; %Path of patient folder (copy to) %ADAPT !!!!!!!!!!!  

                f_writeExcel(DataForCalc.PIGnormalised_51,Path_xlsx_Template,Path_xlsx,...
                             i,'','',EMG_Excel,Kinetic_4orMore,Params4_excel)
            end %FOR i = 1:size(Trials,1)
            
            % writes Rep Trials to Excel
            % left   
            tt = regexp(RepTrial_left,'_');

            copyfile([Path_PatientFolder_temp,'\',RepTrial_left(1:tt(1,1)-1),'_',PatientFolder_temp,'.c3d'],...
                    [Path_PatientFolder_temp,'\','RepTrial_',RepTrial_left,'_',PatientFolder_temp,'.c3d']);

            Path_xlsx_left = [Path_PatientFolder_temp,'\','RepTrial_',RepTrial_left,'_',PatientFolder_temp,'.xlsx']; %Path of patient folder (copy to) %ADAPT !!!!!!!!!!!    
            
            f_writeExcel(DataForCalc.PIGnormalised_51,Path_xlsx_Template,Path_xlsx_left,rowRepTrial_left,...
                        ParameterSMaRT,TrialsSMaRT_left,EMG_Excel,...
                        Kinetic_4orMore,Params4_excel)
            % right
            tt = regexp(RepTrial_right,'_');

            copyfile([Path_PatientFolder_temp,'\',RepTrial_right(1:tt(1,1)-1),'_',PatientFolder_temp,'.c3d'],...
                    [Path_PatientFolder_temp,'\','RepTrial_',RepTrial_right,'_',PatientFolder_temp,'.c3d']);

            Path_xlsx_right = [Path_PatientFolder_temp,'\','RepTrial_',RepTrial_right,'_',PatientFolder_temp,'.xlsx']; %Path of patient folder (copy to) %ADAPT !!!!!!!!!!!     

            f_writeExcel(DataForCalc.PIGnormalised_51,Path_xlsx_Template,Path_xlsx_right,rowRepTrial_right,...
                        ParameterSMaRT,TrialsSMaRT_right,EMG_Excel,...
                        Kinetic_4orMore,Params4_excel)
            
            clear Params4_excel MuscleName DataAcquired EMG_Excel
            clear Path_xlsx_Template Path_xlsx Path_xlsx_left tt Path_xlsx_right
                    
            disp(' ');
            disp('++++++++++++++++++++')
            disp('XLSX were created in "L"')
            disp(Path_PatientFolder_temp)
            disp('++++++++++++++++++++')
    end %SWITCH ConsistencyEval

end % if ~VideoOnly

%**************************************************************************
%% Copy plantar pressure (.lin & .lst) with "f_copy_PressureFiles"
%**************************************************************************
Path_PatientFolder_temp_Patientfolder = [Path_PatientFolder_temp,'\' PatientFolder_temp]; % Unterordner f�r Modelling
if exist([Path_Patientfolder,'\Links'],'dir') == 7 %If folder with "Links" exists in "K\Patientfolder"
    mkdir([Path_PatientFolder_temp_Patientfolder,'\Links'])
    f_copy_PressureFiles(Path_Patientfolder,Path_PatientFolder_temp_Patientfolder,'Links')
    disp(' ');
    disp('++++++++++++++++++++');
    disp('Pressure files copied for left side')
else
    disp(' ');
    disp('!!!!!!!!!!!!!!!!!!!!!!!!');
    disp('NO pressure files to copy for left side')
end

if exist([Path_Patientfolder,'\Rechts'],'dir') == 7 %If folder with "Rechts" exists in "K\Patientfolder"
    mkdir([Path_PatientFolder_temp_Patientfolder,'\Rechts'])
    f_copy_PressureFiles(Path_Patientfolder,Path_PatientFolder_temp_Patientfolder,'Rechts')
    disp('Pressure files copied for right side');
    disp('++++++++++++++++++++');
else
    disp('NO pressure files to copy for right side');
    disp('!!!!!!!!!!!!!!!!!!!!!!!!');
end

%**************************************************************************
%% Copy pictures (.JPG) 
%**************************************************************************

if exist([Path_Patientfolder '\' PatientFolder],'dir') % IF subfolder exists for pressure or picture data
   copyfile([Path_Patientfolder '\' PatientFolder],[Path_PatientFolder_temp '\' PatientFolder]) 
else  mkdir([Path_PatientFolder_temp '\' PatientFolder])
      if ~isempty(dir([Path_Patientfolder '\*.JPG'])) 
        fileList = dir([Path_Patientfolder '\*.JPG']);
        fileList = struct2cell(fileList);
        for i = 1:length(fileList(1,:))
            copyfile([Path_Patientfolder '\' char(fileList(1,i))],(Path_PatientFolder_temp_Patientfolder))
        end 
      else
          disp(' ');
          disp('!!!!!!!!!!!!!!!!!!!!!!!!');
          disp('NO pictures to copy')
      end
end

clear Path_PatientFolder_temp_Patientfolder fileList i

%**************************************************************************       
%% If only video data exist
%**************************************************************************   
if VideoOnly == 1;

    %**************************************************************************     
    %% Patient information for clinic report (1st page)
    %**************************************************************************
    ID = ['ID: ',PatientFolder_temp];
    f_Report_firstPage_2017(Path_BenoetigteDateien,Params4_c3d,PatientFolder_temp)

    %**************************************************************************     
    %% Clinical Measurements for clinic report (2nd page)
    %**************************************************************************
    f_Report_clinicalTest(ID,Params4_c3d)

    %**************************************************************************     
    %% Create overview sheet for gaitlab folder
    %**************************************************************************
    %if there exists a "protocol.mat" in the current folder
    if ~isempty(dir([Path_Patientfolder,'\' PatientFolder '_protocol.mat']));
       Protocol = importdata([Path_Patientfolder,'\' PatientFolder '_protocol.mat']);
       TibiaTorsion_static.roomCoordinate.left = '';  TibiaTorsion_static.roomCoordinate.right = '';
       TibiaTorsion_static.tibiaCoordinate.left = ''; TibiaTorsion_static.tibiaCoordinate.right = '';
       f_OverviewProtocol(Protocol,TibiaTorsion_static)          
       isProtocol = 1;
       clear Protocol
    else isProtocol = 0;
    end

    %**************************************************************************
    %% Create PDF
    %**************************************************************************
    % Make PDF to save
    AllFigs = findall(0,'type','figure');
    AllFigs = [1:size(AllFigs,1)]';
    AllFigs = sortrows(AllFigs);

    % if there exists a protocol.mat in the subject folder
    if isProtocol == 1
       OverviewSheet = AllFigs(end,1);
       AllFigs(end,:) = [];             

       f_createPDF(OverviewSheet,Path_PatientFolder_temp,PatientFolder_temp,'_PiG_toPrint',Path_BenoetigteDateien)
    end %isProtocol == 1

    f_createPDF(AllFigs,Path_PatientFolder_temp,PatientFolder_temp,'_PiG',Path_BenoetigteDateien)

    %PDF for secretary
    [NamePDF,NamePatient] = f_namePDFs(Params4_c3d,PatientFolder_temp);             

    % if there exists a protocol.mat in the subject folder
    AllFigs_ToPrint = cat(1,AllFigs,AllFigs,AllFigs);

    f_createPDF(AllFigs_ToPrint,Path_PatientFolder_temp,PatientFolder_temp,'_GA_temp',Path_BenoetigteDateien)

    close all
    clear OverviewSheet AllFigs AllFigs_ToPrint

end %IF VideoOnly == 1;

%**************************************************************************
%% Copy Data to Archiv
%**************************************************************************
disp(' ');
disp(' ');
disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
disp('!!! The analysis is over. !!!');
disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!');
disp(' ');
disp('Do you want to copy the data to archiv (L:\)');
disp('and copy the Pdfs for secretary?');
disp(' ');
disp('No, stop script          -------->  ENTER');
disp(' ');
disp('Yes, copy data           -------->  1');
disp(' '); copyEval = input('Selection: ','s');
copyEval = lower(copyEval);
    
switch copyEval
    case {'1'}
        if exist([Path_Final '\' PatientFolder],'dir') % IF there is already a folder for this patient/measure name
            disp(' '); disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'); 
            disp('CAVE: The patient folder already exists on L:\! What do you want to do?')
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'); 
            disp(' '); disp('Stop script, do not overwrite                   -------->  ENTER')
            disp(' '); disp('I do want to overwrite patient folder on L:\    -------->  1')
            disp(' '); PathExists = input('Selection: ','s');
            PathExists = lower(PathExists); disp(' ')

            switch PathExists
              case {''} % stop script if we do not want to overwrite the data
                    disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                    disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
                    disp(['!!! Data in ' Path_PatientFolder_temp ' !!!'])
                    return
              case {'1'}  % data on "L" can be overwritten
                  rmdir([Path_Final '\' PatientFolder],'s');
            end %SWITCH PathExists
        end
        % pdf for secretary
        mkdir(['K:\PDFs_fuerSekretariat\',NamePatient,'\HochladenPhoenix']);
        mkdir(['K:\PDFs_fuerSekretariat\',NamePatient,'\ZuDrucken']);
        copyfile([Path_PatientFolder_temp,'\',PatientFolder_temp,'_PiG.pdf'],['K:\PDFs_fuerSekretariat\',NamePatient,'\HochladenPhoenix','\' NamePDF '.pdf'])
        movefile([Path_PatientFolder_temp,'\',PatientFolder_temp,'_GA_temp.pdf'],['K:\PDFs_fuerSekretariat\',NamePatient,'\ZuDrucken\',NamePDF,'.pdf']);
        % copy data to archiv
        [status,message] = copyfile(Path_PatientFolder_temp,[Path_Final '\' PatientFolder]);
        
        if status
            disp(' ');
            disp('++++++++++++++++++++')
            disp('!!! Program done!!!')
            disp(['Data copied to ' Path_Final '\' PatientFolder])
            disp('++++++++++++++++++++')
        else
            disp(' ');
            disp('!!!!!!!!!!!!!!!!!!!!')
            disp('!!! Data couldn''t be copied to L:\ !!!')
            disp(['!!! ' message ' !!!'])
            disp('++++++++++++++++++++')
        end
        
    case {''}
        disp(' ');
        disp('++++++++++++++++++++')
        disp('!!! Program done!!!')
        disp(['Data in ' Path_PatientFolder_temp])
        disp('++++++++++++++++++++')
end

