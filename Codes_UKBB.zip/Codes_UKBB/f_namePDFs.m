%{ 
*********************************************************************************
            Function "f_namePDFs" linked to script "Auswertung"
                     by Katrin Bracht Jan. 2016
*********************************************************************************



INPUT
  Params4_c3d = Struct with all infos from physio and measurement forms (to write to c3d)
  PatientFolder_new = Name of new Patientfolder on "L" e.g. "v6601a"

OUTPUT
  NamePDF = e.g. "Ganganalyse_PiG_Barfuss_v6666a"
  NamePatient = Surname_firstname_dateOfBirth, e.g. "Bracht_Katrin_19051984"
%}

function [NamePDF,NamePatient] = f_namePDFs(ParametersMat,PatientFolder)

    Birthday = strrep(ParametersMat.Birthday, '.', '');

    NamePatient = [ParametersMat.Surname '_' ParametersMat.Firstname '_' Birthday];
    
%     mkdir(['K:\PDFs_fuerSekretariat\',NamePatient,'\HochladenPhoenix']);
%     mkdir(['K:\PDFs_fuerSekretariat\',NamePatient,'\ZuDrucken']);

    Left_Condition = lower(ParametersMat.Left_Condition);
    Right_Condition = lower(ParametersMat.Right_Condition);

    if strcmp(Left_Condition,'barfuss') && strcmp(Right_Condition,'barfuss')
       Condition = 'Barfuss';
       
    elseif strcmp(Left_Condition,'schuh') && strcmp(Right_Condition,'schuh')
       Condition = 'Schuhe';
       
    elseif strncmp(Left_Condition,'bewegliche afo',14) || strncmp(Left_Condition,'steife afo',10) || ...
           strncmp(Left_Condition,'ossa-orthese',12) || strncmp(Left_Condition,'nancy-hylton',12) || ...
           strncmp(Left_Condition,'fuss orthese',12) || ...
           strncmp(Right_Condition,'bewegliche afo',14) || strncmp(Right_Condition,'steife afo',10) || ...
           strncmp(Right_Condition,'ossa-orthese',12) || strncmp(Right_Condition,'nancy-hylton',12) || ...
           strncmp(Right_Condition,'fuss orthese',12)
       Condition = 'Orthese';  
       
    elseif strncmp(Left_Condition,'prothese',8) || strncmp(Right_Condition,'prothese',8)
       Condition = 'Prothese'; 
       
    elseif ~strncmp(Left_Condition,'einlage',7) || ~strncmp(Right_Condition,'einlage',7)
       Condition = 'OrthetischeHilfsmittel';         
       
    elseif strncmp(Left_Condition,'einlage',7) || strncmp(Right_Condition,'einlage',7)
       Condition = 'Einlagen';  
        
    end %IF strcmp(Left_Condition,'barfuss') && strcmp(Right_Condition,'barfuss')


    NamePDF = ['Ganganalyse_PiG_' Condition '_' PatientFolder];

end %FUNCTION