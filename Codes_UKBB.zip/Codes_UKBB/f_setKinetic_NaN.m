%{
********************************************************************************* 
     Function "f_Kinetic_NaN" linked to script "Auswertung..."
                    by Katrin Bracht March 2018
*********************************************************************************

Replaces all kinetic data in struct "data" with NaNs

INPUT: data = same as Struct "StructNaNKinetic"
       Side = Side current gait cycle
       EV1 = 1
       SizeData = size of kinetic data

OUTPUT: data = Input struct, kinetic data are filled with NaNs

%}

function [data] = f_setKinetic_NaN(data,Side,EV1,SizeData)

        Fieldnames1 = {'Moment','Power','Force'}'; 

        for j = 1:size(Fieldnames1,1) 
            Fieldnames2 = fieldnames(data.((Fieldnames1{j,:})));

            for k = 1:size(Fieldnames2,1)  
                Fieldnames3 = fieldnames(data.(Fieldnames1{j,:}).(Fieldnames2{k,:}));

                for l = 1:size(Fieldnames3,1)  
                    data.(Fieldnames1{j,:}).(Fieldnames2{k,:}).(Fieldnames3{l,:}).(Side)(EV1:SizeData,1) = NaN(SizeData,1);
                    
                end %FOR k = 1:size(Fieldnames3,1)  
            end %FOR j = 1:size(Fieldnames2,1)       
        end %FOR i = 1:size(namefield1,1)
    
end %FUNCTION