function out = f_defineGaitCycles(Path_data, trials_infos)
%{
by M. Freslier, Mar. 2017

changed by F. Behrendt, Mar. 2018, for the use with Nexus 2.5 data

go through the list of trials and define the good gait cycles for trials
with kinetic. Informations are taken from the trials_infos struct.
If there is a general event for the definition of the 4th step, a
description will be added.

INPUT
    Path_data = path where the data are saved (temporary folder)
    trials_infos = struct of the information of the trials, fields are
        filename, Processed (='static','vid_running','vid_orthosis' or
        'dynamic'), kinetic, newName

OUTPUT
    out = 1 if all ok, 0 if there is a problem ... (script
    will be stopped)
%}

out = 1;

for trial = 1:length(trials_infos)
    switch trials_infos(trial).Processed
        case 'dynamic' % only for dynamic trials
            Path_c3d = [Path_data '\' trials_infos(trial).newName '.c3d'];
            warning off all
            acq = btkReadAcquisition(Path_c3d);
            warning on all; warning('off','MATLAB:interp1:NaNinY')

            eventsOrigin = btkGetEvents(acq);
            
            % search the 4th step general events and set a description
            if isfield(eventsOrigin,'General_Event')
                FO_Events = [eventsOrigin.Left_Foot_Off eventsOrigin.Right_Foot_Off];
                nb_4thStep = 0;

                [diff index] = min(abs(FO_Events-eventsOrigin.General_Event)); %finds the neighboring toe-off value 
                eventsOrigin.General_Event = FO_Events(index);% replaces the general event frame value by the original toe-off frame value
                [times, labels, descriptions, ids] = btkGetEventsValues(acq); 
                index = find(strcmp(labels,'Event')); 
                btkSetEventTime(acq, index, eventsOrigin.General_Event); % writes value into acq
                btkWriteAcquisition(acq,Path_c3d);
                 
                for genEvt = 1:length(eventsOrigin.General_Event)
                    for FO_evt=1:length(FO_Events)
                        if eventsOrigin.General_Event(genEvt) == FO_Events(FO_evt)
                            nb_4thStep = nb_4thStep + 1;
                        end
                    end
                end
                switch nb_4thStep
                    case 0 % no general event found for defining 4th Step
                    case 1 % only one general event found for defining 4th step
                        btkSetEventDescription(acq,'Event','Toe Off of the 4th step');
                        btkWriteAcquisition(acq,Path_c3d);
                    otherwise % too many general events that could define a 4th step
                        out = 0;
                        disp(' ');
                        disp('!!! error in f_defineGaitCycles: !!!');
                        disp(['!!! Too many general events that could define a 4th step for trial '...
                            trials_infos(trial).filename ': please have a look. !!!']);
                end
            end % if isfield(eventsOrigin,'General_Event')
                
            if trials_infos(trial).newName(1) == 'K' % only for dynamic trials with kinetic
                freq = btkGetPointFrequency(acq); % frequency kinematic (Vicon)
                freqAnalog = btkGetAnalogFrequency(acq); % frequency analog (EMG, forces)
                firstFrame = btkGetFirstFrame(acq); % first frame of the measurement (in case the trial was cut)
                firstFrameAnalog = firstFrame*(freq\freqAnalog)-(freq\freqAnalog)+1;

                Analog = btkGetAnalogs(acq);

                % set the general events for the gait cycles with kinetic
                for step = 1:size(trials_infos(trial).kinetic,1)
                    side = trials_infos(trial).kinetic{step,1};
                    forceplate = trials_infos(trial).kinetic{step,2};
                    
                    switch forceplate
                        case 'FP1'
                            Fz = Analog.Fz1;
                        case 'FP2'
                            Fz = Analog.Fz2;
                        case 'FP3'
                            Fz = Analog.Fz3;
                        case 'FP4'
                            Fz = Analog.Fz4;
                    end % switch forceplate
                    
                    switch side
                        case 'left'
                            FS_ipsi = eventsOrigin.Left_Foot_Strike;
                        case 'right'
                            FS_ipsi = eventsOrigin.Right_Foot_Strike;
                    end % switch side
                    
                    [FS_found,FS_GaitCycle] = findCorrespondingFS(freqAnalog,firstFrameAnalog,Fz,FS_ipsi);
                    if FS_found
                        ev_descrip = [side,' foot contact on forceplate ',forceplate,', clean hit.'];
                        btkAppendEvent(acq, 'Event', FS_GaitCycle, 'General','',ev_descrip);
                        %% Write the new general event into acquision
                        btkWriteAcquisition(acq,Path_c3d);
                    else
                        out = FS_found;
                        disp(' ');
                        disp('!!! error in f_defineGaitCycles: !!!');
                        disp(['!!! for trial ' trials_infos(trial).filename ': !!!']);
                        disp(['!!! there isn''t any foot strikes that correspond to ('...
                            side ',' forceplate '): please have a look. !!!']);
                    end
                end % for step = 1:size(trials_infos(trial).kinetic,1)
                btkDeleteAcquisition(acq);
            end % if trials_infos(trial).newName(1) == 'K'
        otherwise
            continue
    end % switch trials_infos(trial).Processed
end % for trial = 1:length(trials_infos)

end % END OF FUNCTION

% function that check if there is a foot strike in given FS list which
% correspond to the given vertical force
function [out,timeGenEvt] = findCorrespondingFS(freqAnalog,firstFrameAnalog,Fz,FS)
    i=1;
    while i<=length(FS)
        if Fz(round(FS(i)*freqAnalog - firstFrameAnalog + 2)-50) == 0 ...
            && Fz(round(FS(i)*freqAnalog - firstFrameAnalog + 2)+50)~=0
        % this FS correspond to the considered FP
            eventsOK = 1;
            break
        else
            i = i + 1;
            eventsOK = 0;
        end
    end
    if eventsOK == 0
        timeGenEvt = 0;
        out = 0;
        return
    else %eventsOK == 1
        timeGenEvt = FS(i);
        out = 1;
        return
    end
end