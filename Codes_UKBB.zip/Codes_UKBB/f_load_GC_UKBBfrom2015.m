%{ 
*********************************************************************************
Function "f_load_GC" linked to script "Auswertung_..."
            by Katrin Bracht March. 2018
*********************************************************************************

- save the events (foot strikes and foot off) for the current gait cycle
into the PIGunnormalised struct under Events_currentGC
- Check labelling markers "f_check_LabellingMarkers"
- Replace kinetic with the values, if kinetic is good for this gait cycle "f_replaceKinetic"
- Time-normalisation of the data with "f_timeNormalisation"
- Calculate gait parameters
- Write stride width into c3d
- Calculate non-dimensional gait parameters


INPUT: StructC3D = Struct with unnormalised data: {Model}.{Measure}.{Plane}.{Joint}.{Side} (e.g PIGunnormalised.Angles.Sagittal.Knee.Left)
       InfoGC = a cell array with informations of the gait cycles:
                {x,1} = name of the c3d
                {x,2} = side
                {x,3} = 'FP0' (no kinetics)
                {x,4} = a struct with the events (FS ipsi&contra, FO ipsi&contra)
                {x,5} = step number, obtained from the definition of the 4th
                        step, 0 if undetermined
                {x,6} = trial number (obtained from the c3d name)
                {x,7} = step number, obtained from the 1st gait cycle defined
                        in the trial, -1 if impossible to determine
        
        MarkersC3D = Struct with all markers similar to output from c3d but with corrected gait direction
        StructNaNKinetic = Struct similar to StructC3D but with Kinetic only where it is good


OUTPUT: Resuct = Struct: {Model}.{Measure}.{Plane}.{Joint}.{Side} (e.g PIGunnormalised.Angles.Sagittal.Knee.Left)
        out = 0 if there is some error in marker labelling
        StructC3D = Struct with unnormalised data: {Model}.{Measure}.{Plane}.{Joint}.{Side} (e.g PIGunnormalised.Angles.Sagittal.Knee.Left)
        StructGC = Struct similar to StructC3D, icluding time normalised data to 51 and 100 data values
        StructNaNKinetic = Struct similar to StructC3D but with Kinetic only where it is good
%}

% function [StructC3D,StructGC,StructNaNKinetic] = f_load_GC(StructC3D,InfoGC,MarkersC3D,StructNaNKinetic,Params4_c3d)
function [out,StructC3D,StructGC,StructNaNKinetic] = f_load_GC_UKBBfrom2015(StructC3D,InfoGC,MarkersC3D,StructNaNKinetic,LLegLength,RLegLength,EMG_recorded)
%**************************************************************************
    %% insert gait cycles events in the PIGunnormalised field
%**************************************************************************
    StructC3D.PIGunnormalised.Events_currentGC.InSeconds.FootStrike.dummy = InfoGC{1,4}.FS_ipsi;
    StructC3D.PIGunnormalised.Events_currentGC.InSeconds.FootOff.dummy = InfoGC{1,4}.FO_ipsi;

    GC_side =  InfoGC{1,2}; %side of ipsilateral gait cycle e.g. "left" or "right"
    ForcePlate = InfoGC{1,3}; %the relevant force plate which was hit properly,e e.g. "FP4", if no kinetik than "FP0"       
   
    switch GC_side
    case 'left'
        events.Left_Foot_Strike = InfoGC{1,4}.FS_ipsi;
        events.Right_Foot_Strike = InfoGC{1,4}.FS_contra;        
        events.Left_Foot_Off = InfoGC{1,4}.FO_ipsi;
        events.Right_Foot_Off = InfoGC{1,4}.FO_contra;
        
        EV1 = events.Left_Foot_Strike(1,1);
        EV2 = events.Left_Foot_Strike(1,2);
    case 'right'
        events.Right_Foot_Strike = InfoGC{1,4}.FS_ipsi;
        events.Left_Foot_Strike = InfoGC{1,4}.FS_contra;        
        events.Right_Foot_Off = InfoGC{1,4}.FO_ipsi;
        events.Left_Foot_Off = InfoGC{1,4}.FO_contra;
        
        EV1 = events.Right_Foot_Strike(1,1);
        EV2 = events.Right_Foot_Strike(1,2);
    end % switch side

    
    % Transfer events from seconds to frames
    freq = StructC3D.PIGunnormalised.Frequency.Vicon.Hertz.Dummy;
    firstFrame = StructC3D.PIGunnormalised.FirstFrame.Vicon.Dummy.Dummy;
    EventsFrames = structfun(@(x) (round(x * freq - firstFrame + 2)), ...
                                   events, 'UniformOutput', false);
                               
% **************************************************************************    
    %% Check labelling markers "f_check_LabellingMarkers"
% **************************************************************************

    out = f_check_LabellingMarkers(MarkersC3D,['Trial_',num2str(InfoGC{1,6})],EventsFrames);
    if ~out
        StructGC = struct;
        return
    end
    
%**************************************************************************
    %% Time-normalisation of the data with "f_timeNormalisation"
%**************************************************************************

    %[StructGC] = f_timeNormalisation(StructC3D,EV1,EV2);
    [StructGC] = f_timeNormalisation_UKBBfrom2015(StructC3D,EV1,EV2,EMG_recorded);
       
%%**************************************************************************    
     %% Replace kinetic with the values, if kinetic is good for this gait cycle "f_replaceKinetic"
%%**************************************************************************
    
    if strcmp(ForcePlate,'FP0') %if no kinetic
       StructGC.PIGnormalised_100 = f_setKinetic_NaN(StructGC.PIGnormalised_100,'Left',1,100);
       StructGC.PIGnormalised_100 = f_setKinetic_NaN(StructGC.PIGnormalised_100,'Right',1,100);    
       StructGC.PIGnormalised_51 = f_setKinetic_NaN(StructGC.PIGnormalised_51,'Left',1,51);
       StructGC.PIGnormalised_51 = f_setKinetic_NaN(StructGC.PIGnormalised_51,'Right',1,51); 
    elseif strcmp(ForcePlate,'FP0') == 0 && strcmp(GC_side,'left'); %if kinetic left is good
       StructNaNKinetic.PIGunnormalised = f_replaceKinetic(StructNaNKinetic.PIGunnormalised,'Left',EventsFrames.Left_Foot_Strike(1,1),EventsFrames.Left_Foot_Strike(1,2),StructC3D.PIGunnormalised);
       StructGC.PIGnormalised_100 = f_setKinetic_NaN(StructGC.PIGnormalised_100,'Right',1,100);
       StructGC.PIGnormalised_51 = f_setKinetic_NaN(StructGC.PIGnormalised_51,'Right',1,51);
    elseif strcmp(ForcePlate,'FP0') == 0 && strcmp(GC_side,'right'); %if kinetic right is good
       StructNaNKinetic.PIGunnormalised = f_replaceKinetic(StructNaNKinetic.PIGunnormalised,'Right',EventsFrames.Right_Foot_Strike(1,1),EventsFrames.Right_Foot_Strike(1,2),StructC3D.PIGunnormalised);
       StructGC.PIGnormalised_100 = f_setKinetic_NaN(StructGC.PIGnormalised_100,'Left',1,100);
       StructGC.PIGnormalised_51 = f_setKinetic_NaN(StructGC.PIGnormalised_51,'Left',1,51);
    end %IF strcmp(ForcePlate,'FP0')
    

   
% **************************************************************************        
  %% Calculate gait parameters 
% **************************************************************************        

    GaitParam = f_calc_GaitParameter(GC_side,MarkersC3D,EventsFrames,freq);  
    StructGC.PIGnormalised_100.GaitParam = GaitParam;
    StructGC.PIGnormalised_51.GaitParam = GaitParam;
      
    % write stride width into c3d
%     f_StrideWidth2_c3d(GaitParameters,GaitParam_KinematicCorr.Left_Stride_Width,...
%                        GaitParam_KinematicCorr.Right_Stride_Width,Path_c3d,acq,...
%                        PatientFolder_new,Description_StrideWidth)
    
%**************************************************************************
  %% Gait Parameter non-dimensional according to Hof 1996 with "f_nonDimens_TemporalParameters"
%**************************************************************************
    StructGC.PIGnormalised_100.GaitParam_nonDim.Dummy = f_nonDimens_TemporalParameters...
                                               (StructGC.PIGnormalised_100.GaitParam.Dummy,...
                                                LLegLength,RLegLength);
%                                                 Params4_c3d.LLegLength,Params4_c3d.RLegLength);

    StructGC.PIGnormalised_51.GaitParam_nonDim.Dummy = StructGC.PIGnormalised_100.GaitParam.Dummy;

end % FUNCTION

