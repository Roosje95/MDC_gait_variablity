%{
*********************************************************************************
Function "f_Report_TemporalParameters" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer April 2014
                    adapted for new printout by Marie F. June 2018
*********************************************************************************

Creates the 3rd page of the report with legend of the clinical measurements
and temporal parameters.
                                     
INPUT
  dataStruct = Gait parameters of patient
  dataMean_ND = Mean of non-dimensional gait parameters of patient
  dataRange_ND = Confidence intervals of non-dimensional gait parameters of patient
  CG_Mean = Mean of struct of the healthy subjects
  CG_range = Range (e.g. confidence intervals/standard deviation) of struct of the healthy subjects
  columnRepTrial_left = column where the representative trial stands in "dataStruct" for the left side
  columnRepTrial_right = column where the representative trial stands in "dataStruct" for the right side
  ID = Patient number and letter (e.g. 'ID: 4511l')
  TrialStr = Cell with name of trial that are plotted {'L4',R5'}

OUTPUT
  Figure for 3rd page report save in the postscript.
%}


function f_Report_TemporalParameters_4FP(dataStruct,dataMean_ND,dataRange_ND,...
                                     CG_Mean,CG_range,columnRepTrial_left,...
                                     columnRepTrial_right,ID,TrialStr)
% dataStruct.Stride_Width.Left = [1.00333333015442,1.02999997138977,1.03999996185303,1.07000005245209,1.07666671276093,1.02666664123535];
% dataMean_ND.Stride_Width.Left = 3.07;
% dataRange_ND.Stride_Width.Left = 0.07; 
% dataStruct.Stride_Width.Right = [1.00333333015442,1.02999997138977,1.03999996185303,1.07000005245209,1.07666671276093,1.02666664123535];
% dataMean_ND.Stride_Width.Right = 3.07;
% dataRange_ND.Stride_Width.Right = 0.07;
% CG_Mean.GaitParam.Dummy.Stride_Width = 1.04;
% CG_range.GaitParam.Dummy.Stride_Width = 0.03;                                
% CG_Mean.GaitParam_nonDim.Dummy.Stride_Width = 3.04;
% CG_range.GaitParam_nonDim.Dummy.Stride_Width = 0.08;                                  
                                 
    % Create figure
    figure1 = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                     'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                     'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]

    annotation(figure1,'textbox',[0.805 0.970 0.144 0.05],'String',ID,...
                 'FontSize',11,'FitBoxToText','off','LineStyle','none',...
                 'VerticalAlignment','middle','HorizontalAlignment','right');
             
    %% Bewertungstabelle manuelle Muskelkrafttests
    
    annotation(figure1,'textbox',[0.08 0.768 0.761 0.231],...
              'String',{'Manual muscle strength scale (evaluated in available range of motion (RoM))',...
              '5.  Normal:','4.  Good:','3+.','3.  Fair:','2.  Poor:','2-.','1.  Trace:','0.  Zero:'},...
              'FontWeight','bold','FontSize',7.5,'FitBoxToText','off','EdgeColor','none');
    % Create textbox
    annotation(figure1,'textbox',[0.155 0.771 0.807 0.214],...
              'String',{'Complete RoM against gravity with maximal manual resistance',...
                        'Complete RoM against gravity with moderate resistance or is unable to complete RoM when done with maximal resistance',...
                        'Motion against gravity with minimal resistance (RoM can be slightly decreased because of contraction)',...
                        'Perfect RoM against gravity (RoM can be slightly decreased because of contraction)',...
                        'Moves through incomplete RoM with gravity eliminated','Initiates motion if gravity is eliminated',...
                        'A contraction is felt, but there is no apparent movement of part',...
                        'No contraction felt in muscle'},...
                        'FontSize',7.5,'FitBoxToText','off','EdgeColor','none');

    %% Bewertungstabelle aktive Plantarflexion
    annotation(figure1,'textbox',[0.08 0.686 0.761 0.192],...
              'String',{'Active plantarflexion scale (rise to tip-toes with knees extended)',...
                        '5.  Normal:','4.  Good:','3.  Fair:','2+.Poor:','2.  Poor:','2-. Poor:','1.  Trace:','0.  Zero:'},...
                        'FontWeight','bold','FontSize',7.5,'FitBoxToText','off','EdgeColor','none');
    % Create textbox
    annotation(figure1,'textbox',[0.155 0.693 0.807 0.171],...
              'String',{'5 repetitions with complete RoM against gravity',...
                       '3-4 repetitions with complete RoM against gravity or unable to complete RoM with 5 repetitions',...
                       '1-2 repetition or heel lifted from floor with complete RoM against gravity',...
                       'Heel lift possible, but thought patial RoM only','Moves through complete RoM with gravity eliminated',...
                       'Moves through patial RoM with gravity eliminated',...
                       'A contraction is felt, but there is no apparent movement of part',...
                       'No contraction is felt in muscle'},...
                       'FontSize',7.5,'FitBoxToText','off','EdgeColor','none');

    %% Bewertungstabelle Spastik-Skala
    annotation(figure1,'textbox',[0.08 0.6045 0.761 0.155],...
               'String',{'Spasticity scale (modified Ashworth/Bohannon)',...
                         '0.  ','1.  ','1+.','2.  ','3.  ','4.  '},...
                         'FontWeight','bold','FontSize',7.5,'FitBoxToText',...
                         'off','EdgeColor','none');
    % Create textbox
    annotation(figure1,'textbox',[0.155 0.6178 0.807 0.129],...
              'String',{'No increase in muscle tone',...
                        'Slight increase in tone manifested by a "catch" and release or by minimal resistance at the end of RoM when limb is moved',...
                        'Slight increase in tone manifested by a "catch" followed by minimal resistance throughout the remainder (less than half) of RoM',...
                        'More marked increase in tone through most of the RoM but affected part is easily moved',...
                        'Considerable increase in tone, passive movement is difficult',...
                        'Affected part rigid in flexion or extension'},...
                        'FontSize',7.5,'FitBoxToText','off','EdgeColor','none');


    %% Duncan Ely Test
    annotation(figure1,'textbox',[0.08 0.610 0.761 0.06],...
               'String',{'Duncan Ely Test',...
                         '+  ',' -  '},...
                         'FontWeight','bold','FontSize',7.5,'FitBoxToText',...
                         'off','EdgeColor','none');
    % Create textbox
    annotation(figure1,'textbox',[0.155 0.598 0.807 0.06],...
              'String',{'buttock rise by quick knee flexion in prone position',...
                        'no buttock rise by quick knee flexion in prone position'},...
                        'FontSize',7.5,'FitBoxToText','off','EdgeColor','none');

    %% FMS
%     annotation(figure1,'textbox',[0.08 0.6320 0.048 0.030],'String',{'FMS:'},...
    annotation(figure1,'textbox',[0.08 0.600 0.048 0.030],'String',{'FMS:'},...
              'FontWeight','bold','FontSize',7.5,'FitBoxToText','off','EdgeColor','none');
    % Create textbox
    annotation(figure1,'textbox',[0.155 0.5690 0.807 0.061],...
              'String',{'Stands for "Functional Mobility Scale (Version 2)" and rates the child�s usual walking ability at 5 m, 50 m, and 500 m',...
                        'on a scale of 1 (uses a wheelchair) to 6 (independent on all surfaces, does not use any walking aids/help).'},...
                        'FontSize',7.5,'FitBoxToText','off','EdgeColor','none');


    %% GMFCS
%     annotation(figure1,'textbox',[0.08 0.591 0.065 0.031],'String',{'GMFCS:'},...
    annotation(figure1,'textbox',[0.08 0.572 0.065 0.031],'String',{'GMFCS:'},...
              'FontWeight','bold','FontSize',7.5,'FitBoxToText','off',...
              'EdgeColor','none');
    % Create textbox
    annotation(figure1,'textbox',[0.155 0.542 0.807 0.061],...
              'String',{'Stands for "Gross Motor Function Classification System" and classifies the function of children with cerebral palsy based on',...
                        'self-initiated movement. Scale: 1 (walks without limitations; running, jumping and gait speed might be affected)',...
                        'to 5 (self-mobility is achieved in a powered wheelchair only).'},...
                        'FontSize',7.5,'FitBoxToText','off','EdgeColor','none');

          
   %% Spatio-temporal parameters   
   annotation(figure1,'textbox',[0.08 0.535 0.445 0.030],'String',{'Spatio-temporal parameters'},...
             'FontWeight','bold','FontSize',14,'FitBoxToText','off','LineStyle','none');
    TrialStr = strrep(TrialStr, '_', '.');
    
   % Left   
%    annotation(figure1,'textbox',[0.275 0.515 0.19 0.03],'String',['Left' ' (' TrialStr{1,1} ')'],...
%              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
%              'LineStyle','none','Color',[1 0 0]); %0.401 
     TrialSplit = strsplit(TrialStr{1,1},'.');
     annotation(figure1,'textbox',[0.280 0.515 0.19 0.03],'String', ...
             {'Left', ['(' TrialSplit{1,1} '.' TrialSplit{1,3} '.' TrialSplit{1,4} ')']},...
             'FontWeight','bold','FontSize',8,'FitBoxToText','off',...
             'LineStyle','none','Color',[1 0 0]);
   % Both sides       
   annotation(figure1,'textbox',[0.390 0.515 0.19 0.03],'String',...
             {'Bilateral', ['(' TrialSplit{1,1} '.' TrialSplit{1,3} '.' TrialSplit{1,4} ')']},...
             'FontWeight','bold','FontSize',8,'FitBoxToText','off',...
             'LineStyle','none','Color','k'); %0.278         
   % Right
   TrialSplit = strsplit(TrialStr{1,2},'.');
   annotation(figure1,'textbox',[0.495 0.515 0.19 0.03],'String',...
             {'Right', ['(' TrialSplit{1,1} '.' TrialSplit{1,3} '.' TrialSplit{1,4} ')']},...
             'FontWeight','bold','FontSize',8,'FitBoxToText','off',...
             'LineStyle','none','Color',[0 0 1]);
   % Normal
   annotation(figure1,'textbox',[0.626 0.500 0.19 0.03],'String',{'Normal'},...
             'FontWeight','bold','FontSize',8,'FitBoxToText','off','LineStyle','none'); 
   % 95% Confidence Interval
   annotation(figure1,'textbox',[0.717 0.500 0.19 0.03],'String',{'95% CI (�)'},...
             'FontWeight','bold','FontSize',8,'FitBoxToText','off','LineStyle','none'); 
   % Unit
   annotation(figure1,'textbox',[0.817 0.500 0.19 0.03],'String',{'Unit'},...
             'FontWeight','bold','FontSize',8,'FitBoxToText','off','LineStyle','none'); 

         
    %% Spatio-temporal Parameters
  
    NumSameForBothSides = 5; %#######ADAPT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   
    Fieldnames = {'Walking_Speed','Stride_Length','Stride_Time','Stride_Width','Double_Support','Cadence','Step_Length','Foot_Off',...
                  'Single_Support','Opposite_Foot_Contact'}';
              
    NumGaitParams = size(Fieldnames,1);
    
    Cell = {'Walking speed','Stride length','Stride time','Stride width','Double support','Cadence','Step length','Foot off',...
            'Single support','Opposite foot contact'}';
    
    Cell(:,7) = {'   m/s','   m','   s','   m','   s','   steps/min','   m','   %',...
                 '   s','   %'}'; 

             
    % to round the gait parameters to 2 decimals (%2.2f) and make them a string
    for i = 1:size(Fieldnames)
        
        if i <= NumSameForBothSides  
           Cell{i,2} = ' '; %left side of patient
           Cell{i,3} = sprintf('%2.2f',dataStruct.(Fieldnames{i,1}).Left(1,columnRepTrial_left)); %both sides of patient (taken from left side of patient)
           Cell{i,4} = ' '; %right side of patient
        else
           Cell{i,2} = sprintf('%2.2f',dataStruct.(Fieldnames{i,1}).Left(1,columnRepTrial_left)); %left side of patient
           Cell{i,3} = ' '; %both sides of patient
           Cell{i,4} = sprintf('%2.2f',dataStruct.(Fieldnames{i,1}).Right(1,columnRepTrial_right)); %right side of patient
        end %IF i <= NumSameForBothSides
        
        Cell{i,5} = sprintf('%2.2f',CG_Mean.GaitParam.Dummy.(Fieldnames{i,1})); % mean of healthy subjects
        Cell{i,6} = sprintf('%2.2f',CG_range.GaitParam.Dummy.(Fieldnames{i,1})); % ranges of healthy subjects
        
    end %FOR i = 1:size(Fieldnames)
   
    
    
%**************************************************************************    
    %% Plot gait parameters to table
%**************************************************************************

    GreyBackground = [0.85 0.85 0.85]; %Background color
                  
    Ypos = 0.487; %Y-Position of textbox lower corner
    XposStart = 0.085; %x-Position of textbox lower corner
    FrontSize = 10; %size of text
  
    for i = 1:NumGaitParams %for Rows of Cell
        
        Xpos = XposStart; %X-Position of textbox lower left corner
        Height = 0.023; %Height of textbox

        if mod (i,2) %if i = odd number --> grey background
           BackgroundColor = GreyBackground;          
        else 
           BackgroundColor = 'none';
        end %IF mod (i,2)   

        for j = 1:7

            %if first or last column
            if j == 1
               
               HorizontalAlignment = 'left';
               Width = 0.200; %Width of textbox 
              
               f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                             FrontSize,BackgroundColor,HorizontalAlignment)
                        
               Xpos = Xpos + Width;
              
            elseif j>1 && j<7
               
               HorizontalAlignment = 'right';
               Width = 0.105; %Width = 0.105;
              
               f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                             FrontSize,BackgroundColor,HorizontalAlignment)

               Xpos = Xpos + Width;
               
            elseif j == 7
               
               HorizontalAlignment = 'left';
               Width = 0.105; %Width of textbox 
              
               f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                             FrontSize,BackgroundColor,HorizontalAlignment)
                        
               Xpos = Xpos + Width;
            end %IF j == 1

        end %FOR j = 1:6

       Ypos = Ypos - Height;

    end %FOR i = 1:NumGaitParams %for Rows of Cell
 
    
   %% Rectangles
   
   annotation(figure1,'rectangle',[XposStart Ypos+Height 0.83 NumGaitParams*Height]);
   %bilateral
   annotation(figure1,'rectangle',[XposStart+0.200 Ypos+Height 0.105 NumGaitParams*Height]);
   %right side 
   annotation(figure1,'rectangle',[XposStart+0.200+2*0.105 Ypos+Height 0.105 NumGaitParams*Height]);
   %normal
   annotation(figure1,'rectangle',[XposStart+0.200+3*0.105 Ypos+Height 0.210 NumGaitParams*Height]);
 
   
   
%**************************************************************************
%% Plot dimensionless gait parameters in percent of controls
%**************************************************************************

   % Calculate difference (in percent) from non-dimensional parameters of
   % patient to mean of controls
 

   for i = 1:size(Fieldnames)
       if i <= NumSameForBothSides
           ForPlot_PA_Mean(i,1) = dataMean_ND.(Fieldnames{i,1}).Left; %left side of patient
           ForPlot_PA_Mean(i,2) = NaN; %left side of patient
           ForPlot_PA_Mean(i,3) = NaN; %right side of patient
           
           ForPlot_PA_Range(i,1) = dataRange_ND.(Fieldnames{i,1}).Left; %left side of patient
           ForPlot_PA_Range(i,2) = NaN; %left side of patient
           ForPlot_PA_Range(i,3) = NaN; %right side of patien

           ForPlot_CG_Mean(i,1:3) = repmat(CG_Mean.GaitParam_nonDim.Dummy.(Fieldnames{i,1}),1,3); % mean of healthy subjects
           ForPlot_CG_Range(i,1:3) = repmat(CG_range.GaitParam_nonDim.Dummy.(Fieldnames{i,1}),1,3); % ranges of healthy subjects
       else
           ForPlot_PA_Mean(i,1) = NaN; %left side of patient
           ForPlot_PA_Mean(i,2) = dataMean_ND.(Fieldnames{i,1}).Left; %left side of patient
           ForPlot_PA_Mean(i,3) = dataMean_ND.(Fieldnames{i,1}).Right; %right side of patient
           
           ForPlot_PA_Range(i,1) = NaN; %left side of patient
           ForPlot_PA_Range(i,2) = dataRange_ND.(Fieldnames{i,1}).Left; %left side of patient
           ForPlot_PA_Range(i,3) = dataRange_ND.(Fieldnames{i,1}).Right; %right side of patient
           
           ForPlot_CG_Mean(i,1:3) = repmat(CG_Mean.GaitParam_nonDim.Dummy.(Fieldnames{i,1}),1,3); % mean of healthy subjects
           ForPlot_CG_Range(i,1:3) = repmat(CG_range.GaitParam_nonDim.Dummy.(Fieldnames{i,1}),1,3); % ranges of healthy subjects
       end %IF i <= NumSameForBothSides
   end %FOR i = 1:size(Fieldnames)
   
   ForPlot_PA_Mean = ForPlot_PA_Mean./ForPlot_CG_Mean.*100-100;
   ForPlot_PA_Mean(NumSameForBothSides+1:end,1) = NaN;   ForPlot_PA_Mean(1:NumSameForBothSides,2:3) = NaN;
   ForPlot_PA_Range = ForPlot_PA_Range./ForPlot_CG_Mean.*100;
   ForPlot_PA_Range(NumSameForBothSides+1:end,1) = NaN;   ForPlot_PA_Range(1:NumSameForBothSides,2:3) = NaN;
   ForPlot_CG_Range = ForPlot_CG_Range./ForPlot_CG_Mean.*100;

   
  %% Plot controls in grey rectangles for bilateral plot
  
   annotation(figure1,'textbox',[0.087 0.26 0.829 0.01],'String',...
              'Percentage deviation of non-dimensional spatio-temporal parameters to healthy controls',...
              'FontWeight','bold','FontSize',10,'VerticalAlignment','middle',...
              'FitBoxToText','off','LineStyle','none','HorizontalAlignment','center');  

   struct_for_patch.Vertices = [0.5,1.5,1.5,0.5, 1.5,2.5,2.5,1.5, 2.5,3.5,3.5,2.5, 3.5,4.5,4.5,3.5,...
                                4.5,5.5,5.5,4.5, ...
                                -20,-20,20,20, -20,-20,20,20, -20,-20,20,20, -20,-20,20,20,...
                                -20,-20,20,20]';   
      
   struct_for_patch.Faces = [1,2,3,4; 5,6,7,8; 9,10,11,12; 13,14,15,16; 17,18,19,20];                      
                                                                
   struct_for_patch.FaceColor = [0.8 0.8 0.8];
   
   X = 1;                        
   for tt = 1:size(ForPlot_CG_Range(1:NumSameForBothSides,:),1)
       struct_for_patch.Vertices([X,X+1],2) = ForPlot_CG_Range(tt,1)*-1;
       struct_for_patch.Vertices([X+2,X+3],2) = ForPlot_CG_Range(tt,1);
       X = X+4;
   end % FOR tt = 1:size(ForPlot_CG_Range,1)

   Plot1 = subplot('Position',[0.135 0.106 0.278 0.14]);
   patch(struct_for_patch,'LineStyle','none'); hold all
    
  
  %% plot bars with errors "f_barwitherr" & "f_rotateXLabels"

   Color = 'k';
   bar1 = f_barwitherr(ForPlot_PA_Range(1:NumSameForBothSides,1),Color,...
                       ForPlot_PA_Mean(1:NumSameForBothSides,1),'grouped','LineWidth',1); 
 
   set(bar1(1),'FaceColor',Color,'EdgeColor',Color,'LineStyle','none','LineWidth',1.4,'BarWidth',0.4);
 
   set(gca,'XTick',1:1:NumSameForBothSides,'XTickLabel',Cell(1:NumSameForBothSides,1)',...
       'XTickLabelRotation',45,'FontSize',8,'YGrid','on'); % [0.135 0.1 0.769 0.14]
   box(gca,'on'); set(gca, 'Layer','top') % draw box on top
   
   ylabel('Difference to norm in %'); 

   
   MIN = floor(min(min(ForPlot_PA_Mean-ForPlot_PA_Range)));
   MAX = ceil(max(max(ForPlot_PA_Mean+ForPlot_PA_Range)));
   ylim([MIN-1 MAX+1])
   xlim([0.5 NumSameForBothSides+0.5]); hold all
   XValues = 0.5:1:NumSameForBothSides+0.5;
   ZeroLine = plot(XValues,zeros(NumSameForBothSides+1,1)','Color','k','LineWidth',0.8); % plot zero line

                  
  %% Plot controls in grey rectangles for left/right plot           
              
   X = 1;                        
   for tt = NumSameForBothSides+1:size(ForPlot_CG_Range,1)
       struct_for_patch.Vertices([X,X+1],2) = ForPlot_CG_Range(tt,1)*-1;
       struct_for_patch.Vertices([X+2,X+3],2) = ForPlot_CG_Range(tt,1);
       X = X+4;
   end % FOR tt = 1:size(ForPlot_CG_Range,1)
     
   Plot2 = subplot('Position',[0.459 0.106 0.456 0.14]);
   patch(struct_for_patch,'LineStyle','none'); hold all
    
  
  %% plot bars with errors "f_barwitherr" & "f_rotateXLabels" for left/right plot      

   Color = [1 0 0; 0 0 1];
   bar2 = f_barwitherr(ForPlot_PA_Range(NumSameForBothSides+1:NumGaitParams,2:3),...
                       Color,ForPlot_PA_Mean(NumSameForBothSides+1:NumGaitParams,2:3),...
                       'grouped','LineWidth',1);
  
   set(bar2(1),'FaceColor','r','EdgeColor','r','LineStyle','none','LineWidth',1.4,'BarWidth',1);
   set(bar2(2),'FaceColor','b','EdgeColor',[0 0 1],'LineStyle','none','LineWidth',1.4,'BarWidth',1);
 
   set(gca,'XTick',1:1:NumGaitParams-NumSameForBothSides,'XTickLabel',...
       Cell(NumSameForBothSides+1:end,1)','XTickLabelRotation',45,...
       'FontSize',8,'YGrid','on'); % [0.08 0.1 0.819 0.14]
   box(gca,'on'); set(gca, 'Layer','top') % draw box on top
  
   ylim([MIN-1 MAX+1])
   xlim([0.5 NumGaitParams-NumSameForBothSides+0.5]); hold all
   XValues = 0.5:1:NumGaitParams-NumSameForBothSides+0.5;
   ZeroLine = plot(XValues,zeros(NumGaitParams-NumSameForBothSides+1,1)',...
                   'Color','k','LineWidth',0.8); % plot zero line
  
   % make legend
   annotation(gcf,'line',[0.15 0.18],[0.025 0.025],'LineWidth',1.5,'Color','k');   
   annotation(gcf,'textbox',[0.185 0 0.171 0.037],'FitBoxToText','on','String',...
                  'Bilateral (mean)','FontSize',8,'LineStyle','none'); %Text
              
   annotation(gcf,'textbox',[0.373 0 0.171 0.037],'FitBoxToText','on','String',...
                  '95% CI of norm','FontSize',8,'LineStyle','none'); %Text
   annotation(gcf,'textbox',[0.35 0.019 0.02 0.015],'String',{'    '},...
                  'BackgroundColor',GreyBackground,'LineStyle','none'); %rectangle 
              
   annotation(gcf,'line',[0.50 0.53],[0.025 0.025],'LineWidth',1.5,'Color','r');           
   annotation(gcf,'textbox',[0.535 0 0.171 0.037],'FitBoxToText','on','String',...
                  'Left (mean)','FontSize',8,'LineStyle','none','Color','r'); %Left
              
   annotation(gcf,'line',[0.63 0.66],[0.025 0.025],'LineStyle','--',...
                  'LineWidth',1.5,'Color','b'); %[0.35 0.38
   annotation(gcf,'textbox',[0.665 0 0.171 0.037],'FitBoxToText','on','String',...
                  'Right (mean)','FontSize',8,'LineStyle','none','Color','b'); %Right

              
   %% plot stipes to blue bars "f_StripesForBarplot"
   
    for m = 1:NumGaitParams-NumSameForBothSides
        x1 = m+0.03;
        x2 = m+0.26;
        f_StripesForBarplot(x1,x2,ForPlot_PA_Mean(NumSameForBothSides+m,3))
    end %FOR m = 1:size(ForPlot_PA_Mean,1)

  
   %% Page Number
   
   f_makeTextbox(figure1,'- 3 -',0.849,0.001,0.10,0.0,7,'none','right')
   
   
end %FUNCTION