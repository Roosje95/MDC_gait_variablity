%{ 
*********************************************************************************
Function "f_createPDF" linked to script "Auswertung_mitFormularen" & "Datenarchivierung_footmodel"                      
                    by Katrin Schweizer Oct. 2014
*********************************************************************************

Prints the figures defined by the figure handles in data to a postscript.
Transforms the postscript to PDF and deletes the postscript file.

INPUT: data = figure handles
       Path_Patientfolder_new = name of patient folder e.g. '4321g'
       PatientFolder = name of patient folder e.g. '4321g'
       Filename = name of pdf file e.g. '_PiG' of '_PiG_ToPrint'

%}

function f_createPDF(data,Path_Patientfolder_new,PatientFolder,Filename,Path_BenoetigteDateien)

    % print the first page to postscript
    print (data(1,1),'-dpsc',[Path_Patientfolder_new '\' PatientFolder Filename '.ps']);
    
    % append page 2-end to postscript
    for PP = 2:size(data,1) 
        print (data(PP,1),'-dpsc','-append',[Path_Patientfolder_new '\' PatientFolder Filename '.ps']);
    end %FOR PP = 2:size(data,1)

    % change postscript to pdf with function "f_ps2pdf"
    f_ps2pdf('psfile', [Path_Patientfolder_new '\' PatientFolder Filename '.ps'], ...
             'pdffile', [Path_Patientfolder_new '\' PatientFolder Filename '.pdf'],...
             'gspapersize', 'a4','verbose',0,... 
             'deletepsfile', 1,'gscommand',[Path_BenoetigteDateien,'\gs\gs9.18\bin\gswin64c.exe'],...
             'gslibpath',[Path_BenoetigteDateien,'\gs\gs9.18\lib'],...
             'gsfontpath',[Path_BenoetigteDateien,'\gs\gs9.18\lib'])

         
   %%
    if strcmp('_PiG',Filename) % if the PDF is the one to save
       disp(' ');
       disp('++++++++++++++++++++')
       disp('PDF was created')
       disp(Path_Patientfolder_new)
       disp('++++++++++++++++++++')
       
    elseif strcmp('_PiG_temp',Filename) 
       disp(' ');
       disp('++++++++++++++++++++')
       disp('PDF for secretary was created')
       disp(Path_Patientfolder_new)
       disp('++++++++++++++++++++') 
       
    elseif strcmp('_PiG_toPrint',Filename) 
       disp(' '); disp('Do you want to print the PDF now?')
       disp(' '); disp('Yes, open PDF          -------->  ENTER')
       disp(' '); disp('No, print later        -------->  0')
       disp(' '); PrintPDF = input('Selection: ','s');
       PrintPDF = lower( PrintPDF); disp(' ') 
       
       switch PrintPDF
          case {'0'}
          case {''}  % if PDF should be opened
    
          open([Path_Patientfolder_new '\' PatientFolder Filename '.pdf']);

          disp(' '); disp('Do you want to delete PDF for printing?')
          disp(' '); disp('Yes, delete          -------->  1')
          disp(' '); disp('No, do not delete    -------->  ENTER')
          disp(' '); PrintPDF_delete = input('Selection: ','s');
          PrintPDF_delete = lower( PrintPDF_delete); disp(' ') 

          switch PrintPDF_delete          
              case {'1'}
                   % deletes the PDF for printing. Works only, if PDF is
                   % closed and the path to the pdf can't have any empty
                   % fields (Leerschl�ge)
                    system(['del ' Path_Patientfolder_new '\' PatientFolder Filename '.pdf']);
                    
                    
                    disp(' ');
                    disp('++++++++++++++++++++')
                    disp('PDF for printing was deleted')
                    disp(Path_Patientfolder_new)
                    disp('++++++++++++++++++++')

              case {''} 
          end %SWITCH PrintPDF_delete
          
       end %SWITCH PrintPDF
       
    end %IF strcmp('_PiG',Filename)

end %FUNCTION
