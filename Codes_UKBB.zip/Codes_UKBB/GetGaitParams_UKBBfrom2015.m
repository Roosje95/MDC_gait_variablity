%% GetGaitParams_UKBBfrom2015
% gets gait params from UKBB data collected in set-up since 2015

% Needed: c3d files, parameter file, Codes_UKBB, Gait_algo_1, btk

% Input: VD & Struct made with c3dtomat_multiFolder.m
% Output: StructAllC3D,StructAllGC

% April 2020, Rosa Visscher
% Updated: underconstruction

clear all; clc; close all;

%% Settings

% file locations 
Path_data = ('Z:\Projects\NCM_CP\read_only\Data\Data_General\Data_Patients\UKBB_Gait_from2015\processedData_from2015');
Path_dest = ('Z:\Projects\NCM_CP\project_only\NCM_CP_MotorDevelopmentCurve\Data');
addpath(Path_data)
addpath(Path_dest)
addpath(genpath('Z:\Projects\NCM_CP\read_only\Codes\Codes_Basics\Codes_UKBB'));
addpath Z:\Projects\NCM_CP\read_only\Codes\Codes_General\1_GetGaitParams\UKBB_from2015

load('Z:\Projects\NCM_CP\project_only\NCM_CP_MotorDevelopmentCurve\Data\mat_info_fromAug2016.mat')
%% Load data, identify Heel Strike, extract angle position at HS
measurements = mat_info_barfuss(:,1);
total = length(measurements);
for x = 308:length(measurements)
    measurement = char(measurements{x,1});
    Direc_data = [Path_data '\' char(measurement)];
    cd(Direc_data) % move into subfolder subject
    subdirec = dir;
    subdirec(strncmp({subdirec.name}, '.', 1)) = []; % removes the . and .. entries
   
%     files_mat = dir('*.mat');
%         for j=1:length(files_mat)
%             namewithparameters = strfind(files_mat(j).name, 'parameters');
%             if~isempty(namewithparameters)
%                 parameters_mat = load(files_mat(j).name);
%                 parameters_c3d = fieldnames(parameters_mat);
%                 mat_info(x,12) = {[parameters_mat.(parameters_c3d{1,1}).Date]};
%                 continue
%             end%for-loop to extract parameters.mat info
%         end%for-loop mat files
            
        %% Extract data with UKBB script
        subject = measurement;
        findKinetics = strfind(char(mat_info{x,2}), 'N');
        if ~isempty(findKinetics)
            Kinetics = 0;%1=yes, 0=no
        else 
            Kinetics = 1;
        end 
        Copy_mat = 1;  
        Path_measurements = Direc_data;
        Path_temp = [Path_dest '\files_c3d'];
        Path_save = [Path_dest '\files_structs'];
        findEMG = strfind(char(mat_info{x,9}), '0');
        if isempty(findEMG)
            EMG_recorded = 1;
        else 
            EMG_recorded = 0;
        end 
        
        [StructAllC3D,StructAllGC] = A_generalScript_UKBBfrom2015(subject,Kinetics,Copy_mat,Path_measurements,Path_temp,Path_save,EMG_recorded);
        
        
    disp([x total]);
    
    cd .. % move up to subject folders
    
end
