function [StructAllC3D,StructAllG] = A_generalScript_UKBB(subject,Kinetics,Copy_mat,Path_measurements,Path_temp,Path_save)
%A_generalScript_UKBB function of the Script A_generalScript written by
%M. Freslier - August 2018
%   Reads in the C3D files marker trajectories, EMG, forces gait events from the
%   selected patient and gives out the gaitparameters, joint angles & moments, GRF, EMG signals
   
% Get into Patient folder
Path_measurements = split(Path_measurements,'\');
Path_measurements(8) = {subject{1,1}};
Path_measurements = strjoin(Path_measurements,'\');
% define saving location
Path_save = split(Path_save,'\');
Path_save(8) = {subject{1,1}};% 7 or 8 or 9, {} are sometimes needed..
Path_save = strjoin(Path_save,'\');

%% select the measurement folder
Path_Patientfolder = Path_measurements; %uigetdir(Path_measurements);
% extract name of patient folder
pathDetailed = strsplit(Path_Patientfolder,'\');  
PatientFolder = pathDetailed{size(pathDetailed,2)};

% if ~exist (Path_measurements)
%     Path_measurements = split(Path_measurements,'\');
%     Path_measurements(6) = {'UKBB_Gait_from2015'};
%     Path_measurements(7) = {'processedData_from2015'};
%     Path_measurements = strjoin(Path_measurements,'\');
%     Path_Patientfolder = Path_measurements;
%     pathDetailed = strsplit(Path_Patientfolder,'\');  
%     PatientFolder = pathDetailed{size(pathDetailed,2)};
% end
% create measurement folder in the new work folder (defined with
% Path_temp)
Path_Patientfolder_new = [Path_temp,'\',PatientFolder];
if isempty(dir(Path_Patientfolder_new))
    mkdir(Path_Patientfolder_new) %make a folder
else %if the patient folder already exists
    delete([Path_Patientfolder_new,'\*.*'])
end
if Copy_mat == 1
    f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'mat');
end

%% ---> copy of the c3d's files
%{
  You could copy all the c3d's files without any modifications.
  But if you want to further use the gait cycles with good kinetics or if
  you want only analysed trials (N..,K..,B..,L..,R..,static), you may have
  to run the second script (it will add some general event(s) to specify
  which gait cycles have good kinetics, especially for measurement made
  between 05.2014 and 08.2016)
%}

% % (1) ---> copy of all c3d's files
% f_copyFileType(Path_Patientfolder,Path_Patientfolder_new,'c3d');
% [outCheck,c3d_infos] = f_checkTrialType(Path_Patientfolder_new);

% (2) ---> copy of static and analysed (N..,K..,B..,L..,R..) c3d's files
% RepTrials won't be interpreted as analysed trial: you may have to rename
% it with one of the above letters in first place of the filename.

[outCheck,c3d_infos] = f_copyCheck_c3dFiles(Path_Patientfolder,Path_Patientfolder_new);

    %% stop the script if no c3d trials found
    if ~outCheck
        disp(' ')
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        % stop the script execution
        return
    else
        clear outCheck
    end
    
%% ---> obtain a list of the gait cycles
% if you want to delete some trials from the 'c3d_infos' list, you could
% delete per hand the corresponding row(s) in the Matlab workspace or write
% your own script for it
if Kinetics == 0
    % % (1) ---> if you are only interested in the kinematik or EMG (gait cycles with good
    % % kinetics are not important), run the following script
    out_collect = 1;
    disp(' ');
    for files = 1:length(c3d_infos)
        switch c3d_infos(files).Processed
            case {'KineticsUndefined','Kinetics','NoKinetics','Unknown'}
                c3d_acq = btkReadAcquisition([Path_Patientfolder_new '\' c3d_infos(files).filename]);
                disp(['--- ' c3d_infos(files).filename ': extract gait cycles ---']);
                [out_collect_GC,c3d_infos(files).gaitcycles] = ...
                    f_collect_gaitCycles_NoKinetics(c3d_acq);
                btkDeleteAcquisition(c3d_acq);
                out_collect = out_collect * out_collect_GC;
           otherwise
               continue
        end
    end
else
    % (2) ---> if you are only interested in the gait cycles with good kinetics, run the
    % following script
    % it is assumed that the data have kinetics...
    out_collect = 1;
    disp(' ');
    for files = 1:length(c3d_infos)
        switch c3d_infos(files).Processed
            case 'Kinetics'
                c3d_acq = btkReadAcquisition([Path_Patientfolder_new '\' c3d_infos(files).filename]);
                disp(['--- ' c3d_infos(files).filename ': extract gait cycles ---']);
                [out_collect_GC,c3d_infos(files).gaitcycles] = ...
                    f_collect_gaitCycles_Kinetics(c3d_acq);
                btkDeleteAcquisition(c3d_acq);
                out_collect = out_collect * out_collect_GC;
            otherwise
                continue
        end
    end
end
    %% stop the script if no c3d trials found
    if ~out_collect
        disp(' ')
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        % stop the script execution
        return
    else
        clear out_collect files c3d_acq out_collect_GC
    end

%% extract all the data for each c3d selected (from c3d_infos)
%% list of all the gait cycles
% information from EMG has to be determined: it is possible from param.mat
% or it has to be given from another source for older data
    % needs more adaptations: if no .mat...
%     Params4_c3d = load([Path_Patientfolder '\' PatientFolder '_parameters.mat']); %RV changed importdata to load
%     if ~isempty(Params4_c3d.Params4_c3d.EMG_Setup)%RV changed name struct(Params4_c3d.c3d_parameters.EMG_Setup Params4_c3d.Params4_c3d.EMG_Setup)
%         EMG_recorded = 'y';
%     else
%         EMG_recorded = 'n';
%     end
    EMG_recorded = 'n';
    %out_list = 1; %RV seems to be unused, check if it works like this
    [out_list,allGaitCycles] = f_GaitGycles_List(c3d_infos,EMG_recorded);
    %% stop the script if there is a problem to determine the informations
    if ~out_list
        disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
        return
    else
        clear out_list
    end
    
%% makes structs with kinematics, kinetics, EMG, temporal-Distance parameters
    [out_label,StructAllGC,StructAllC3D,DataForCalc,Trials,TrialNamePlot] = ...
            f_loadC3d_buildStructs(Path_Patientfolder_new,allGaitCycles,EMG_recorded);
    %% stop the script if there is a problem with the marker labelling
    if ~out_label
            disp(' ');
            disp('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
            disp('!!!!!!!!!!!!!! Script stopped !!!!!!!!!!!!!')
            return
    else
        clear out_label
    end
    
    %% Saving results
    PIGoutcomesNormalized = fullfile(Path_save, 'PIGoutcomesNormalized.mat');
    PIGoutcomesNonnormalized = fullfile(Path_save, 'PIGoutcomesNonnormalized.mat');
    save(PIGoutcomesNormalized, 'StructAllGC')
    save(PIGoutcomesNonnormalized, 'StructAllC3D')
end

