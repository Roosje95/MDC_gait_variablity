%{
********************************************************************************* 
     Function "f_zerolevelEMG" linked to script "Auswertung_mitFormularen"
                       used in "f_load_c3d"
                    by Katrin Schweizer March 2014
*********************************************************************************

Zero-levels EMG data and sets empty data to NaN

INPUT: struct = Analog struct as given from c3d
       EMG_recorded = Info on whether EMG was recorded ('y')or not ('n')

OUTPUT: struct = same fields as input struct, but EMG data are zero levelled
                 and empty data are set to NaN

%}

function struct = f_zerolevelEMG(struct,EMG_recorded)

   Fieldnames2 = fieldnames(struct);  

   for j = 1:size(Fieldnames2,1)
       
       % for EMG data only --> zero leveln
       if Fieldnames2{j,1}(1) == 'E';
       
          data = struct.(Fieldnames2{j,:});
          
          MeanEMG = nanmean(data,1); %Mean of EMG signal over time
       
          % only if the Mean is not already zero, otherwise we devide by zero
          if MeanEMG ~= 0          
             struct.(Fieldnames2{j,:}) = data-MeanEMG;
          end %IF MeanEMG ~= 0 
        
          %if no EMG was recorded set data to NaN
          if EMG_recorded == 'n'
             struct.(Fieldnames2{j,:}) = NaN(size(data));
          end %IF EMG_recorded == 'n'
      
       end %IF Fieldnames2{j,1}(1) == 'v';
       
       % Check for empty data and replace by NaN
       data = struct.(Fieldnames2{j,:}).*100000000000; % times 10000000000 to make the number bigger,
                     % as some signals are different from zero in such a
                     % small number, that matlab takes it for zero!
                     
       if sum(data) == 0 % if all data are zero --> no EMG measured on that channel
          struct.(Fieldnames2{j,:}) = NaN(size(data));
       end %IF sum(data) == 0

   end %FOR Fieldnames2 = fieldnames(data);

end %FUNCTION