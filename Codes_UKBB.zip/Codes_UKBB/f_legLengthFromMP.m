function [lleglength,rleglength] = f_legLengthFromMP(path_MP)

delimiter = {' ','='};
%% Format string for each line of text:
%   column1: text (%s)
%	column2: double (%f)
% For more information, see the TEXTSCAN documentation.
formatSpec = '%s%f%[^\n\r]';

%% Open the text file.
fileID = fopen(path_MP,'r');

dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'EmptyValue' ,NaN, 'ReturnOnError', false);

%% Close the text file.
fclose(fileID);

%% find the indeces of legLength in the dataArray
ind_left = find(strcmp(dataArray{1},'$LLegLength'));
ind_right = find(strcmp(dataArray{1},'$RLegLength'));

%% extract leg lengths from the dataArray
lleglength = dataArray{2}(ind_left);
rleglength = dataArray{2}(ind_right);