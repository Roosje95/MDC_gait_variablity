%{
*********************************************************************************
                   Function "f_Marker2_c3d" 
                     by Katrin Schweizer Dez. 2014
                    adapted by Marie F. July 2017
*********************************************************************************

Writes marker diameter to c3d-file (Points > Descriptions)
                                     
INPUT
  MarkerDiameter4_c3d = cell including the names of the marker (1. column)
                        and the marker diameter (2. column) (obtained from
                        f_extractMarkerDiameter)
  acq = data aquisition for btk

OUTPUT
  acq = new data aquisition for btk with informations about Marker diameter

%}

function acq = f_Marker2_c3d(MarkerDiameter4_c3d,acq)

Markers = btkGetMarkers(acq);
FieldsMarkers = fieldnames(Markers);

%**************************************************************************         
     %% Write information to Point>Description in c3d file
%**************************************************************************
     
    for i = 1:size(MarkerDiameter4_c3d,1) 
        
        %if the marker was labelled
        if sum(ismember(FieldsMarkers,MarkerDiameter4_c3d{i,1}))>0
 
           Input = [MarkerDiameter4_c3d{i,1} '_' MarkerDiameter4_c3d{i,2}];  
 
           [points, pointsInfo] = btkSetPointDescription(acq,MarkerDiameter4_c3d{i,1},Input);
       
        end 
        
     end % FOR i = 1:size(MarkerDiameter4_c3d,1)

%**************************************************************************     
    %% Write the new Point>Description into acquision (c3d file)
%**************************************************************************

%     btkWriteAcquisition(acq,Path_c3d);
    
    
end %FUNCTION