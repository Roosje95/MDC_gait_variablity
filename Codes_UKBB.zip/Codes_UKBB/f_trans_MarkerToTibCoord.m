%{ 
*********************************************************************************
              Function "f_calc_TibiaTorsion" linked to 
             script "Auswertung" run from "f_write_StaticInfo"
                     by Katrin Bracht Dec. 2015
*********************************************************************************

Transforms the markers from global (lab) coordinates to the tibia
coordinates

INPUT
   KneeMed = knee joint centre
   KneeLat = KAX-Marker of Knee Alignment Device
   AnkleMed = medial malleolus marker
   AnkleLat = lateral malleolus marker
   sign_side = is 1 (positive) for left foot, -1 (negative) for the right side

OUTPUT
   Trans_KneeMed = knee joint marker transformed into tibia coordinate system
   Trans_KneeLat = KAX-Marker transformed into tibia coordinate system
   Trans_AnkleMed = medial malleolus marker transformed into tibia coordinate system
   Trans_AnkleLat = lateral malleolus marker transformed into tibia coordinate system
%}

function [Trans_KneeMed,Trans_KneeLat,Trans_AnkleMed,Trans_AnkleLat] ...
             = f_trans_MarkerToTibCoord(KJC,KAX,ANKM,ANK,Tib_X,Tib_Y,Tib_Z)

%% Transform Marker to tibia coordinate system
    for i = 1:size(ANK,1)
        
        transMat = cat(2,Tib_X(i,:)',Tib_Y(i,:)',Tib_Z(i,:)'); % transformation matrix
        inv_transMat = inv(transMat); % inverse transformation matrix

        Trans_KneeMed(i,:) = inv_transMat * KJC(i,:)';
        Trans_KneeLat(i,:) = inv_transMat * KAX(i,:)';
        Trans_AnkleMed(i,:) = inv_transMat * ANKM(i,:)';
        Trans_AnkleLat(i,:) = inv_transMat * ANK(i,:)';
           
    end %FOR i = 1:size(ANK,1)
    
end %FUNCTION f_trans_MarkerToTibCoord
