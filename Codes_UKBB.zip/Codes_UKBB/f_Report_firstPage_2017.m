%{ 
*********************************************************************************
  Function "f_Report_firstPage" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer April 2014
*********************************************************************************

Creates the first page of the report with patient information (Name, Dignosis...).

INPUT
  Path_BenoetigteDateien = Path to "Ben�tigteDateien"
  Param = Struct with data from google formular
  ID = Patient number (e.g. 4551a)

OUTPUT
  Figure for 1st page report save in the postscript.
%}

function Fig = f_Report_firstPage_2017(Path_BenoetigteDateien,Param,ID)

   % Create figure
   Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]


   %% Header

   % Logo
   Logo = imread([Path_BenoetigteDateien,'\Logo_UKBB.jpg']);
               
   axes1 = axes('Parent',Fig,'YTick',zeros(1,0),'YDir','reverse','YColor',[1 1 1],...
                'XTick',zeros(1,0),'XColor',[1 1 1],'Position',[0.78 0.87 0.2 0.1],...
                'DataAspectRatio',[1 1 1],'Visible','off');    % Define subplot to plot Logo
            
   hold(axes1,'all');
   
   % Plot logo into subplot
   image(Logo,'Parent',axes1); 
   
   % Visum Ganglabor:
   annotation(Fig,'textbox',[0.06 0.975 0.18 0.02],'String',{'Visum Ganglabor:'},...
             'FontWeight','bold','FitBoxToText','off','LineStyle','none');

   % Physio: xy1
   annotation(Fig,'textbox',[0.24 0.975 0.28 0.02],'String',['Kl. Untersuchung: ',Param.Physio],...
             'FitBoxToText','off','LineStyle','none');

   % BW: xy2
   annotation(Fig,'textbox',[0.5 0.975 0.2 0.02],'String',['BW: ',Param.Scientist],...
             'FitBoxToText','off','LineStyle','none');
         
         % BW: xy3
   annotation(Fig,'textbox',[0.66 0.975 0.33 0.02],'String',['zus�tzl. Mitarb. UKBB: ',Param.FurtherPersonUKBB],...
             'FitBoxToText','off','LineStyle','none');

   % Labor f�r Bewegungsuntersuchungen
   annotation(Fig,'textbox',[0.25 0.94 0.5 0.02],'String',{'Labor f�r Bewegungsuntersuchungen'},...
             'HorizontalAlignment','center','FontWeight','bold','FontSize',14,...
             'FitBoxToText','off','LineStyle','none');

   % Universit�ts-Kinderspital beider Basel (UKBB)
   annotation(Fig,'textbox',[0.25 0.915 0.5 0.02],...
             'String',{'Universit�ts-Kinderspital beider Basel (UKBB)'},...
             'HorizontalAlignment','center','FontWeight','bold','FontSize',11,...
             'FontAngle','italic','FitBoxToText','off','LineStyle','none');

   % Spitalstrasse 33','Postfach','CH-4031 Basel, Schweiz
   annotation(Fig,'textbox',[0.385 0.85 0.23 0.06],...
             'String',{'Spitalstrasse 33','Postfach','CH-4031 Basel, Schweiz'},...
             'HorizontalAlignment','center','FitBoxToText','off',...
             'LineStyle','none');

   % Line
   annotation(Fig,'line',[0.06 0.94],[0.84 0.84],'linestyle','-.');


   %% Datum:
   annotation(Fig,'textbox',[0.06 0.81 0.18 0.02],'String',{'Datum:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.26 0.81 0.18 0.02],'String',Param.Date,...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');


   %% Ganglabor ID:
   annotation(Fig,'textbox',[0.72 0.81 0.18 0.02],'String',{'Ganglabor ID:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.86 0.81 0.1 0.02],'String',ID,...
              'FontSize',11,'FitBoxToText','off','LineStyle','none');


   %% Name, Vorname:
   annotation(Fig,'textbox',[0.06 0.78 0.18 0.02],'String',{'Name, Vorname:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.26 0.78 0.45 0.02],'String',{[Param.Surname,', ',Param.Firstname]},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
         
   %% Geschlecht:
   annotation(Fig,'textbox',[0.72 0.78 0.18 0.02],'String',{'Geschlecht:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.85 0.78 0.1 0.02],'String',{Param.Gender},...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');
         
   %% Geburtsdatum:
   annotation(Fig,'textbox',[0.06 0.75 0.18 0.02],'String',{'Geburtsdatum:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.26 0.75 0.18 0.02],'String',{Param.Birthday},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');

   % Line
   annotation(Fig,'line',[0.06 0.94],[0.73 0.73],'linestyle','-.');
         
   %% Diagnose:
   annotation(Fig,'textbox',[0.06 0.70 0.18 0.02],'String',{'Diagnose:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   Diagnostic_infos = strrep(Param.Diagnostic_infos,'; ','\newline');
   Therapie_infos = strrep(Param.Therapie_infos,'; ','\newline');
   
   annotation(Fig,'textbox',[0.26 0.59 0.68 0.13],'String',{Diagnostic_infos,'',Therapie_infos},...
              'FontSize',11,'FitBoxToText','off','LineStyle','none');

   %% GMFCS:
   annotation(Fig,'textbox',[0.06 0.57 0.18 0.02],'String',{'GMFCS:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.26 0.57 0.1 0.02],'String',{Param.GMFCS},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
         
   %% FMS (5,50,500m):
   annotation(Fig,'textbox',[0.06 0.55 0.18 0.02],'String',{'FMS (5,50,500m):'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   FMS = [Param.FMS_5m,', ',Param.FMS_50m,', ',Param.FMS_500m];
   annotation(Fig,'textbox',[0.26 0.55 0.1 0.02],'String',{FMS},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Comment
   annotation(Fig,'textbox',[0.36 0.55 0.58 0.04],'String',{Param.GMFCS_comment,Param.FMS_comment},...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');
         
   %% Fragestellung:
   annotation(Fig,'textbox',[0.06 0.52 0.18 0.02],'String',{'Fragestellung:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   Question = strrep(Param.Question,'; ','\newline');
   annotation(Fig,'textbox',[0.26 0.45 0.68 0.09],'String',Question,...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');

   % Line
   annotation(Fig,'line',[0.06 0.94],[0.45 0.45],'linestyle','-.');
         
   %% Bedingungen:
   annotation(Fig,'textbox',[0.06 0.42 0.18 0.02],'String',{'Bedingungen:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');

   % Data
   if strcmp(Param.Left_Heelrise,'') % in case someone has nothing filled in in the google form --> set parameter to zero
      Param.Left_Heelrise = '0';
   end
   if strcmp(Param.Left_Solerise,'')
      Param.Left_Solerise = '0';
   end
   
   if strcmp(Param.Right_Heelrise,'')
      Param.Right_Heelrise = '0';
   end
   if strcmp(Param.Right_Solerise,'')
      Param.Right_Solerise = '0';
   end
   
   Condition{1,1} = ['Links: ',Param.Left_Condition,' ',Param.Left_Condition_infos];
   
   if ~strcmp(Param.Left_Heelrise,'0') && strcmp(Param.Left_Solerise,'0')
      Condition{1,1} = [Condition{1,1},', Fersenerh�hung ',Param.Left_Heelrise,' cm'];
   elseif strcmp(Param.Left_Heelrise,'0') && ~strcmp(Param.Left_Solerise,'0')
      Condition{1,1} = [Condition{1,1},', Sohlenerh�hung ',Param.Left_Solerise,' cm'];
   elseif ~strcmp(Param.Left_Heelrise,'0') && ~strcmp(Param.Left_Solerise,'0')
      Condition{1,1} = [Condition{1,1},', Fersenerh�hung ',Param.Left_Heelrise,' cm',', Sohlenerh�hung ',Param.Left_Solerise,' cm']; 
   end %IF Param.Left_Heelrise ~= '0' && Param.Left_Solerise == '0'
   
   Condition{1,2} = ['Rechts: ',Param.Right_Condition,' ',Param.Right_Condition_infos];
   if ~strcmp(Param.Right_Heelrise,'0') && strcmp(Param.Right_Solerise,'0')
      Condition{1,2} = [Condition{1,2},', Fersenerh�hung ',Param.Right_Heelrise,' cm'];
   elseif strcmp(Param.Right_Heelrise,'0') && ~strcmp(Param.Right_Solerise,'0')
      Condition{1,2} = [Condition{1,2},', Sohlenerh�hung ',Param.Right_Solerise,' cm'];
   elseif ~strcmp(Param.Right_Heelrise,'0') && ~strcmp(Param.Right_Solerise,'0')
      Condition{1,2} = [Condition{1,2},', Fersenerh�hung ',Param.Right_Heelrise,' cm',', Sohlenerh�hung ',Param.Right_Solerise,' cm']; 
   end %IF Param.Right_Heelrise ~= '0' && Param.Right_Solerise == '0' 

   % if any help was needed while walking
   if ~strcmp(Param.Help,'keine')
      Condition{1,3} = [Param.Help,' ',Param.Side_Help,' ',Param.Help_infos];
   end %IF ~strcmp(Param.Help,'keine')
       
%    annotation(Fig,'textbox',[0.269 0.286 0.663 0.062],'String',Condition,...
   annotation(Fig,'textbox',[0.26 0.33 0.68 0.11],'String',Condition,...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');
    
   %% Messungen:
   annotation(Fig,'textbox',[0.06 0.31 0.18 0.02],'String',{'Messungen:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   Measure = [Param.Meas_Type_1,' ',Param.Meas_Type_2,' ',Param.Meas_Type_3,' ',Param.Meas_Type_4];
   annotation(Fig,'textbox',[0.26 0.31 0.45 0.02],'String',Measure,...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');

   %% EMG-Kan�le:
   annotation(Fig,'textbox',[0.72 0.31 0.18 0.02],'String',{'EMG-Kan�le:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.85 0.31 0.18 0.02],'String',Param.EMG_channel_nb,...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');

   %% Model:
   annotation(Fig,'textbox',[0.06 0.28 0.18 0.02],'String',{'Model:'},...
             'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');
   % Data
   annotation(Fig,'textbox',[0.26 0.28 0.45 0.02],'String',Param.Model,...
             'FontSize',11,'FitBoxToText','off','LineStyle','none');

   % Line
   annotation(Fig,'line',[0.06 0.94],[0.265 0.265],'linestyle','-.');
          
   %% Bemerkungen:
%    annotation(Fig,'textbox',[0.06 0.21 0.88 0.02],'String',{'Bemerkungen:'},...
%              'FontWeight','bold','FontSize',11,'FitBoxToText','off','LineStyle','none');





%    Measure_comment = strrep(Param.Measure_comment,'; ','\newline');
%    EMG_comment = strrep(Param.EMG_comment,'; ','\newline');
%    clinical_exam_comment = strrep(Param.clinical_exam_comment,'; ','\newline');
%    % Data
%    x = 1;
%    if ~strcmp(Param.Measure_comment,'')
%       Comment{1,x} = ['Ganganalyse: ',Measure_comment];
%       x = x+1;
%    else Comment{1,x} = '';
%    end %IF ~strcmp(Param.Measure_comment,'')
%    
%    if ~strcmp(Param.EMG_comment,'')
%       Comment{1,x} = ['EMG: ',EMG_comment];
%       x = x+1;
%    else Comment{1,x} = '';
%    end %IF ~strcmp(Param.EMG_comment,'')
%    
%    if ~strcmp(Param.clinical_exam_comment,'')
%       Comment{1,x} = ['Klinik: ',clinical_exam_comment];
%    else Comment{1,x} = '';
%    end %IF ~strcmp(Param.clinical_exam_comment,'')
%    
%    annotation(Fig,'textbox',[0.269 0.039 0.665 0.104],'String',Comment,...
%              'FontSize',11,'FitBoxToText','off','LineStyle','none','FontWeight','bold');

         
    %% Page Number
    f_makeTextbox(Fig,'- 1 -',0.849,0.001,0.10,0.0,7,'none','right')

end %FUNCTION