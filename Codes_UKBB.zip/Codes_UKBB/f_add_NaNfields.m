%{
********************************************************************************* 
     Function "f_add_NaNfields" linked to script "Auswertung_mitFormularen"
                       used in "f_load_c3d"
                    by Katrin Schweizer Jan. 2014
*********************************************************************************

Adds fields to the struct if they are missing (e.g. upper body angles or EMG) and 
removes fields if they are not used (e.g. upper body kinetics)


INPUT: data = Struct as derived by c3d (e.g. Angles)
       KeepFieldnames = Names of the fields that should be filled into the struct
                        (e.g. upper body angles)
       DeleteFieldnames = Names of the fields that should be deleted from the struct
                          (e.g. LWristMoment)

OUTPUT: data = Input struct supplemented by the fields defined by "KeepFieldnames"
               --> Matrices are NaN and with upper body kinetic fields removed

%}

function data = f_add_NaNfields(data,KeepFieldnames,DeleteFieldnames)

    namefield1 = fieldnames(data);
    
    data_NaN = NaN(size(data.(namefield1{1,1}))); % Vector with NaNs
        
    % Over all fieldnames that should be kept/created
    for i = 1:size(KeepFieldnames,1)
        
        %if there exist no such fieldname, make a field and fill with NaNs
        if ~isfield(data,KeepFieldnames{i,1});           
           data.(KeepFieldnames{i,1}) = data_NaN;              
        end %IF ~isfield(data,KeepFieldnames{i,1});
        
    end %FOR i = 1:size(KeepFieldnames)
    
    %only for kinetics (not for angles or EMG = "noDeletion")
    if ~strcmp('noDeletion',DeleteFieldnames)
       
       % Loop over all fieldnames that should be deleted
       for i = 1:size(DeleteFieldnames,1)
           
           %if there exists upper body kinetics delete these fields
           if isfield(data,DeleteFieldnames{i,1});
              data = rmfield(data,DeleteFieldnames{i,1});
           end %IF ~isfield(data,DeleteFieldnames{i,1});
           
       end %FOR i = 1:size(DeleteFieldnames) 
       
    end %IF ~strcmp('noDeletion',DeleteFieldnames)

end %FUNCTION