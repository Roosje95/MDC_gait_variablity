%{
********************************************************************************* 
     Function "f_replaceKinetic" linked to script "Auswertung..."                     
                    by Katrin Bracht March 2018
*********************************************************************************

Replaces the NaNs in struct "data" with kinetic data, if they are good for
the current gait cycle

INPUT: data = Struct "StructNaNKinetic" similar to StructC3D but with kinetic NaN
       Side = Side current gait cycle
       EV1 = first event (e.g. first foot strike)
       EV2 = second event (e.g. second foot strike)
       DataKinetic = Struct "StructC3D" with all kinetic data (also the not good values)

OUTPUT: data = Input struct, kinetic data are filled in if good for the current gait cycle

%}

function [data] = f_replaceKinetic(data,Side,EV1,EV2,DataKinetic)

        Fieldnames1 = {'Moment','Power','Force'}'; 

        for j = 1:size(Fieldnames1,1) 
            Fieldnames2 = fieldnames(data.((Fieldnames1{j,:})));

            for k = 1:size(Fieldnames2,1)  
                Fieldnames3 = fieldnames(data.(Fieldnames1{j,:}).(Fieldnames2{k,:}));

                for l = 1:size(Fieldnames3,1)  
                    data.(Fieldnames1{j,:}).(Fieldnames2{k,:}).(Fieldnames3{l,:}).(Side)(EV1:EV2,1) = DataKinetic.(Fieldnames1{j,:}).(Fieldnames2{k,:}).(Fieldnames3{l,:}).(Side)(EV1:EV2,1);
                    
                end %FOR k = 1:size(Fieldnames3,1)  
            end %FOR j = 1:size(Fieldnames2,1)       
        end %FOR i = 1:size(namefield1,1)
    
end %FUNCTION