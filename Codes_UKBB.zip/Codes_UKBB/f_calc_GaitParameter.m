%{ 
*********************************************************************************
     Function "f_calc_GaitParameter" linked to xxx
                          runs from "xxx"
                    by Frank Behrendt April 2018
*********************************************************************************
https://www.vicon.com/faqs/software/how-does-nexus-plug-in-gait-and-polygon-calculate-gait-cycle-parameters-spatial-and-temporal
- Walking speed: is stride length divided by stride time
- Stride time: time between successive ipsilateral foot strikes
- Stride length: is the distance from IP1 to IP2
- Step length is the distance from contralateral Foot off to ispilateral Foot Strike
- Single support: time from contralateral foot off to contralateral foot contact
- Opposite Foot Contact: time of contralateral foot contact
- Foot Off: time of ipsilateral foot off
- DoubleSupport: Duration from Foot Strike contra to Foot Off ipsi
- Cadence: number of strides per unit time (usually per minute)
- Stride width: is the distance from CP to CPP 
    IP1 is the ipsilateral marker's position at the first ipsilateral foot contact.
    IP2 is the ipsilateral marker's position at the second ipsilateral foot contact.
    CP is the contralateral marker's position at the contralateral foot contact.
    CPP is CP projected onto the IP1 to IP2 vector.

INPUT
    MarkersC3D = Struct with all markers similar to output from c3d but with corrected gait direction
    freq = Vicon frequency

OUTPUT

%}


function GaitParam = f_calc_GaitParameter(GC_side,MarkersC3D,EventsFrames,freq)


    if strcmp(GC_side,'right') == 1
       LengthGaitcycle = EventsFrames.Right_Foot_Strike(2)-EventsFrames.Right_Foot_Strike(1); %in frames
    elseif strcmp(GC_side,'left') == 1
       LengthGaitcycle = EventsFrames.Left_Foot_Strike(2)-EventsFrames.Left_Foot_Strike(1);
    end
    
    %*******************************    
    % Stride Length in m 

     if strcmp(GC_side,'right') == 1
         stride = MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(2),1:2) - MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(1),1:2);
         GaitParam.Dummy.Stride_Length.Right = sqrt((stride(1))^2 + (stride(2))^2)/1000;  % Stride length in m
         GaitParam.Dummy.Stride_Length.Left = NaN;
     elseif strcmp(GC_side,'left') == 1
         stride = MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(2),1:2) - MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(1),1:2);
         GaitParam.Dummy.Stride_Length.Left = sqrt((stride(1))^2 + (stride(2))^2)/1000;  % Stride length in m
         GaitParam.Dummy.Stride_Length.Right = NaN;
     end
    %*******************************


    %*******************************
    % Stride Time in seconds

    if strcmp(GC_side,'right') == 1
    GaitParam.Dummy.Stride_Time.Right = (EventsFrames.Right_Foot_Strike(2)-EventsFrames.Right_Foot_Strike(1))/freq; 
    GaitParam.Dummy.Stride_Time.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
    GaitParam.Dummy.Stride_Time.Left=(EventsFrames.Left_Foot_Strike(2)-EventsFrames.Left_Foot_Strike(1))/freq; 
    GaitParam.Dummy.Stride_Time.Right = NaN;
    end
    %*******************************


    %*******************************
    % Walking Speed in m/s

    if strcmp(GC_side,'right') == 1
        GaitParam.Dummy.Walking_Speed.Right = GaitParam.Dummy.Stride_Length.Right / GaitParam.Dummy.Stride_Time.Right;
        GaitParam.Dummy.Walking_Speed.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
        GaitParam.Dummy.Walking_Speed.Left = GaitParam.Dummy.Stride_Length.Left / GaitParam.Dummy.Stride_Time.Left;  
        GaitParam.Dummy.Walking_Speed.Right = NaN;
    end

    %*******************************


    %*******************************
    % Step Length in m

    if strcmp(GC_side,'right') == 1
         GaitParam.Dummy.Step_Length.Right = (MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(2),1) - MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(1),1))/1000;
         GaitParam.Dummy.Step_Length.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
         GaitParam.Dummy.Step_Length.Left = (MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(2),1) - MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(1),1))/1000;         
         GaitParam.Dummy.Step_Length.Right = NaN;        
%         IP2 = MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(2),1:3);
%         IP2(:,2) = [];         
%         CP = MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(1),1:3);
%         CP(:,2) = [];        
%         step = norm(IP2-CP)/1000;
%         
%         norm(MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(2),1:3) -  MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(1),(1:3)))/1000
        
%          step = MarkersC3D.LTOE(EventsFrames.Left_Foot_Strike(1),1:2) - MarkersC3D.RTOE(EventsFrames.Right_Foot_Strike(1),1:2);
%          GaitParam.Dummy.Step_Length.Left = sqrt((step(1))^2 + (step(2))^2)/1000;  % StepLength in m

    end
    %*******************************


    %*******************************
    % SingleSupport in s

    if strcmp(GC_side,'right') == 1
     GaitParam.Dummy.Single_Support.Right = (EventsFrames.Left_Foot_Strike-EventsFrames.Left_Foot_Off)/freq;
     GaitParam.Dummy.Single_Support.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
     GaitParam.Dummy.Single_Support.Left = (EventsFrames.Right_Foot_Strike-EventsFrames.Right_Foot_Off)/freq;
     GaitParam.Dummy.Single_Support.Right = NaN;
    end
    %******************************* 


    %*******************************
    % OppositeFootContact in % after first heel strike ipsi

    if strcmp(GC_side,'right') == 1
       GaitParam.Dummy.Opposite_Foot_Contact.Right = (EventsFrames.Left_Foot_Strike(1)-EventsFrames.Right_Foot_Strike(1))/LengthGaitcycle*100;
       GaitParam.Dummy.Opposite_Foot_Contact.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
       GaitParam.Dummy.Opposite_Foot_Contact.Left = (EventsFrames.Right_Foot_Strike(1)-EventsFrames.Left_Foot_Strike(1))/LengthGaitcycle*100;
       GaitParam.Dummy.Opposite_Foot_Contact.Right = NaN;
    end

    %******************************* 


    %*******************************
    % FootOff: time in % - ipsilateral foot off after first heel strike ipsi

    if strcmp(GC_side,'right') == 1
       GaitParam.Dummy.Foot_Off.Right = (EventsFrames.Right_Foot_Off(1)-EventsFrames.Right_Foot_Strike(1))/LengthGaitcycle*100;
       GaitParam.Dummy.Foot_Off.Left = NaN;
    elseif strcmp(GC_side,'left') == 1        
       GaitParam.Dummy.Foot_Off.Left = (EventsFrames.Left_Foot_Off(1)-EventsFrames.Left_Foot_Strike(1))/LengthGaitcycle*100;
       GaitParam.Dummy.Foot_Off.Right = NaN;
    end
    %*******************************

    
    %*******************************
    % Opposite FootOff: time in % - contralateral foot off after first heel strike ipsi

    if strcmp(GC_side,'right') == 1              
       GaitParam.Dummy.Opposite_Foot_Off.Right = (EventsFrames.Left_Foot_Off(1)-EventsFrames.Right_Foot_Strike(1))/LengthGaitcycle*100;
       GaitParam.Dummy.Opposite_Foot_Off.Left = NaN;
    elseif strcmp(GC_side,'left') == 1 
       GaitParam.Dummy.Opposite_Foot_Off.Left = (EventsFrames.Right_Foot_Off(1)-EventsFrames.Left_Foot_Strike(1))/LengthGaitcycle*100;
       GaitParam.Dummy.Opposite_Foot_Off.Right = NaN;
    end
    %*******************************
    
    
    %*******************************
    % DoubleSupport in s
    % Double support: time from ipsilateral foot contact to contralateral foot off plus time from contralateral foot contact to ipsilateral foot off. 

    if strcmp(GC_side,'right') == 1
       GaitParam.Dummy.Double_Support.Right = (EventsFrames.Left_Foot_Off(1)-EventsFrames.Right_Foot_Strike(1)+EventsFrames.Right_Foot_Off(1)-EventsFrames.Left_Foot_Strike(1))/freq;
       GaitParam.Dummy.Double_Support.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
       GaitParam.Dummy.Double_Support.Left = (EventsFrames.Right_Foot_Off(1)-EventsFrames.Left_Foot_Strike(1)+EventsFrames.Left_Foot_Off(1)-EventsFrames.Right_Foot_Strike(1))/freq;
       GaitParam.Dummy.Double_Support.Right = NaN;
    end

    %*******************************
    % StepTime in s
    % Input: TimeSecondFootStrikeIpsi
    %        TimeFootStrikeContra

    if strcmp(GC_side,'right') == 1
       GaitParam.Dummy.Step_Time.Right = (EventsFrames.Right_Foot_Strike(2)-EventsFrames.Left_Foot_Strike(1))/freq;
       GaitParam.Dummy.Step_Time.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
       GaitParam.Dummy.Step_Time.Left = (EventsFrames.Left_Foot_Strike(2)-EventsFrames.Right_Foot_Strike(1))/freq;
       GaitParam.Dummy.Step_Time.Right = NaN;
    end

    
    %*******************************
    % Cadence in step per minute

    if strcmp(GC_side,'right') == 1
        GaitParam.Dummy.Cadence.Right = (60 / GaitParam.Dummy.Stride_Time.Right)*2;
        GaitParam.Dummy.Cadence.Left = NaN;
    elseif strcmp(GC_side,'left') == 1
        GaitParam.Dummy.Cadence.Left = (60 / GaitParam.Dummy.Stride_Time.Left)*2;
        GaitParam.Dummy.Cadence.Right = NaN;
    end

    %*******************************




    %*******************************
    % Stride width in metres between ankle joint centres
    
    % Stride width: is the distance from CP to CPP 
    % IP1 is the ipsilateral marker's position at the first ipsilateral foot contact.
    % IP2 is the ipsilateral marker's position at the second ipsilateral foot contact.
    % CP is the contralateral marker's position at the contralateral foot contact.
    % CPP is CP projected onto the IP1 to IP2 vector.
    % 
    % Reference: https://www.vicon.com/faqs/software/how-does-nexus-plug-in-gait-and-polygon-calculate-gait-cycle-parameters-spatial-and-temporal

    if strcmp(GC_side,'right') == 1
        
       IP1 = MarkersC3D.RTIO(EventsFrames.Right_Foot_Strike(1),1:2);
       IP2 = MarkersC3D.RTIO(EventsFrames.Right_Foot_Strike(2),1:2);
       CP  = MarkersC3D.LTIO(EventsFrames.Left_Foot_Strike(1),1:2); 
       Sign_side = -1;
       
       Vec_IP = IP1-IP2; % vector IP2 to IP1
       Norm_Vec_IP = Vec_IP./norm(Vec_IP);
       Vec_IP2_CP = CP-IP2; % vector IP2 to CP
       Vec3 = Norm_Vec_IP * dot(Vec_IP2_CP,Norm_Vec_IP); % Vector from IP2 to insertion of orthogonal vector to IP1-IP2 and CP
       Dist = norm (Vec_IP2_CP-Vec3); % Distance between vectro IP1-IP2 to CP

       StrideWidth = Dist * Sign_side; %depending on body side

       % if the feet cross, calculate negative step width
       Vec_IP_3 = [Vec_IP,0];
       Vec_IP2_CP_3 = [Vec_IP2_CP,0];
       CrossProd = cross(Vec_IP_3,Vec_IP2_CP_3);
       if CrossProd(:,3) < 0 
          StrideWidth = StrideWidth * -1;
       end %IF cross(Vec_IP,Vec_IP2_CP) < 0 

       GaitParam.Dummy.Stride_Width.Right = StrideWidth/1000; % transfer from millimeters to metres     
       GaitParam.Dummy.Stride_Width.Left = NaN;

    elseif strcmp(GC_side,'left') == 1
      
       IP1 = MarkersC3D.LTIO(EventsFrames.Left_Foot_Strike(1),1:2);
       IP2 = MarkersC3D.LTIO(EventsFrames.Left_Foot_Strike(2),1:2);
       CP  = MarkersC3D.RTIO(EventsFrames.Right_Foot_Strike(1),1:2); 
       Sign_side = 1;
       
       Vec_IP = IP1-IP2; % vector IP2 to IP1
       Norm_Vec_IP = Vec_IP./norm(Vec_IP);
       Vec_IP2_CP = CP-IP2; % vector IP2 to CP
       Vec3 = Norm_Vec_IP * dot(Vec_IP2_CP,Norm_Vec_IP); % Vector from IP2 to insertion of orthogonal vector to IP1-IP2 and CP
       Dist = norm (Vec_IP2_CP-Vec3); % Distance between vectro IP1-IP2 to CP

       StrideWidth = Dist * Sign_side; %depending on body side

       % if the feet cross, calculate negative step width
       Vec_IP_3 = [Vec_IP,0];
       Vec_IP2_CP_3 = [Vec_IP2_CP,0];
       CrossProd = cross(Vec_IP_3,Vec_IP2_CP_3);
       if CrossProd(:,3) < 0 
          StrideWidth = StrideWidth * -1;
       end %IF cross(Vec_IP,Vec_IP2_CP) < 0 

       GaitParam.Dummy.Stride_Width.Left = StrideWidth/1000; % transfer from millimeters to metres     
       GaitParam.Dummy.Stride_Width.Right = NaN;

    end
  
    Description_StrideWidth = 'Calculated between ankle joint centres';

end
