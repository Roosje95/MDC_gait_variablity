%{ 
*********************************************************************************
              Function "f_calc_absAngles_GroodSuntay" linked to 
                   script "Auswertung_ChiBa15b"
                    runs from "f_load_c3d"
                 by Marie Freslier June 2015
*********************************************************************************

Calculate the rotations of a body with coordinate system (X,Y,Z) in space
from Grood&Suntay (JBE 105:136-144,1983)

Coordinate system of the space: (x0,y0,z0) where
    x0 = positiv to gait direction
    y0 = positiv to the left
    z0 = positiv to the top

INPUT: side = 'R' or 'L', define the side for the sign definition of the
angles
       X = anterio/posterior axis of the body
       Y = medio/lateral axis of the body
       Z = vertical axis of the body
       X,Y,Z are matrices of 3 columns (x,y,z) and rows are values in time
       (same lengths for the 3 variables)

OUTPUT: flexion = flexion/extension angle of the body around the floating axis

        adduction = add-/abduction angle of the body around the x axis in space

        rotation = intern/extern rotation of the body around the Z axis of
        the body

%}
function [flexion,adduction,rotation] = f_calc_absAngles_GroodSuntay(X,Y,Z,side)
    % number of raws
    n = length(X);

    % normalisation of the body axis
    Xn = zeros(n,3);
    Yn = zeros(n,3);
    Zn = zeros(n,3);
    
    for i=1:n
        Xn(i,:) = X(i,:)/norm(X(i,:));
        Yn(i,:) = Y(i,:)/norm(Y(i,:));
        Zn(i,:) = Z(i,:)/norm(Z(i,:));
    end
    
    % define the space coordinate system
    x0 = [1*ones(1,n)' zeros(2,n)'];
    z0 = [zeros(2,n)' 1*ones(1,n)'];

    % floating axis
    flAxis = cross(Zn,x0);
    
    % flexion aroud flAxis
    cosFlex = dot(x0,Zn,2);

    flexion = 90 - acos(cosFlex)*180/pi;

    
    % adduction around x0
%     cosAdd = dot(y0,flAxis);
%     can't determine sign of angle: cos(a)=cos(-a); hence use flAxis.z0:
%     dot(y0,flAxis)=cos(Add) and dot(flAxis.z0)=cos(Add+pi/2)=-sin(Add)
    sinAdd = dot(flAxis,z0,2);

    if side == 'R'
        adduction = asin(sinAdd)*180/pi;
    else
        adduction = -asin(sinAdd)*180/pi;
    end
    
    % rotation around Zn
%     cosRot = dot(Yn,flAxis);
%     can't determine sign of angle: cos(a)=cos(-a); hence use flAxis.Xn:
%     dot(Yn,flAxis)=cos(Rot) and dot(flAxis.Xn)=cos(Rot-pi/2)=sin(Rot)
    sinRot = dot(flAxis,Xn,2);
    if side == 'R'
        rotation = asin(sinRot)*180/pi;
    else
        rotation = -asin(sinRot)*180/pi;
    end