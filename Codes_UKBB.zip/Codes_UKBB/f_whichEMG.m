%{
*********************************************************************************
     Function "f_whichEMG" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer Oct. 2014
*********************************************************************************

Extract information on which EMG-Setup was measured from "measurement info form".
Link the muscle names to the channel names in the c3d (NewNameEMG).

                                     
INPUT
  data = Struct (named "Params4_c3d" in main script) including all data
         from clinical testing

OUTPUT
  NewNameEMG = three-column cell 1. column is the original name in the c3d "Analog -> Descriptions" e.g. 'EMG1',
                                 2. column is the channel as numbered by matlab e.g. 'v1'
                                 3. column is the side and muscle name e.g. 'RGastrocMed'
  Titel_EMG = titles for EMG plots
  Param_EMG = Names of the muscles as given in struct
  EMG_recorded = Info on whether EMG was recorded ('y')or not ('n')
%}

function [NewNameEMG,Titel_EMG,Param_EMG,EMG_recorded] = f_whichEMG(data)

    %% If EMG was recorded
    
    if ~isempty(data.EMG_Setup)
        
        EMG_recorded = 'y'; % Info that EMG was recorded
        
        %original name in the c3d "Analog -> Descriptions" e.g. 'EMG1'      
        NewNameEMG(:,1) = {'EMG1','EMG10','EMG11','EMG12','EMG13','EMG14','EMG15','EMG16',...
                           'EMG2','EMG3','EMG4','EMG5','EMG6','EMG7','EMG8','EMG9',}';  
        %channel as numbered by matlab e.g. 'v1'               
        NewNameEMG(:,2) = {'v','v1','v2','v3','v4','v5','v6','v7','v8','v9','v10',...
                           'v11','v12','v13','v14','v15'}';

        for i = 1:16
            NewNameEMG{i,3} = data.(NewNameEMG{i,1});   %the side and muscle name e.g. 'RGastrocMed'    
        end %FOR i = 1:16

        
        %% For the EMG names to have the right arrangement for plotting
        
        NewNameEMG(:,4) = {'15';'2';'13';'11';'6';'7';'8';'9';'3';'16';'5';'1';'12';'10';'14';'4'};% 
        NewNameEMG = sortrows(NewNameEMG,4);
        NewNameEMG(:,4) = [];


        %% Delete empty EMG channels
        
        for i = 1:16
            noEMG(i,1) = isempty(NewNameEMG{i,3});
        end %FOR i = 1:16           
        NewNameEMG(noEMG,:) = [];


        %% Create Title and Param_EMG
        
        x=1;
        for i = 1:size(NewNameEMG,1)

            if NewNameEMG{i,3}(1,1) == 'L'           
               Titel_EMG{x,:} = NewNameEMG{i,3}(2:end); %Titel for Plots;
               Param_EMG{x,:} = NewNameEMG{i,3}(2:end); %Muscle names as in struct  
               x = x+1;
            end %IF NewNameEMG{i,3}(1,1) == 'L'  

        end %FOR i = 1:size(NewNameEMG,1)          

        
        %% Replace EMG titles (output of meausurement form) with names as definded in structs
        
        Titel_EMG = strrep(Titel_EMG, 'AddLongus', 'Adductor long.');
        Titel_EMG = strrep(Titel_EMG, 'GastrocMed', 'Gastrocnemius med.');
        Titel_EMG = strrep(Titel_EMG, 'GastrocLat', 'Gastrocnemius lat.');         
        Titel_EMG = strrep(Titel_EMG, 'GluteusMax','Gluteus max.');
        Titel_EMG = strrep(Titel_EMG, 'GluteusMed', 'Gluteus med.'); 
        Titel_EMG = strrep(Titel_EMG, 'HamsLat', 'Hamstrings lat.');
        Titel_EMG = strrep(Titel_EMG, 'HamsMed', 'Hamstrings med.');
        Titel_EMG = strrep(Titel_EMG, 'Iliopsoas', 'Iliopsoas');
        Titel_EMG = strrep(Titel_EMG, 'PeroneusBrevis', 'Peroneus brev.');
        Titel_EMG = strrep(Titel_EMG, 'PeroneusLongus', 'Peroneus long.');
        Titel_EMG = strrep(Titel_EMG, 'RectusFem', 'Rectus femoris');         
        Titel_EMG = strrep(Titel_EMG, 'Soleus', 'Soleus');
        Titel_EMG = strrep(Titel_EMG, 'TibAnt', 'Tibialis ant.');       
        Titel_EMG = strrep(Titel_EMG, 'TibPost', 'Tibialis post.');
        Titel_EMG = strrep(Titel_EMG, 'VastLat', 'Vastus lat.');
        Titel_EMG = strrep(Titel_EMG, 'VastMed', 'Vastus med.');

        
       %% if we used the normal EMG, set-up use normal EMG set-up  
       
       if strcmp(data.EMG_Setup,'Standard-Routine')
          
          disp(' '); disp('-------------------------') ; disp('Standard EMG setup'); disp('-------------------------'); disp(' ');
         
   
       %% if we used the patella set-up, use Patella set-up
       
       elseif strcmp(data.EMG_Setup,'Knie-Setup (VM)')
           
          disp(' '); disp('-------------------------') ; disp('Knie (vastus med) EMG setup'); disp('-------------------------'); disp(' ');
         

       elseif strcmp(data.EMG_Setup,'Fussmodell beidseitig')
           
          disp(' '); disp('-------------------------') ; disp('Fussmodell EMG setup'); disp('-------------------------'); disp(' ');
         
          
       %% Other: user defined set-up % ADAPT EMG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   
       
       elseif  strcmp(data.EMG_Setup,'Anderes EMG Setup')

          disp(' '); disp('-------------------------') ; disp('Other EMG setup'); disp('-------------------------'); disp(' ');
       
       end %IF strcmp(data.EMG_Setup,'Standard-Routine')
       
       
    %% if we used no EMG
    
    else 
         disp(' '); disp('-------------------------') ; disp('No EMG'); disp('-------------------------'); disp(' ');

         EMG_recorded = 'n';
         NewNameEMG(:,1) = {'EMG1','EMG10','EMG11','EMG12','EMG13','EMG14','EMG15','EMG16',...
                           'EMG2','EMG3','EMG4','EMG5','EMG6','EMG7','EMG8','EMG9',}';  
        %channel as numbered by matlab e.g. 'v1'               
         NewNameEMG(:,2) = {'v','v1','v2','v3','v4','v5','v6','v7','v8','v9','v10',...
                           'v11','v12','v13','v14','v15'}';
         NewNameEMG(:,3) = {'NaN','NaN','NaN','NaN','NaN','NaN','NaN','NaN','NaN',...
                            'NaN','NaN','NaN','NaN','NaN','NaN','NaN'}';
         Titel_EMG = {'NaN','NaN'}';
         Param_EMG ='NaN';

    end %IF ~isempty(data.EMG_Setup)
    
end %FUNCTION
