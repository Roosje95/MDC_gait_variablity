function [out,new_c3dName] = f_defineGaitCycles_generalCase(Path_Origin,Path_new,c3d_name)
%{
by M. Freslier, July. 2017

Function to define the good gait cycles for the given side and test which 
forceplate correspond to it.

INPUT
    Path_Origin = path where the data are stored
    Path_new = path where the data will be copied (temporary folder)
    c3d_name = name of the c3d file

OUTPUT
    out = 1 if all ok, 0 if there is a problem ... (script
    could be stopped)
%}

    out = 1;
    
    Path_c3d = [Path_Origin,'\',c3d_name];
    
    switch c3d_name(1:3)
        case 'Rep' % RepTrial
            infos_filename = strsplit(c3d_name,'_');
            trial_Type = infos_filename{1,2}(1);
        otherwise
            trial_Type = c3d_name(1);
    end
    
    switch trial_Type
        case 'B'
            warning off all
            acq = btkReadAcquisition(Path_c3d);
            warning on all; warning('off','MATLAB:interp1:NaNinY')
            [out_GenEvtL,acq] = addGeneralEvents(acq,'left');
            if ~out_GenEvtL
                out = out_GenEvtL;
                disp(' ');
                disp('!!! error in f_defineGaitCycles: !!!');
                disp(['!!! for trial ' c3d_name ': !!!']);
                disp(['!!! there isn''t any foot strikes that correspond to '...
                    '(left, FP1 or FP2): please have a look. !!!']);
            end
            [out_GenEvtR,acq] = addGeneralEvents(acq,'right');
            if ~out_GenEvtR
                out = out_GenEvtR;
                disp(' ');
                disp('!!! error in f_defineGaitCycles: !!!');
                disp(['!!! for trial ' c3d_name ': !!!']);
                disp(['!!! there isn''t any foot strikes that correspond to '...
                    '(right, FP1 or FP2): please have a look. !!!']);
            end
            if out_GenEvtL || out_GenEvtR
                new_c3dName = ['K',c3d_name(2:length(c3d_name))];
            else
                new_c3dName = ['N',c3d_name(2:length(c3d_name))];
            end
            Path_c3dnew = [Path_new,'\',new_c3dName];
            btkWriteAcquisition(acq,Path_c3dnew);
            btkDeleteAcquisition(acq);
        case 'L'
            warning off all
            acq = btkReadAcquisition(Path_c3d);
            warning on all; warning('off','MATLAB:interp1:NaNinY')
            [out_GenEvt,acq] = addGeneralEvents(acq,'left');
            if out_GenEvt
                new_c3dName = ['K',c3d_name(2:length(c3d_name))];
            else
                out = out_GenEvt;
                new_c3dName = ['N',c3d_name(2:length(c3d_name))];
                disp(' ');
                disp('!!! error in f_defineGaitCycles: !!!');
                disp(['!!! for trial ' c3d_name ': !!!']);
                disp(['!!! there isn''t any foot strikes that correspond to '...
                    '(left, FP1 or FP2): please have a look. !!!']);
            end
            Path_c3dnew = [Path_new,'\',new_c3dName];
            btkWriteAcquisition(acq,Path_c3dnew);
            btkDeleteAcquisition(acq);
        case 'R'
            warning off all
            acq = btkReadAcquisition(Path_c3d);
            warning on all; warning('off','MATLAB:interp1:NaNinY')
            [out_GenEvt,acq] = addGeneralEvents(acq,'right');
            if out_GenEvt
                new_c3dName = ['K',c3d_name(2:length(c3d_name))];
            else
                out = out_GenEvt;
                new_c3dName = ['N',c3d_name(2:length(c3d_name))];
                disp(' ');
                disp('!!! error in f_defineGaitCycles: !!!');
                disp(['!!! for trial ' c3d_name ': !!!']);
                disp(['!!! there isn''t any foot strikes that correspond to '...
                    '(right, FP1 or FP2): please have a look. !!!']);
            end
            Path_c3dnew = [Path_new,'\',new_c3dName];
            btkWriteAcquisition(acq,Path_c3dnew);
            btkDeleteAcquisition(acq);
        case 'K'
            new_c3dName = c3d_name;
            warning off all
            acq = btkReadAcquisition(Path_c3d);
            warning on all; warning('off','MATLAB:interp1:NaNinY')
            [out_GenEvtDesc,message,acq] = checkGenEventDescrip(acq);
            if out_GenEvtDesc
                Path_c3dnew = [Path_new,'\',c3d_name];
            else
                out = out_GenEvtDesc;
                Path_c3dnew = [Path_new,'\',c3d_name];
                disp(' ');
                disp('!!! error in f_defineGaitCycles: !!!');
                disp(['!!! for trial ' c3d_name ': !!!']);
                disp(message);
            end
            btkWriteAcquisition(acq,Path_c3dnew);
            btkDeleteAcquisition(acq);
        
        otherwise
            out = 0;
            disp(' ');
            disp('!!! error in f_defineGaitCycles: !!!');
            disp(['!!! for trial ' c3d_name ': !!!']);
            disp(['!!! this trial isn''t of type good both (B....c3d), '...
                'good left (L....c3d) or good right (R....c3d). !!!']);
            return
    end
    
%     % search the 4th step general events and set a description
%     if isfield(eventsOrigin,'General_Event')
%         FO_Events = [eventsOrigin.Left_Foot_Off eventsOrigin.Right_Foot_Off];
%         nb_4thStep = 0;
%         for genEvt = 1:length(eventsOrigin.General_Event)
%             for FO_evt=1:length(FO_Events)
%                 if eventsOrigin.General_Event(genEvt) == FO_Events(FO_evt)
%                     nb_4thStep = nb_4thStep + 1;
%                 end
%             end
%         end
%         switch nb_4thStep
%             case 0 % no general event found for defining 4th Step
%             case 1 % only one general event found for defining 4th step
%                 btkSetEventDescription(acq,'Event','Toe Off of the 4th step');
%             otherwise % too many general events that could define a 4th step
%                 out = 0;
%                 disp(' ');
%                 disp('!!! error in f_defineGaitCycles: !!!');
%                 disp(['!!! Too many general events that could define a 4th step for trial '...
%                     trials_infos(trial).filename ': please have a look. !!!']);
%         end
%     end % if isfield(eventsOrigin,'General_Event')

end % END OF FUNCTION

% function which searches the 1st event of the given gait cycle (side 
% given): which forceplate (FP1 or FP2?), and add a general event in the
% acquisition
function [out,acq] = addGeneralEvents(acq,side)
    out = 1;
    
    %% remove subject name in event description and read events
    for t = 1 : btkGetEventNumber(acq)
        btkSetEventSubject(acq, t, '');
    end
    clear t
    
    eventsOrigin = btkGetEvents(acq);
    freq = btkGetPointFrequency(acq); % frequency kinematic (Vicon)
    freqAnalog = btkGetAnalogFrequency(acq); % frequency analog (EMG, forces)
    firstFrame = btkGetFirstFrame(acq); % first frame of the measurement (in case the trial was cut)
    firstFrameAnalog = firstFrame*(freq\freqAnalog)-(freq\freqAnalog)+1;

    Analog = btkGetAnalogs(acq);
    % extract forceplate vertical component
    
    if isfield(Analog,'Fz2')
    Fz1 = Analog.Fz1;
    Fz2 = Analog.Fz2;
    else
    Fz1 = Analog.Fz;
    Fz2 = Analog.Fz1;
    end
    clear Analog

    switch side
        case 'right'
            FS_ipsi = eventsOrigin.Right_Foot_Strike;
        case 'left'
            FS_ipsi = eventsOrigin.Left_Foot_Strike;
    end
    
    % look on FP1
    [FS_found,FS_GaitCycle] = findCorrespondingFS(freqAnalog,firstFrameAnalog,Fz1,FS_ipsi);
    if FS_found
        ev_descrip = [side,' foot contact on forceplate ','FP1',', clean hit.'];
        btkAppendEvent(acq, 'Event', FS_GaitCycle, 'General','',ev_descrip);
    else % if not found with FP1, look on FP2
        [FS_found,FS_GaitCycle] = findCorrespondingFS(freqAnalog,firstFrameAnalog,Fz2,FS_ipsi);
        if FS_found
            ev_descrip = [side,' foot contact on forceplate ','FP2',', clean hit.'];
            btkAppendEvent(acq, 'Event', FS_GaitCycle, 'General','',ev_descrip);
        else
            out = FS_found;
        end
    end
end

% function which check if the general events have a complete description
% and possibly complete it
function [out,message,acq] = checkGenEventDescrip(acq)
    out = 1;
    message = {}; ind_message = 0;
    
    Analog = btkGetAnalogs(acq);
    freq = btkGetPointFrequency(acq); % frequency kinematic (Vicon)
    freqAnalog = btkGetAnalogFrequency(acq); % frequency analog (EMG, forces)
    firstFrame = btkGetFirstFrame(acq); % first frame of the measurement (in case the trial was cut)
    firstFrameAnalog = firstFrame*(freq\freqAnalog)-(freq\freqAnalog)+1;
    clear freq firstFrame
    %% remove subject name in event description and read events
    for t = 1 : btkGetEventNumber(acq)
        btkSetEventSubject(acq, t, '');
    end
    clear t
    eventsOrigin = btkGetEvents(acq);
    

    %% get the foot strike events and their names (X_Foot_Strike), sort it in time order
    event_names = {};
    event_s = {};
    events_fields = fieldnames(eventsOrigin);
    for evt_index = 1 : numel(events_fields)
        footStrike = regexp(events_fields(evt_index),'Right_Foot_Strike|Left_Foot_Strike','once');
        if ~isempty(footStrike{1,1})
            [event_s, event_names] = get_event(evt_index, eventsOrigin,...
                events_fields, event_s, event_names);
        end  % if
    end  % for
    list_FSs = sortrows([event_s, event_names],1);
    clear evtValues events_fields footStrike event_s event_names evt_index
        
    %% get the general events and their description
    [evtValues,label,descript] = btkGetEventsValues(acq);
    events_index = (1:length(evtValues))';
    % sort by description (without description first)
    events_infos = sortrows([num2cell(evtValues),label,descript,num2cell(events_index)], 3);
    clear evtValues label descript events_index
    
    nb_4thStep = 0;
    evt_index = 1;
    while strcmp(events_infos{evt_index,2},'Event') && ... % it's a general events
            ~(strncmp(events_infos{evt_index,3},'Toe Off of the 4th',18) ...
            || strncmp(events_infos{evt_index,3},'left foot contact ',18) ...
            || strncmp(events_infos{evt_index,3},'right foot contact',18))
        % general event for foot strike?
        ind = 1;
        while ind<=size(list_FSs,1) && events_infos{evt_index,1}~=list_FSs{ind,1}
            ind = ind + 1;
        end
        if ind <= size(list_FSs,1) % FS found for this general event
            % look for the corresponding forceplate
            FS_found = 0;
            i = 1;
            while i<=4 && ~FS_found
                fp = ['Fz',num2str(i)];
                FPx = ['FP',num2str(i)];
                Fz = Analog.(fp);
                if isfield(Analog,fp)
                    [FS_found,~] = findCorrespondingFS(freqAnalog,...
                        firstFrameAnalog,Fz,events_infos{evt_index,1});
                end
                i = i + 1;
            end
            if FS_found % corresponding FP found
                % remove existing general event ...
                btkRemoveEvent(acq,events_infos{evt_index,4});
                % ... and replace it with the same value with adapted description
                side = regexp(list_FSs{ind,2},'Left|Right','match');
                ev_descrip = [lower(side{1,1}),' foot contact on forceplate ',FPx,', clean hit.'];
                btkAppendEvent(acq, 'Event', events_infos{evt_index,1}, 'General','',ev_descrip);
            else % no corresponding FP found
                out = 0;
                ind_message = ind_message + 1;
                message{ind_message,1} = ['!!! gen. evt on ',num2str(events_infos{evt_index,1}),...
                    's doesn''t correspond to any FP. Please have a look. !!!'];
                % remove this event
                btkRemoveEvent(acq,events_infos{evt_index,4});
            end
        else % this general event has no corresponding FS: search for FO
            FO_Events = sort([eventsOrigin.Left_Foot_Off eventsOrigin.Right_Foot_Off]);
            ind = 1;
            while ind<=length(FO_Events) && events_infos{evt_index,1}~=FO_Events(ind)
                ind = ind + 1;
            end
            if ind <= length(FO_Events) % corresponding FO found
                if nb_4thStep == 0 % no other FO corresponding to a general event previously found
                    nb_4thStep = nb_4thStep + 1;
                    % is there another general event corresponding to a FO?
                    next_evt = evt_index + 1;
                    while next_evt<=size(events_infos,1) ...
                            && strcmp(events_infos{next_evt,2},'Event') && ... % it's a general events
                            ~(strncmp(events_infos{next_evt,3},'Toe Off of the 4th',18) ...
                            || strncmp(events_infos{next_evt,3},'left foot contact ',18) ...
                            || strncmp(events_infos{next_evt,3},'right foot contact',18))
                        ind = 1;
                        while ind<=length(FO_Events) && events_infos{next_evt,1}~=FO_Events(ind)
                            ind = ind + 1;
                        end
                        if ind <= length(FO_Events) % corresponding FO found
                            nb_4thStep = nb_4thStep + 1;
                        end
                        next_evt = next_evt + 1;
                    end % while next_evt<=size(events_infos,1) ...
                    if nb_4thStep > 1
                        out = 0;
                        ind_message = ind_message + 1;
                        message{ind_message,1} = ['!!! gen. evt on ',num2str(events_infos{evt_index,1}),...
                            's isn''t the only one to define a 4. step. Please have a look. !!!'];
                        % remove this event
                        btkRemoveEvent(acq,events_infos{evt_index,4});
                    else % only one FO corresponding to a general event (-> 4th step)
                        % remove existing general event ...
                        btkRemoveEvent(acq,events_infos{evt_index,4});
                        % ... and replace with the same value with adapted description
                        btkAppendEvent(acq, 'Event', events_infos{evt_index,1}, ...
                            'General','','Toe Off of the 4th step');
                    end % if nb_4thStep > 1
                else % there is already a FO corresponding to a general event
                    out = 0;
                    ind_message = ind_message + 1;
                    message{ind_message,1} = ['!!! gen. evt on ',num2str(events_infos{evt_index,1}),...
                        's isn''t the only one to define a 4. step. Please have a look. !!!'];
                    % remove this event
                    btkRemoveEvent(acq,events_infos{evt_index,4});
                end % if nb_4thStep == 0
            else % no corresponding FO found
                out = 0;
                ind_message = ind_message + 1;
                message{ind_message,1} = ['!!! the general event on ',num2str(events_infos{evt_index,1}),...
                    's don''t correspond to any foot strike or foot off. Please have a look. !!!'];
                % remove this event
                btkRemoveEvent(acq,events_infos{evt_index,4});
            end % if ind <= length(FO_Events)
        end % if ind <= size(list_FSs,1)
        
        % update the list of the events with new indeces
        [evtValues,label,descript] = btkGetEventsValues(acq);
        events_index = (1:length(evtValues))';
        % sort by description (without description first)
        events_infos = sortrows([num2cell(evtValues),label,descript,num2cell(events_index)], 3);
        clear evtValues label descript events_index
    end % while
    
end

function [events, event_names] = get_event(event_index, events_list, events_field, events, event_names)
% get the events from the field 'events_field' out of the struct
% 'events_list' and convert the values into a cell format 'events'
% event_names is a struct with corresponding types of the events:
% X_Foot_Strike or X_Foot_Off

    events_s = events_list.(events_field{event_index});

    if numel(events_s) > 1
        event_names = [event_names; repmat(events_field(event_index), 1, numel(events_s))'];
        events = [events; num2cell(events_s)'];
    else
        event_names = [event_names; events_field(event_index)];
        events = [events; num2cell(events_s)];
    end  % if
end  % function

% function which checks if there is a foot strike in given FS list which
% correspond to the given vertical force
function [out,timeGenEvt] = findCorrespondingFS(freqAnalog,firstFrameAnalog,Fz,FS)
    i=1;
    while i<=length(FS)
        if Fz(round(FS(i)*freqAnalog - firstFrameAnalog + 2)-50) == 0 ...
            && Fz(round(FS(i)*freqAnalog - firstFrameAnalog + 2)+50)~=0
        % this FS correspond to the considered FP
            eventsOK = 1;
            break
        else
            i = i + 1;
            eventsOK = 0;
        end
    end
    if eventsOK == 0
        timeGenEvt = 0;
        out = 0;
        return
    else %eventsOK == 1
        timeGenEvt = FS(i);
        out = 1;
        return
    end
end