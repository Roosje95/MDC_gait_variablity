%{ 
*********************************************************************************
  Function "f_checkPlot_Consistency" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer Dez. 2013
*********************************************************************************

Prepares the data for the consistency plots.
Plots the control group in a grey band, all trials of the left side of the patients in a
continous line, the right side in a dashed line. It also plots the foot-off
of the patients in horizontal line.
The plots are scared to 0-100% of a gait cycle on the x-achsis and 
to +/- 1% above/below the maximum/minimum of the data

INPUT
  PA_data = Data of patients from struct (e.g. "DataForCalc.PIGnormalised_101.Angle")
  Title = Titel for plot (e.g. "Consistency plots Joint rotation angles - Upper body")
  CG_RangeLB = Lower bound of control goup data
  CG_RangeUB = Upper bound of control goup data
  Subtitle = Titles for subplots (e.g. "Spine tilt")
  name_Y = Names for Y-Axis (e.g. "post  degrees  ant")
  DataName = Names of fields to get the data (e.g. "Angle,Sagittal,Spine")
  lines = number of lines for subplots
  YLim = the standard y-axis-limits (e.g. [-10 10]
  XTICK = [1 21 41 61 81 101]
  XTICKLABEL = {'0','20','40','60','80','100'}
  Color_band = Color for band of controls (grey)
  FootOff_Left = Left foot off for patients
  FootOff_Right = Right foot off for patients
  TrialStr = Cell with name of trial that are plotted {'L4',R5'}
  Color_Left = Color for the left side of the patient data (red)
  Color_Right = Color for the right side (blue)
  LineWidth_side1 = Line width for the left side of the patient data
  LineWidth_side2 = Line width for the right side of the patient data

%}

function f_checkPlot_Consistency(PA_data,Title,CG_RangeLB,CG_RangeUB,Subtitle,...
                                 name_Y,DataName,lines,YLim,XTICK,XTICKLABEL,...
                                 Color_band,FootOff_Left,FootOff_Right,...
                                 TrialStr,Color_Left,Color_Right,...
                                 LineWidth_side1,LineWidth_side2)                          

   Data_NaN = NaN;  

   
%**************************************************************************         
  %% plot left side
%**************************************************************************
   for i = 1:size(DataName,1) %check if not all data are NaN
       DataNotNAN(i,1) = sum(~isnan(PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Left(1,:)));       
   end %FOR for i = 1:size(DataName,1)
   DataGood = sum(DataNotNAN);
  
   if DataGood >= 1 % if data exist (are not NaN)
      
      % Set general figure parameter
      Fig_left = figure('PaperSize',[20.98 29.68],'Units','centimeters','Position', [18,0,20.98,29.68],...
                        'PaperPositionMode','manual','PaperPosition', [0.5,0,20.48,28.18]); %[linker Seitenrand, unterer Seitenrand,Breite, H�he] 
      annotation(Fig_left,'textbox',[0.366 0.956 0.3 0.04],'String',Title,...
              'HorizontalAlignment','center','FontSize',14,'LineStyle','none',...
              'FitBoxToText','on');
      annotation(Fig_left,'textbox',[0.06 0.935 0.09 0.04],'String','Left',...
              'Color','r','HorizontalAlignment','center','FontSize',11,...
              'LineStyle','none','FontWeight','bold');
       
          
      %% Across all data that should be plotted
      
      for i = 1:size(DataName,1)
          
          % Vector for patient data
          PA_Left = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Left;
          
          % Vector for control group data range (LB = lower bound, UB = upper bound)
          if  isfield(CG_RangeLB,DataName{1,1}) %if in the control group the field exists          
              CG_LB = CG_RangeLB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
              CG_UB = CG_RangeUB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
              
          else % if no normal data exist for this parameter -> set normal data to NaN
              CG_LB = NaN(100,1);
              CG_UB = NaN(100,1);
              
          end %isfield(CG_RangeLB,DataName{1,1})
          
          % for the last three subplots X-Achsis lable is Gait cycle
          if i > size(DataName,1)-3
              name_X = '% gait cycle';
          else
              name_X = '';
          end %i > size(DataName,1)-3 
       
          figure(Fig_left)
          subplot(lines,3,i)
          
          % apply "f_plotData" to plot each subplot
          f_plotData(CG_LB,CG_UB,PA_Left,Data_NaN,Subtitle{i,1},name_Y{i,1},name_X,...
                     Color_band,YLim(i,:),XTICK,XTICKLABEL,FootOff_Left,FootOff_Right,...
                     Color_Left,Color_Right,LineWidth_side1,LineWidth_side2)                    

      end %FOR i = 1:size(DataName,1)

      % make legend 
      figure(Fig_left)

      Legend_L = TrialStr;
      Legend_L(isnan(PA_Left(1,:))',:) = [];
      legend(Legend_L ,'Orientation','horizontal','Position',[0.3192 0.04362 0.3663 0.02553])
      set(legend,'Box','off')    
      
   end %IF DataGood >= 1

   
   
%**************************************************************************
  %% Right side
%**************************************************************************

   for i = 1:size(DataName,1) %check if not all data are NaN
       DataNotNAN(i,1) = sum(~isnan(PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Right(1,:)));       
   end %FOR for i = 1:size(DataName,1)
   DataGood = sum(DataNotNAN);
   
   if DataGood >= 1  % if data exist (are not NaN)
       
       % Set general figure parameter              
       Fig_right = figure('PaperSize',[20.98 29.68],'Units','centimeters','Position', [18,0,20.98,29.68],...
                          'PaperPositionMode','manual','PaperPosition', [0.5,0,20.48,28.18]);

       annotation(Fig_right,'textbox',[0.366 0.956 0.3 0.04],'String',Title,...
               'HorizontalAlignment','center','FontSize',14,'LineStyle','none',...
               'FitBoxToText','on');
       annotation(Fig_right,'textbox',[0.06 0.935 0.09 0.04],'String','Right',...
               'Color','b','HorizontalAlignment','center','FontSize',11,...
               'LineStyle','none','FontWeight','bold');
          
           
     %% Across all data that should be plotted
     
      for i = 1:size(DataName,1)
          
          % Vector for patient data
          PA_Right = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Right;
          
          % Vector for control group data range (LB = lower bound, UB = upper bound)
          if  isfield(CG_RangeLB,DataName{1,1}) %if in the control group the field exists          
              CG_LB = CG_RangeLB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
              CG_UB = CG_RangeUB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
              
          else % if no normal data exist for this parameter -> set normal data to NaN
              CG_LB = NaN(100,1);
              CG_UB = NaN(100,1);
              
          end %isfield(CG_RangeLB,DataName{1,1})              
              
          % for the last three subplots X-Achsis lable is Gait cycle
          if i > size(DataName,1)-3
              name_X = '% gait cycle';
          else
              name_X = '';
          end %i > size(DataName,1)-3        
          
          figure(Fig_right)
          subplot(lines,3,i)
          
          % apply "f_plotData" to plot each subplot
          f_plotData(CG_LB,CG_UB,Data_NaN,PA_Right,Subtitle{i,1},name_Y{i,1},name_X,...
                     Color_band,YLim(i,:),XTICK,XTICKLABEL,FootOff_Left,FootOff_Right,...
                     Color_Left,Color_Right,LineWidth_side1,LineWidth_side2)
      end %FOR i = 1:size(DataName,1)
   
      figure(Fig_right)
      Legend_R = TrialStr;
      Legend_R(isnan(PA_Right(1,:))',:) = [];
      legend(Legend_R,'Orientation','horizontal','Position',[0.3192 0.04362 0.3663 0.02553])  
      set(legend,'Box','off') 
       
   end %IF DataGood >= 1 
   

end %FUNCTION