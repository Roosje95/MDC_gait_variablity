%{
*********************************************************************************
 Function "f_Report_clinicalTest" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer April 2014
*********************************************************************************

Creates the 2rd page of the report with the clinical measurements.
                                     
INPUT
  ID = Gait lab number and letter of visit of patient
  Param = Struct with data from google formular


OUTPUT
  Figure for 2nd page report save in the postscript.
%}

function f_Report_clinicalTest(ID,Param)

   GreyBackground = [0.85 0.85 0.85];

   % Create figure

   figure1 = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                    'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                    'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]

         
   %% Klinischer Befund
   
   annotation(figure1,'textbox',[0.05 0.970 0.805 0.05],'String',{'Klinischer Befund'},...
                 'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                 'VerticalAlignment','middle','LineStyle','none');
   annotation(figure1,'textbox',[0.805 0.970 0.144 0.05],'String',ID,...
                 'FontSize',11,'FitBoxToText','off','LineStyle','none',...
                 'VerticalAlignment','middle','HorizontalAlignment','right');

   % Left
   annotation(figure1,'textbox',[0.499 0.955 0.19 0.03],'String',{'Links'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
             'LineStyle','none','Color',[1 0 0]);

   % Right
   annotation(figure1,'textbox',[0.725 0.955 0.19 0.03],'String',{'Rechts'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
             'LineStyle','none','Color',[0 0 1]);

  
   % Change unit from mm to cm
   Param.Height = sprintf('%2.1f',str2double(Param.Height)/10);
   Param.LLegLength = sprintf('%2.1f',str2double(Param.LLegLength)/10);
   Param.RLegLength = sprintf('%2.1f',str2double(Param.RLegLength)/10);
             
   %
   Cell = {'','','','Torsion',''}';
   Cell(:,2) = {'Gewicht (kg)','Gr�sse (cm)','Beinl�nge (cm)','Tibial (Grad)','Femoral (Grad)'}';
   Cell(:,3) = {Param.Bodymass,Param.Height,'','',''}';
   Cell(:,4) = {Param.Bodymass_comment,Param.Height_comment,'','',''}';
   Cell(:,5) = {'','',Param.LLegLength,Param.LTibialTorsion_Grad,Param.LFemoralTorsion}';
   Cell(:,6) = {'','',Param.LLegLength_comment,Param.LTibialTorsion_comment,Param.LFemoralTorsion_comment}';
   Cell(:,7) = {'','',Param.RLegLength,Param.RTibialTorsion_Grad,Param.RFemoralTorsion}';
   Cell(:,8) = {'','',Param.RLegLength_comment,Param.RTibialTorsion_comment,Param.RFemoralTorsion_comment}';


   Ypos = 0.938; %Y-Position of textbox lower corner
   XposStart = 0.05;

   for i = 1:5 %for Rows of Cell
       Xpos = XposStart; %X-Position of textbox lower left corner
       Width = 0.062; %Width of textbox
       Height = 0.0235;%0.037; %Height of textbox
    
       if mod (i,2) %if i = odd number
          BackgroundColor = GreyBackground;          
       else 
          BackgroundColor = 'none';
       end
    
       %Column 1
       annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',Cell{i,1},...
                 'FontWeight','light','FontSize',10,'FitBoxToText','off','LineStyle','none',...
                 'EdgeColor','none','BackgroundColor',BackgroundColor);

       Xpos = Xpos + Width;
       Width = 0.162;
    
       %Column 2 & 2b
       annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',Cell{i,2},...
                 'FontWeight','light','FontSize',10,'FitBoxToText','off','LineStyle','none',...
                 'EdgeColor','none','BackgroundColor',BackgroundColor);

       Xpos = Xpos + Width;
%        Width = 0.064;    

      for j = 3:8
       
          if mod (j,2)
             Width = 0.054;
             FrontSize = 10;
             f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                           FrontSize,BackgroundColor,'right')
                         
             Xpos = Xpos + Width;
          
          else Width = 0.1713; %Comments
               FrontSize = 7;
               f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                             FrontSize,BackgroundColor,'left')
                           
               Xpos = Xpos + Width;
          end

      end %FOR j = 1:11

      Ypos = Ypos - Height;
    
   end %FOR i = 1:10


    %% Rectangles around tables

    %around entire table
    annotation(figure1,'rectangle',[XposStart Ypos+Height 0.899 0.118]); %,'FaceColor','flat');
    %around general parameters
    annotation(figure1,'rectangle',[0.274 Ypos+Height 0.2253 0.118]); %,'FaceColor','flat');%[0.275 Ypos+Height 0.2253 0.118]
    %around left side
    annotation(figure1,'rectangle',[0.4993 Ypos+Height 0.2253 0.118]); %,'FaceColor','flat');%[0.5005 Ypos+Height 0.2253 0.118]


    %% RoM

    annotation(figure1,'textbox',[0.05 0.793 0.3252 0.03],'String',{'Passive Beweglichkeit (Grad)'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
              'LineStyle','none');

    % Left
    annotation(figure1,'textbox',[0.36 0.793 0.19 0.03],'String',{'Links'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
              'LineStyle','none','Color',[1 0 0]);

    % Right
    annotation(figure1,'textbox',[0.69 0.793 0.19 0.03],'String',{'Rechts'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
              'LineStyle','none','Color',[0 0 1]);

    Cell = {'H�fte','','','','Knie','','Fuss','',''}';
    Cell(:,2) = {'Flex-/Extension','Ab-/Adduktion','Ab-/Adduktion','Aussen-/Innenrot.',...
                 'Flex-/Extension','Flex-/Extension','Dorsal-/Plantarflex.',...
                 'Dorsal-/Plantarflex.','Dorsal-/Plantarflex.'}';
    Cell(:,3) = {'','(Knie gestreckt)','(Knie gebeugt)','','(H�fte gebeugt)','(H�fte gestreckt)',...
                 '(Knie gebeugt, USG fix)','(Knie gestreckt, USG fix)','(Knie gestr., USG frei)'}';
    Cell(:,4) = {Param.LRoM_HipFlexion,Param.LRoM_HipAbduction_extendedKnee,...
                 Param.LRoM_HipAbduction_flexedKnee,Param.LRoM_HipExtRotation,...
                 Param.LRoM_KneeFlexion_flexedHip,Param.LRoM_KneeFlexion_extendedHip,...
                 Param.LRoM_FootDsl_flexedKnee_fixedLowAnk,Param.LRoM_FootDsl_extendedKnee_fixedLowAnk,...
                 Param.LRoM_FootDsl_extendedKnee_freeLowAnk}';
    Cell(:,5) = {Param.LRoM_HipFlexion_comment,Param.LRoM_HipAbduction_extendedKnee_comment,...
                 Param.LRoM_HipAbduction_flexedKnee_comment,Param.LRoM_HipExtRotation_comment,...
                 Param.LRoM_KneeFlexion_flexedHip_comment,Param.LRoM_KneeFlexion_extendedHip_comment,...
                 Param.LRoM_FootDsl_flexedKnee_fixedLowAnk_comment,...
                 Param.LRoM_FootDsl_extendedKnee_fixedLowAnk_comment,...
                 Param.LRoM_FootDsl_extendedKnee_freeLowAnk_comment}';
    Cell(:,6) = {Param.LRoM_HipExtension,Param.LRoM_HipAdduction_extendedKnee,...
                 Param.LRoM_HipAdduction_flexedKnee,Param.LRoM_HipIntRotation,...
                 Param.LRoM_KneeExtension_flexedHip,Param.LRoM_KneeExtension_extendedHip,...
                 Param.LRoM_FootPlt_flexedKnee_fixedLowAnk,Param.LRoM_FootPlt_extendedKnee_fixedLowAnk,...
                 Param.LRoM_FootPlt_extendedKnee_freeLowAnk}';
    Cell(:,7) = {Param.LRoM_HipExtension_comment,Param.LRoM_HipAdduction_extendedKnee_comment,...
                 Param.LRoM_HipAdduction_flexedKnee_comment,Param.LRoM_HipIntRotation_comment,...
                 Param.LRoM_KneeExtension_flexedHip_comment,Param.LRoM_KneeExtension_extendedHip_comment,...
                 Param.LRoM_FootPlt_flexedKnee_fixedLowAnk_comment,...
                 Param.LRoM_FootPlt_extendedKnee_fixedLowAnk_comment,...
                 Param.LRoM_FootPlt_extendedKnee_freeLowAnk_comment}';
    Cell(:,8) = {Param.RRoM_HipFlexion,Param.RRoM_HipAbduction_extendedKnee,...
                 Param.RRoM_HipAbduction_flexedKnee,Param.RRoM_HipExtRotation,...
                 Param.RRoM_KneeFlexion_flexedHip,Param.RRoM_KneeFlexion_extendedHip,...
                 Param.RRoM_FootDsl_flexedKnee_fixedLowAnk,Param.RRoM_FootDsl_extendedKnee_fixedLowAnk,...
                 Param.RRoM_FootDsl_extendedKnee_freeLowAnk}';
    Cell(:,9) = {Param.RRoM_HipFlexion_comment,Param.RRoM_HipAbduction_extendedKnee_comment,...
                 Param.RRoM_HipAbduction_flexedKnee_comment,Param.RRoM_HipExtRotation_comment,...
                 Param.RRoM_KneeFlexion_flexedHip_comment,Param.RRoM_KneeFlexion_extendedHip_comment,...
                 Param.RRoM_FootDsl_flexedKnee_fixedLowAnk_comment,...
                 Param.RRoM_FootDsl_extendedKnee_fixedLowAnk_comment,...
                 Param.RRoM_FootDsl_extendedKnee_freeLowAnk_comment}';
    Cell(:,10) = {Param.RRoM_HipExtension,Param.RRoM_HipAdduction_extendedKnee,...
                  Param.RRoM_HipAdduction_flexedKnee,Param.RRoM_HipIntRotation,...
                  Param.RRoM_KneeExtension_flexedHip,Param.RRoM_KneeExtension_extendedHip,...
                  Param.RRoM_FootPlt_flexedKnee_fixedLowAnk,Param.RRoM_FootPlt_extendedKnee_fixedLowAnk,...
                  Param.RRoM_FootPlt_extendedKnee_freeLowAnk}';
    Cell(:,11) = {Param.RRoM_HipExtension_comment,Param.RRoM_HipAdduction_extendedKnee_comment,...
                  Param.RRoM_HipAdduction_flexedKnee_comment,Param.RRoM_HipIntRotation_comment,...
                  Param.RRoM_KneeExtension_flexedHip_comment,Param.RRoM_KneeExtension_extendedHip_comment,...
                  Param.RRoM_FootPlt_flexedKnee_fixedLowAnk_comment,...
                  Param.RRoM_FootPlt_extendedKnee_fixedLowAnk_comment,...
                  Param.RRoM_FootPlt_extendedKnee_freeLowAnk_comment}';


    Ypos = 0.765; %Y-Position of textbox lower corner


    for i = 1:size(Cell,1) %for Rows of Cell
        Xpos = XposStart; %X-Position of textbox lower left corner
        Width = 0.052; %Width of textbox
        Height = 0.032; %Height of textbox

        if mod (i,2) %if i = odd number
           BackgroundColor = GreyBackground;          
        else 
           BackgroundColor = 'none';
        end

        %Column 1
        annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',Cell{i,1},...
                  'FontWeight','light','FontSize',10,'FitBoxToText','off','LineStyle','none',...
                  'EdgeColor','none','BackgroundColor',BackgroundColor);

        Xpos = Xpos + Width;
        Width = 0.172;

        %Column 2 & 2b
        annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',Cell{i,2},...
                  'FontWeight','light','FontSize',10,'FitBoxToText','off','LineStyle','none',...
                  'EdgeColor','none','BackgroundColor',BackgroundColor);

        annotation(figure1,'textbox',[Xpos Ypos+0.007 Width 0.011],'String',Cell{i,3},...
                  'FontWeight','light','FontSize',7,'FitBoxToText','off','LineStyle','none',...
                  'EdgeColor','none','BackgroundColor','none');

        Xpos = Xpos + Width;
%         Width = 0.044;    

       for j = 4:11

           if ~mod (j,2)
              Width = 0.044;
              FrontSize = 10;
              f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                            FrontSize,BackgroundColor,'right')

              Xpos = Xpos + Width;

           else Width = 0.125;
                FrontSize = 7;
                f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                              FrontSize,BackgroundColor,'left')

                Xpos = Xpos + Width;
           end

       end %FOR j = 1:11

       Ypos = Ypos - Height;

    end %FOR i = 1:size(Cell,1)


    %% Rectangles around tables

    %around entire table
    annotation(figure1,'rectangle',[XposStart Ypos+Height 0.899 0.289]);%,'FaceColor','flat');%0.316
    %around left side
    annotation(figure1,'rectangle',[0.275 Ypos+Height 0.3380 0.289]);%,'FaceColor','flat');
    %around knee
    annotation(figure1,'rectangle',[XposStart Ypos+(4*Height) 0.899 2*Height]);%,'FaceColor','flat');
    

    %% Spasticity

    annotation(figure1,'textbox',[0.274 0.468 0.3252 0.03],'String',{'Spastik-Skala'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off','VerticalAlignment','middle',...
              'LineStyle','none');
    annotation(figure1,'textbox',[0.394 0.468 0.3252 0.03],'String',{'(Ashworth/Bohannon modifiziert)'},...
              'FontWeight','bold','FontSize',7,'FitBoxToText','off','VerticalAlignment','middle',...
              'LineStyle','none');

    % Left
    annotation(figure1,'textbox',[0.274 0.450 0.19 0.03],'String',{'Links'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
              'LineStyle','none','Color',[1 0 0]);

    % Right
    annotation(figure1,'textbox',[0.443 0.450 0.19 0.03],'String',{'Rechts'},...
               'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
               'LineStyle','none','Color',[0 0 1]);

    % Manual muscle strength
    annotation(figure1,'textbox',[0.612 0.468 0.3252 0.03],'String',{'Manueller Muskelkrafttest'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off','VerticalAlignment','middle',...
              'LineStyle','none');

    % Left
    annotation(figure1,'textbox',[0.612 0.450 0.19 0.03],'String',{'Links'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
              'LineStyle','none','Color',[1 0 0]);

    % Right
    annotation(figure1,'textbox',[0.781 0.450 0.19 0.03],'String',{'Rechts'},...
              'FontWeight','bold','FontSize',10,'FitBoxToText','off',...
              'LineStyle','none','Color',[0 0 1]);


    Cell = {'H�fte','','','','','','','Knie','','','Fuss','','','Pendel'}';
    Cell(:,2) = {'Flexoren','Extensoren','Adduktoren','Abduktoren','Innenrotatoren',...
                 'Exorotatoren','Duncan Ely Test','Flexoren','Extensoren','Aktives Streckdefizit',...
                 'Plantarflexoren','Plantarflexoren','Dorsalflexoren','-Test (frei/steif)'}';
    Cell(:,3) = {'','','','','','','','','','(Grad)','(Knie 90�)','(Knie gestreckt)','',''}';
    Cell(:,4) = {Param.LSpastic_HipFlexor,Param.LSpastic_HipExtensor,Param.LSpastic_HipAdductor,...
                 '/',Param.LSpastic_HipIntRotator,Param.LSpastic_HipExtRotator,...
                 Param.LSpastic_DuncanElyTest,Param.LSpastic_KneeFlexor,Param.LSpastic_KneeExtensor,...
                 '/',Param.LSpastic_FootPltFlexor_flexedKnee,Param.LSpastic_FootPltFlexor_extendedKnee,...
                 Param.LSpastic_FootDslFlexor,Param.LPendelTest}';
    Cell(:,5) = {Param.LSpastic_HipFlexor_comment,Param.LSpastic_HipExtensor_comment,Param.LSpastic_HipAdductor_comment,...
                 '',Param.LSpastic_HipIntRotator_comment,Param.LSpastic_HipExtRotator_comment,...
                 Param.LSpastic_DuncanElyTest_comment,Param.LSpastic_KneeFlexor_comment,Param.LSpastic_KneeExtensor_comment,...
                 '',Param.LSpastic_FootPltFlexor_flexedKnee_comment,Param.LSpastic_FootPltFlexor_extendedKnee_comment,...
                 Param.LSpastic_FootDslFlexor_comment,Param.LPendelTest_comment}';
    Cell(:,6) = {Param.RSpastic_HipFlexor,Param.RSpastic_HipExtensor,Param.RSpastic_HipAdductor,...
                 '/',Param.RSpastic_HipIntRotator,Param.RSpastic_HipExtRotator,...
                 Param.RSpastic_DuncanElyTest,Param.RSpastic_KneeFlexor,Param.RSpastic_KneeExtensor,...
                 '/',Param.RSpastic_FootPltFlexor_flexedKnee,Param.RSpastic_FootPltFlexor_extendedKnee,...
                 Param.RSpastic_FootDslFlexor,Param.RPendelTest}';
    Cell(:,7) = {Param.RSpastic_HipFlexor_comment,Param.RSpastic_HipExtensor_comment,Param.RSpastic_HipAdductor_comment,...
                 '',Param.RSpastic_HipIntRotator_comment,Param.RSpastic_HipExtRotator_comment,...
                 Param.RSpastic_DuncanElyTest_comment,Param.RSpastic_KneeFlexor_comment,Param.RSpastic_KneeExtensor_comment,...
                 '',Param.RSpastic_FootPltFlexor_flexedKnee_comment,Param.RSpastic_FootPltFlexor_extendedKnee_comment,...
                 Param.RSpastic_FootDslFlexor_comment,Param.RPendelTest_comment}';
    Cell(:,8) = {Param.LStrength_HipFlexor,Param.LStrength_HipExtensor,'/',Param.LStrength_HipAbductor,...
                 Param.LStrength_HipIntRotator,Param.LStrength_HipExtRotator,...
                 '/',Param.LStrength_KneeFlexor,Param.LStrength_KneeExtensor,...
                 Param.LStrength_KneeExtDeficit,'/',Param.LStrength_FootPltFlexor,...
                 Param.LStrength_FootDslFlexor,'/'}';
    Cell(:,9) = {Param.LStrength_HipFlexor_comment,Param.LStrength_HipExtensor_comment,'',Param.LStrength_HipAbductor_comment,...
                 Param.LStrength_HipIntRotator_comment,Param.LStrength_HipExtRotator_comment,...
                 '',Param.LStrength_KneeFlexor_comment,Param.LStrength_KneeExtensor_comment,...
                 Param.LStrength_KneeExtDeficit_comment,'',Param.LStrength_FootPltFlexor_comment,...
                 Param.LStrength_FootDslFlexor_comment,''}';
    Cell(:,10) = {Param.RStrength_HipFlexor,Param.RStrength_HipExtensor,'/',Param.RStrength_HipAbductor,...
                 Param.RStrength_HipIntRotator,Param.RStrength_HipExtRotator,...
                 '/',Param.RStrength_KneeFlexor,Param.RStrength_KneeExtensor,...
                 Param.RStrength_KneeExtDeficit,'/',Param.RStrength_FootPltFlexor,...
                 Param.RStrength_FootDslFlexor,'/'}';
    Cell(:,11) = {Param.RStrength_HipFlexor_comment,Param.RStrength_HipExtensor_comment,'',Param.RStrength_HipAbductor_comment,...
                 Param.RStrength_HipIntRotator_comment,Param.RStrength_HipExtRotator_comment,...
                 '',Param.RStrength_KneeFlexor_comment,Param.RStrength_KneeExtensor_comment,...
                 Param.RStrength_KneeExtDeficit_comment,'',Param.RStrength_FootPltFlexor_comment,...
                 Param.RStrength_FootDslFlexor_comment,''}';


    Ypos = 0.425;%0.393; %Y-Position of textbox lower corner


    for i = 1:size(Cell,1) %for Rows of Cell
        Xpos = XposStart; %X-Position of textbox lower left corner
        Width = 0.052; %Width of textbox
        Height = 0.032; %Height of textbox

        if mod (i,2) %if i = odd number
           BackgroundColor = GreyBackground;          
        else 
           BackgroundColor = 'none';
        end

        %Column 1
        annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',Cell{i,1},...
                  'FontWeight','light','FontSize',10,'FitBoxToText','off','LineStyle','none',...
                  'EdgeColor','none','BackgroundColor',BackgroundColor);

        Xpos = Xpos + Width;
        Width = 0.172;

        %Column 2 & 2b
        annotation(figure1,'textbox',[Xpos Ypos Width Height],'String',Cell{i,2},...
                  'FontWeight','light','FontSize',10,'FitBoxToText','off','LineStyle','none',...
                  'EdgeColor','none','BackgroundColor',BackgroundColor);

        annotation(figure1,'textbox',[Xpos Ypos+0.007 Width 0.011],'String',Cell{i,3},...
                  'FontWeight','light','FontSize',7,'FitBoxToText','off','LineStyle','none',...
                  'EdgeColor','none','BackgroundColor','none');

        Xpos = Xpos + Width;
%         Width = 0.044;    


       for j = 4:11

           if ~mod (j,2)
              Width = 0.044;
              FrontSize = 10;
              f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                            FrontSize,BackgroundColor,'left')

              Xpos = Xpos + Width;

           else Width = 0.125;
                FrontSize = 7;
                f_makeTextbox(figure1,Cell{i,j},Xpos,Ypos,Width,Height,...
                              FrontSize,BackgroundColor,'left')

                Xpos = Xpos + Width;
           end

       end %FOR j = 1:size(Cell,1)

        Ypos = Ypos - Height;

    end %FOR i = 1:14


    %% Rectangles around tables

    %around entire table
    annotation(figure1,'rectangle',[XposStart Ypos+Height 0.899 0.448]);%,'FaceColor','flat');
    %around spasticity left side
    annotation(figure1,'rectangle',[0.275 Ypos+Height 0.169 0.448]);%,'FaceColor','flat');
    %around muscle strength left side
    annotation(figure1,'rectangle',[0.612 Ypos+Height 0.169 0.448]);%,'FaceColor','flat');
    %around knee
    annotation(figure1,'rectangle',[XposStart Ypos+(5*Height) 0.899 3*Height]);%,'FaceColor','flat');
    %Pendel-Test
    annotation(figure1,'rectangle',[XposStart Ypos+Height 0.899 0.032]);%,'FaceColor','flat');

    
    %% Page Number
    f_makeTextbox(figure1,'- 2 -',0.849,0.001,0.10,0.0,7,'none','right')

end %FUNKTION    
    