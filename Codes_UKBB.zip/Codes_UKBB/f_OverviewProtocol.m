%{ 
*********************************************************************************
              Function "f_OverviewProtocol" linked to 
script "Auswertung_mitFormularen" & "Datenarchivierung_footmodel"
                     by Katrin Schweizer Feb. 2015
*********************************************************************************

Creates an overview sheet for the folders in the lab about what was done during
the measurements (Name, Dignosis, measurements, conditions).

INPUT
  Protocol = Struct with data from google formular of all measurements
  TibiaTorsion_static = tibia torsion as calculated from static trial
                        between ankle markers and KAX-KNEM. Calculated in
                        2D, positive = external

OUTPUT
  Figure for folders in gait lab.
%}

function f_OverviewProtocol(Protocol,TibiaTorsion_static)

   % Create figure
   Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]


   %% Header
   
   % Visum Ganglabor:
   annotation(Fig,'textbox',[0.0659 0.955 0.204 0.0378],'String',{'Visum Ganglabor:'},...
             'FontWeight','bold','FitBoxToText','off','LineStyle','none');

   % Physio: xy1
   annotation(Fig,'textbox',[0.223 0.9545 0.290 0.037],'String',['Kl. Untersuchung: ',Protocol.Physio],...
             'FitBoxToText','off','LineStyle','none');

   % BW: xy2
   annotation(Fig,'textbox',[0.523 0.9545 0.232 0.037],'String',['BW: ',Protocol.Scientist],...
             'FitBoxToText','off','LineStyle','none');



   %% Datum:
   annotation(Fig,'textbox',[0.73 0.955 0.193 0.0361],'String',{'Datum:'},...
             'FontWeight','bold','FitBoxToText','off','LineStyle','none');

   % Data
   annotation(Fig,'textbox',[0.81 0.956 0.193 0.036],'String',Protocol.Date,...
             'FitBoxToText','off','LineStyle','none');
         
   %Line
   annotation(Fig,'line',[0.0778985507246377 0.916666666666667],...
    [0.96 0.96],'LineWidth',1.5);


   %% Ganglabor ID:
   annotation(Fig,'textbox',[0.671 0.920 0.201 0.036],'String',{'Ganglabor ID:'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Data
   annotation(Fig,'textbox',[0.844 0.922 0.189 0.033],'String',Protocol.GL_nb,...
             'FontSize',10,'FitBoxToText','off','LineStyle','none');


   %% Name, Vorname:','','Geburtsdatum:','
   annotation(Fig,'textbox',[0.066 0.805 0.193 0.151],...
             'String',{'Name, Vorname:','','Geburtsdatum:'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Data
   annotation(Fig,'textbox',[0.223 0.857 0.256 0.100],'String',{[Protocol.Surname,', ',Protocol.Firstname],'',Protocol.Birthday},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

         
   %% Diagnose:
   
   annotation(Fig,'textbox',[0.066 0.835 0.191 0.049],'String',{'Diagnose:'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Data
   Diagnostic_infos = strrep(Protocol.Diagnostic_infos,'; ','\newline');
   Therapie_infos = strrep(Protocol.Therapie_infos,'; ','\newline');
   
   annotation(Fig,'textbox',[0.223 0.751 0.711 0.133],'String',{Diagnostic_infos,'',Therapie_infos},...
              'FontSize',10,'FitBoxToText','off','LineStyle','none');

         
   %% Fragestellung:
   Question = strrep(Protocol.Question,'; ','\newline');
   annotation(Fig,'textbox',[0.068 0.714 0.191 0.049],'String',{'Fragestellung:'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Data
   annotation(Fig,'textbox',[0.223 0.670 0.706 0.092],'String',Question,...
             'FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Line
    annotation(Fig,'line',[0.0778985507246377 0.916666666666667],...
    [0.72 0.72],'LineWidth',1.5);

         
%% *****************************************************************
%% Bedingungen 1:
%% *****************************************************************
   %% Model
   
   if strncmp('PiG Ganzk�rper',Protocol.Model1,14)
      Model = 'PiG UB';
   elseif strncmp('PiG Unterk�rper',Protocol.Model1,15)
      Model = 'PiG LB';
   elseif strncmp('Fussmodell',Protocol.Model1,10)
      Model = 'Foot';
   else Model = Protocol.Model1;
   end %IF strncmp('PiG Ganzk�rper',Protocol.Model1,14)
   
   annotation(Fig,'textbox',[0.067 0.652 0.208 0.063],'String',{[Protocol.session1, '   (' Model ')']},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Data
   if strcmp(Protocol.Left_Heelrise1,'') % in case someone has nothing filled in in the google form --> set Protocoleter to zero
      Protocol.Left_Heelrise1 = '0';
   end
   
   if strcmp(Protocol.Left_Solerise1,'')
      Protocol.Left_Solerise1 = '0';
   end
   
   if strcmp(Protocol.Right_Heelrise1,'')
      Protocol.Right_Heelrise1 = '0';
   end
   
   if strcmp(Protocol.Right_Solerise1,'')
      Protocol.Right_Solerise1 = '0';
   end
   
   Condition{1,1} = ['Links: ',Protocol.Left_Condition1,' ',Protocol.Left_Condition_infos1];
   
   if ~strcmp(Protocol.Left_Heelrise1,'0') && strcmp(Protocol.Left_Solerise1,'0')
      Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise1,' cm'];
   elseif strcmp(Protocol.Left_Heelrise1,'0') && ~strcmp(Protocol.Left_Solerise1,'0')
      Condition{1,1} = [Condition{1,1},', sole ',Protocol.Left_Solerise1,' cm'];
   elseif ~strcmp(Protocol.Left_Heelrise1,'0') && ~strcmp(Protocol.Left_Solerise1,'0')
      Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise1,' cm',', sole ',Protocol.Left_Solerise1,' cm']; 
   end %IF Protocol.Left_Heelrise ~= '0' && Protocol.Left_Solerise == '0'
   
   Condition{1,1} = [Condition{1,1}, ', TibTors (roomCoord.) = ', ...
                     num2str(TibiaTorsion_static.roomCoordinate.left), '�/',...
                     num2str(TibiaTorsion_static.tibiaCoordinate.left),' (tibCoord.)'];
   
   Condition{1,2} = ['Rechts: ',Protocol.Right_Condition1,' ',Protocol.Right_Condition_infos1];
   if ~strcmp(Protocol.Right_Heelrise1,'0') && strcmp(Protocol.Right_Solerise1,'0')
      Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise1,' cm'];
   elseif strcmp(Protocol.Right_Heelrise1,'0') && ~strcmp(Protocol.Right_Solerise1,'0')
      Condition{1,2} = [Condition{1,2},', sole ',Protocol.Right_Solerise1,' cm'];
   elseif ~strcmp(Protocol.Right_Heelrise1,'0') && ~strcmp(Protocol.Right_Solerise1,'0')
      Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise1,' cm',', sole ',Protocol.Right_Solerise1,' cm']; 
   end %IF Protocol.Right_Heelrise ~= '0' && Protocol.Right_Solerise == '0' 
   
   Condition{1,2} = [Condition{1,2}, ', TibTors (roomCoord.) = ', ...
                     num2str(TibiaTorsion_static.roomCoordinate.right), '�/',...
                     num2str(TibiaTorsion_static.tibiaCoordinate.right),' (tibCoord.)'];
   
   % if any help was needed while walking
   if ~strcmp(Protocol.Help1,'keine')
      Condition{1,3} = [Protocol.Help1,' ',Protocol.Side_Help1,' ',Protocol.Help_infos1];

   end %IF ~strcmp(Protocol.Help,'keine')
     
   annotation(Fig,'textbox',[0.223 0.653 0.706 0.062],'String',Condition,...
             'FontSize',10,'FitBoxToText','off','LineStyle','none');        

             
   %% Bemerkungen:
   
   annotation(Fig,'textbox',[0.067 0.570 0.208 0.045],'String',{'Bemerkungen:'},...
             'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

   Measure_comment = strrep(Protocol.Measure1_comment,'; ','\newline');
   Measure_GL_comment = strrep(Protocol.Measure1_GL_comment,'; ','\newline');
   EMG_comment = strrep(Protocol.EMG1_comment,'; ','\newline');
   clinical_exam_comment = strrep(Protocol.clinical_exam_comment,'; ','\newline');
   
   % Data
   x = 1;
   if ~strcmp(Protocol.Measure1_comment,'')
      Comment{1,x} = ['GA: ',Measure_comment];
      x = x+1;
   else Comment{1,x} = '';
   end %IF ~strcmp(Protocol.Measure_comment,'')
       
   if ~strcmp(Protocol.Measure1_GL_comment,'')
      Comment{1,x} = ['GA intern: ',Measure_GL_comment];
      x = x+1;
   else Comment{1,x} = '';
   end
   
   if ~strcmp(Protocol.EMG1_comment,'')
      Comment{1,x} = ['EMG: ',EMG_comment];
      x = x+1;
   else Comment{1,x} = '';
   end %IF ~strcmp(Protocol.EMG_comment,'')
   
   if ~strcmp(Protocol.clinical_exam_comment,'')
      Comment{1,x} = ['Klinik: ',clinical_exam_comment];
   else Comment{1,x} = '';

   end %IF ~strcmp(Protocol.clinical_exam_comment,'')
   
   annotation(Fig,'textbox',[0.223 0.512 0.711 0.104],'String',Comment,...
             'FontSize',10,'FitBoxToText','off','LineStyle','none');

   % Line
    annotation(Fig,'line',[0.0778985507246377 0.916666666666667],...
    [0.53 0.53],'linestyle','--');


%% *****************************************************************
%% Bedingungen 2:
%% *****************************************************************
   
    if ~isempty(Protocol.session2)
        
       %% Model
       if strncmp('PiG Ganzk�rper',Protocol.Model2,14)
          Model = 'PiG UB';
       elseif strncmp('PiG Unterk�rper',Protocol.Model2,15)
          Model = 'PiG LB';
       elseif strncmp('Fussmodell',Protocol.Model2,10)
          Model = 'Foot';
       else Model = Protocol.Model2;
       end %IF strncmp('PiG Ganzk�rper',Protocol.Model2,14)

       annotation(Fig,'textbox',[0.067 0.46 0.208 0.063],'String',{[Protocol.session2, '   (' Model ')']},...
                 'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

       % Data
       if strcmp(Protocol.Left_Heelrise2,'') % in case someone has nothing filled in in the google form --> set Protocoleter to zero
          Protocol.Left_Heelrise2 = '0';
       end

       if strcmp(Protocol.Left_Solerise2,'')
          Protocol.Left_Solerise2 = '0';
       end

       if strcmp(Protocol.Right_Heelrise2,'')
          Protocol.Right_Heelrise2 = '0';
       end

       if strcmp(Protocol.Right_Solerise2,'')
          Protocol.Right_Solerise2 = '0';
       end

       Condition{1,1} = ['Links: ',Protocol.Left_Condition2,' ',Protocol.Left_Condition_infos2];

       if ~strcmp(Protocol.Left_Heelrise2,'0') && strcmp(Protocol.Left_Solerise2,'0')
          Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise2,' cm'];
       elseif strcmp(Protocol.Left_Heelrise2,'0') && ~strcmp(Protocol.Left_Solerise2,'0')
          Condition{1,1} = [Condition{1,1},', sole ',Protocol.Left_Solerise2,' cm'];
       elseif ~strcmp(Protocol.Left_Heelrise2,'0') && ~strcmp(Protocol.Left_Solerise2,'0')
          Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise2,' cm',', sole ',Protocol.Left_Solerise2,' cm']; 
       end %IF Protocol.Left_Heelrise ~= '0' && Protocol.Left_Solerise == '0'

       Condition{1,2} = ['Rechts: ',Protocol.Right_Condition2,' ',Protocol.Right_Condition_infos2];
       if ~strcmp(Protocol.Right_Heelrise2,'0') && strcmp(Protocol.Right_Solerise2,'0')
          Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise2,' cm'];
       elseif strcmp(Protocol.Right_Heelrise2,'0') && ~strcmp(Protocol.Right_Solerise2,'0')
          Condition{1,2} = [Condition{1,2},', sole ',Protocol.Right_Solerise2,' cm'];
       elseif ~strcmp(Protocol.Right_Heelrise2,'0') && ~strcmp(Protocol.Right_Solerise2,'0')
          Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise2,' cm',', sole ',Protocol.Right_Solerise2,' cm']; 
       end %IF Protocol.Right_Heelrise ~= '0' && Protocol.Right_Solerise == '0' 

       % if any help was needed while walking
       if ~strcmp(Protocol.Help2,'keine')
          Condition{1,3} = [Protocol.Help2,' ',Protocol.Side_Help2,' ',Protocol.Help_infos2];

       end %IF ~strcmp(Protocol.Help,'keine')

       annotation(Fig,'textbox',[0.223 0.461 0.706 0.062],'String',Condition,...
                 'FontSize',10,'FitBoxToText','off','LineStyle','none');

       clearvars Condition Comment 

       %% Bemerkungen 2:

       annotation(Fig,'textbox',[0.067 0.378 0.208 0.045],'String',{'Bemerkungen:'},...
                 'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

       Measure_comment = strrep(Protocol.Measure2_comment,'; ','\newline');
       Measure_GL_comment = strrep(Protocol.Measure2_GL_comment,'; ','\newline');
       EMG_comment = strrep(Protocol.EMG2_comment,'; ','\newline');

       % Data
       x = 1;
       if ~strcmp(Protocol.Measure2_comment,'')
          Comment{1,x} = ['GA: ',Measure_comment];
          x = x+1;
       else Comment{1,x} = '';
       end %IF ~strcmp(Protocol.Measure_comment,'')

       if ~strcmp(Protocol.Measure2_GL_comment,'')
          Comment{1,x} = ['GA intern: ',Measure_GL_comment];
          x = x+1;
       else Comment{1,x} = '';
       end

       if ~strcmp(Protocol.EMG2_comment,'')
          Comment{1,x} = ['EMG: ',EMG_comment];
       else Comment{1,x} = '';
       end %IF ~strcmp(Protocol.EMG_comment,'')

       annotation(Fig,'textbox',[0.223 0.32 0.711 0.104],'String',Comment,...
                 'FontSize',10,'FitBoxToText','off','LineStyle','none');

       % Line
       annotation(Fig,'line',[0.0778985507246377 0.916666666666667],...
        [0.338 0.338],'linestyle','--');

       clearvars Condition Comment 

    end %IF ~isempty(Protocol.session2)

%% *****************************************************************
%% Bedingungen 3:
%% *****************************************************************

    if ~isempty(Protocol.session3)  
        %% Model   
       if strncmp('PiG Ganzk�rper',Protocol.Model3,14)
          Model = 'PiG UB';
       elseif strncmp('PiG Unterk�rper',Protocol.Model3,15)
          Model = 'PiG LB';
       elseif strncmp('Fussmodell',Protocol.Model3,10)
          Model = 'Foot';
       else Model = Protocol.Model3;
       end %IF strncmp('PiG Ganzk�rper',Protocol.Model3,14) 

       annotation(Fig,'textbox',[0.067 0.268 0.208 0.063],'String',{[Protocol.session3, '   (' Model ')']},...
                 'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

       % Data
       if strcmp(Protocol.Left_Heelrise3,'') % in case someone has nothing filled in in the google form --> set Protocoleter to zero
          Protocol.Left_Heelrise3 = '0';
       end

       if strcmp(Protocol.Left_Solerise3,'')
          Protocol.Left_Solerise3 = '0';
       end

       if strcmp(Protocol.Right_Heelrise3,'')
          Protocol.Right_Heelrise3 = '0';
       end

       if strcmp(Protocol.Right_Solerise3,'')
          Protocol.Right_Solerise3 = '0';
       end

       Condition{1,1} = ['Links: ',Protocol.Left_Condition3,' ',Protocol.Left_Condition_infos3];

       if ~strcmp(Protocol.Left_Heelrise3,'0') && strcmp(Protocol.Left_Solerise3,'0')
          Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise3,' cm'];
       elseif strcmp(Protocol.Left_Heelrise3,'0') && ~strcmp(Protocol.Left_Solerise3,'0')
          Condition{1,1} = [Condition{1,1},', sole ',Protocol.Left_Solerise3,' cm'];
       elseif ~strcmp(Protocol.Left_Heelrise3,'0') && ~strcmp(Protocol.Left_Solerise3,'0')
          Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise3,' cm',', sole ',Protocol.Left_Solerise3,' cm']; 
       end %IF Protocol.Left_Heelrise ~= '0' && Protocol.Left_Solerise == '0'

       Condition{1,2} = ['Rechts: ',Protocol.Right_Condition3,' ',Protocol.Right_Condition_infos3];
       if ~strcmp(Protocol.Right_Heelrise3,'0') && strcmp(Protocol.Right_Solerise3,'0')
          Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise3,' cm'];
       elseif strcmp(Protocol.Right_Heelrise3,'0') && ~strcmp(Protocol.Right_Solerise3,'0')
          Condition{1,2} = [Condition{1,2},', sole ',Protocol.Right_Solerise3,' cm'];
       elseif ~strcmp(Protocol.Right_Heelrise3,'0') && ~strcmp(Protocol.Right_Solerise3,'0')
          Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise3,' cm',', sole ',Protocol.Right_Solerise3,' cm']; 
       end %IF Protocol.Right_Heelrise ~= '0' && Protocol.Right_Solerise == '0' 

       % if any help was needed while walking
       if ~strcmp(Protocol.Help3,'keine')
          Condition{1,3} = [Protocol.Help3,' ',Protocol.Side_Help3,' ',Protocol.Help_infos3];

       end %IF ~strcmp(Protocol.Help,'keine')

       annotation(Fig,'textbox',[0.223 0.269 0.706 0.062],'String',Condition,...
                 'FontSize',10,'FitBoxToText','off','LineStyle','none');


       %% Bemerkungen 3:

       annotation(Fig,'textbox',[0.067 0.185 0.208 0.045],'String',{'Bemerkungen:'},...
                 'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

       Measure_comment = strrep(Protocol.Measure3_comment,'; ','\newline');
       Measure_GL_comment = strrep(Protocol.Measure3_GL_comment,'; ','\newline');
       EMG_comment = strrep(Protocol.EMG3_comment,'; ','\newline');

       % Data
       x = 1;
       if ~strcmp(Protocol.Measure3_comment,'')
          Comment{1,x} = ['GA: ',Measure_comment];
          x = x+1;
       else Comment{1,x} = '';
       end %IF ~strcmp(Protocol.Measure_comment,'')

       if ~strcmp(Protocol.Measure3_GL_comment,'')
          Comment{1,x} = ['GA intern: ',Measure_GL_comment];
          x = x+1;
       else Comment{1,x} = '';
       end

       if ~strcmp(Protocol.EMG3_comment,'')
          Comment{1,x} = ['EMG: ',EMG_comment];
       else Comment{1,x} = '';
       end %IF ~strcmp(Protocol.EMG_comment,'')

       annotation(Fig,'textbox',[0.223 0.127 0.711 0.104],'String',Comment,...
                 'FontSize',10,'FitBoxToText','off','LineStyle','none');
       % Line
       annotation(Fig,'line',[0.0778985507246377 0.916666666666667],...
        [0.145 0.145],'linestyle','--');

    end %IF ~isempty(Protocol.session3)

%% *****************************************************************
%% Bedingungen 4:
%% *****************************************************************

    if ~isempty(Protocol.session4)  
        %% Model   
       if strncmp('PiG Ganzk�rper',Protocol.Model4,14)
          Model = 'PiG UB';
       elseif strncmp('PiG Unterk�rper',Protocol.Model4,15)
          Model = 'PiG LB';
       elseif strncmp('Fussmodell',Protocol.Model4,10)
          Model = 'Foot';
       else Model = Protocol.Model4;
       end %IF strncmp('PiG Ganzk�rper',Protocol.Model4,14) 

       annotation(Fig,'textbox',[0.067 0.080 0.208 0.063],'String',{[Protocol.session4, '   (' Model ')']},...
                 'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

       % Data
       if strcmp(Protocol.Left_Heelrise4,'') % in case someone has nothing filled in in the google form --> set Protocoleter to zero
          Protocol.Left_Heelrise4 = '0';
       end

       if strcmp(Protocol.Left_Solerise4,'')
          Protocol.Left_Solerise4 = '0';
       end

       if strcmp(Protocol.Right_Heelrise4,'')
          Protocol.Right_Heelrise4 = '0';
       end

       if strcmp(Protocol.Right_Solerise4,'')
          Protocol.Right_Solerise4 = '0';
       end

       Condition{1,1} = ['Links: ',Protocol.Left_Condition4,' ',Protocol.Left_Condition_infos4];

       if ~strcmp(Protocol.Left_Heelrise4,'0') && strcmp(Protocol.Left_Solerise4,'0')
          Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise4,' cm'];
       elseif strcmp(Protocol.Left_Heelrise4,'0') && ~strcmp(Protocol.Left_Solerise4,'0')
          Condition{1,1} = [Condition{1,1},', sole ',Protocol.Left_Solerise4,' cm'];
       elseif ~strcmp(Protocol.Left_Heelrise4,'0') && ~strcmp(Protocol.Left_Solerise4,'0')
          Condition{1,1} = [Condition{1,1},', heel ',Protocol.Left_Heelrise4,' cm',', sole ',Protocol.Left_Solerise4,' cm']; 
       end %IF Protocol.Left_Heelrise ~= '0' && Protocol.Left_Solerise == '0'

       Condition{1,2} = ['Rechts: ',Protocol.Right_Condition4,' ',Protocol.Right_Condition_infos4];
       if ~strcmp(Protocol.Right_Heelrise4,'0') && strcmp(Protocol.Right_Solerise4,'0')
          Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise4,' cm'];
       elseif strcmp(Protocol.Right_Heelrise4,'0') && ~strcmp(Protocol.Right_Solerise4,'0')
          Condition{1,2} = [Condition{1,2},', sole ',Protocol.Right_Solerise4,' cm'];
       elseif ~strcmp(Protocol.Right_Heelrise4,'0') && ~strcmp(Protocol.Right_Solerise4,'0')
          Condition{1,2} = [Condition{1,2},', heel ',Protocol.Right_Heelrise4,' cm',', sole ',Protocol.Right_Solerise4,' cm']; 
       end %IF Protocol.Right_Heelrise ~= '0' && Protocol.Right_Solerise == '0' 

       % if any help was needed while walking
       if ~strcmp(Protocol.Help4,'keine')
          Condition{1,3} = [Protocol.Help4,' ',Protocol.Side_Help4,' ',Protocol.Help_infos4];

       end %IF ~strcmp(Protocol.Help,'keine')

       annotation(Fig,'textbox',[0.223 0.08 0.706 0.062],'String',Condition,...
                 'FontSize',10,'FitBoxToText','off','LineStyle','none');


       %% Bemerkungen 4:

       annotation(Fig,'textbox',[0.067 0.05 0.208 0.045],'String',{'Bemerkungen:'},...
                 'FontWeight','bold','FontSize',10,'FitBoxToText','off','LineStyle','none');

       Measure_comment = strrep(Protocol.Measure4_comment,'; ','\newline');
       Measure_GL_comment = strrep(Protocol.Measure4_GL_comment,'; ','\newline');
       EMG_comment = strrep(Protocol.EMG4_comment,'; ','\newline');

       % Data
       x = 1;
       if ~strcmp(Protocol.Measure4_comment,'')
          Comment{1,x} = ['GA: ',Measure_comment];
          x = x+1;
       else Comment{1,x} = '';
       end %IF ~strcmp(Protocol.Measure_comment,'')

       if ~strcmp(Protocol.Measure4_GL_comment,'')
          Comment{1,x} = ['GA intern: ',Measure_GL_comment];
          x = x+1;
       else Comment{1,x} = '';
       end

       if ~strcmp(Protocol.EMG4_comment,'')
          Comment{1,x} = ['EMG: ',EMG_comment];
       else Comment{1,x} = '';
       end %IF ~strcmp(Protocol.EMG_comment,'')

       annotation(Fig,'textbox',[0.223 0.00 0.711 0.104],'String',Comment,...
                 'FontSize',10,'FitBoxToText','off','LineStyle','none');
    end %IF ~isempty(Protocol.session4)


end %FUNCTION