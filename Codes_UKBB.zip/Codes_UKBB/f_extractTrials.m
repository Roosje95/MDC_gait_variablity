function [out,trials_infos,Params4_c3d] = f_extractTrials(Path_enf,Params4_c3d)
%{
by M. Freslier, Mar. 2017

search the trials in the selected directory, which are of interest (infos
are read from the enf files):
 - static trial (with 'KAD' in description) -> look for eventuell Assume
 Horizontal option
 - running or orthosis trials (only videos)
 - analysed trials of dynamic

INPUT
    Path_enf = path of the place where the enf files are saved
    Params4_c3d = Struct with all clinical measurements & measurement 
                  information form, NameParameter.Value (value is in string)
OUTPUT
    out = 1 if all ok, 0 if there is a problem to determine the kinetic
    trials_infos = struct of the information of the trials, fields are
    filename, Processed (='static','vid_running','vid_orthosis' or
    'dynamic', kinetic, newName
    Params4_c3d = the same struct as input, extent with information from
    Assume Horizontal option from static trial
%}
    list_enfFiles = dir([Path_enf,'\*.enf']);
    trials_infos = struct;
    numberTrials = 1;
    out = 1;
    for index_enfFiles = 1:length(list_enfFiles)
        %% load and read .enf-File
        delimiter = {'='};
        formatSpec = '%s%[^\n\r]'; % text and new line
        fileID = fopen([Path_enf,'\',list_enfFiles(index_enfFiles,1).name],'r');
        % 1st column = name of parameter, 2nd column = corresponding value
        text_enf = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'EmptyValue' ,NaN, 'ReturnOnError', false);
        fclose(fileID);
        clearvars delimiter formatSpec fileID
        if ~isempty(text_enf)
            % changes all captal letters in text_enf to small letters
            for i=1:size(text_enf,2)
                text_enf{1,i} = lower(text_enf{1,i});
            end

            %% look for the type of trial
            index_trialType = find(strcmp(text_enf{1},'type'));
            
            % if no Type or SESSION found
            if ~isempty(index_trialType) && any(strcmp(text_enf{1,2}(index_trialType),'session')) % SESSION found
                continue
            end % if no Type or SESSION found
            
            % if trial is 'Not For Use'
            index_trialStage = find(strcmp(text_enf{1},'stages'));
            if any(index_trialStage) && any(strcmp(text_enf{1,2}(index_trialStage),'not for use')) % not a trial 'Not For Use'
                continue
            end % if trial is 'Not For Use'
            
            index_trialDescription = find(strcmp(text_enf{1},'description'));
            trialName = regexprep(list_enfFiles(index_enfFiles,1).name,'.Trial(\w*).enf','');
            
            % if trial is static with kad
            if any(index_trialDescription) && ...
                  any(strcmp(text_enf{1,2}(index_trialType),'static')) && ...
                  any(strncmp(text_enf{1,2}(index_trialDescription),'kad',3))
                trials_infos(numberTrials).filename = trialName;
                trials_infos(numberTrials).Processed = 'static';
                trials_infos(numberTrials).newName = f_newFilename(trials_infos(numberTrials));
                
                % check for 'Assume horizontal' function
                index_assHoriz_left = find(strcmp(text_enf{1},'left foot flat ticked'));
                index_assHoriz_right = find(strcmp(text_enf{1},'right foot flat ticked'));
                if any(index_assHoriz_left) && any(index_assHoriz_right) && ...
                      any(strcmp(text_enf{1,2}(index_assHoriz_left),'true')) && ...
                      any(strcmp(text_enf{1,2}(index_assHoriz_right),'true'))
                    Params4_c3d.Assume_Horizontal = 'Ja';
                else
                    Params4_c3d.Assume_Horizontal = 'Nein';
                end
                
                disp([[Path_enf,'\',trialName],...
                    '   ',trials_infos(numberTrials).Processed,'  ']); %,trials_infos(numberTrials).kinetic{:,1}]);
                numberTrials = numberTrials + 1;
                continue
            end % if trial is static with kad
            
            % if trial is video of running
            if strncmpi(trialName,'rennen',6)
                trials_infos(numberTrials).filename = trialName;
                trials_infos(numberTrials).Processed = 'vid_running';
                trials_infos(numberTrials).newName = f_newFilename(trials_infos(numberTrials));
                disp([[Path_enf,'\',trialName],...
                    '   ',trials_infos(numberTrials).Processed,'  ']); %,trials_infos(numberTrials).kinetic{:,1}]);
                numberTrials = numberTrials + 1;
                continue
            end % if trial is video of running
            
            % if trial is video of orthosis
            if strncmpi(trialName,'orthese',7)
                trials_infos(numberTrials).filename = trialName;
                trials_infos(numberTrials).Processed = 'vid_orthosis';
                trials_infos(numberTrials).newName = f_newFilename(trials_infos(numberTrials));
                disp([[Path_enf,'\',trialName],...
                    '   ',trials_infos(numberTrials).Processed,'  ']); %,trials_infos(numberTrials).kinetic{:,1}]);
                numberTrials = numberTrials + 1;
                continue
            end % if trial is video of orthosis
            
            % if trial is processed
            index_trialNotes = find(strcmp(text_enf{1},'notes'));
            if ( any(index_trialDescription) && ...
                  any(strncmp(text_enf{1,2}(index_trialDescription),'ok',2)) ) || ...
                  ( any(index_trialNotes) && ...
                  any(strncmp(text_enf{1,2}(index_trialNotes),'ok',2)) )
                trials_infos(numberTrials).filename = trialName;
                trials_infos(numberTrials).Processed = 'dynamic';
                % check the kinetic + name of the new file copied
                %%%%%%%%%%%%%%%%%%%%%%%%
                [out_checkKinetic,trials_infos(numberTrials).kinetic] = ...
                    f_checkKinetic(text_enf{1,2}(index_trialDescription),trialName);
                out = out * out_checkKinetic;
                if out_checkKinetic == 0
                    continue
                end
                trials_infos(numberTrials).newName = f_newFilename(trials_infos(numberTrials));
                txtToEdit = [[Path_enf,'\',trialName],...
                    '   ',trials_infos(numberTrials).Processed];
                for nbKin=1:size(trials_infos(numberTrials).kinetic,1)
                    txtToEdit = [txtToEdit,'   ',...
                        trials_infos(numberTrials).kinetic{nbKin,1},'   ',...
                        trials_infos(numberTrials).kinetic{nbKin,2}];
                end
                disp(txtToEdit);
                numberTrials = numberTrials + 1;
            end % if trial is processed

        end % ~isemtpy(text_enf)
        clearvars text_enf
    end % for index_enfFiles = 1:length(list_enfFiles)

end % end of function


