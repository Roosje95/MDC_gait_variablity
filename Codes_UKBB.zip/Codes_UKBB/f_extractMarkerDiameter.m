%{
*********************************************************************************
           Function "f_extractMarkerDiameter" linked to 
script "Auswertung_mitFormularen" & "Datenarchivierung_footmodel"
                     by Katrin Schweizer Dez. 2014
*********************************************************************************

Extracts infos on marker diameter from the vsk-file to write to c3d later on.
                                    
INPUT
    Path_vsk = Path to the vsk-file of the current patient
    out = 1 if all ok, 0 if there is a problem to open vsk file (main 
    script will be stopped)

OUTPUT
    MarkerDiameter4_c3d = cell including the names of the marker (1. column)
                         and the marker diameter (2. column)
%}

function [out,MarkerDiameter4_c3d] = f_extractMarkerDiameter(Path_vsk)

    out = 1;
    try
        vsk = importdata(Path_vsk); % open vsk-file  
    catch
        out = 0;
        MarkerDiameter4_c3d = 0;
        disp(' ');
        disp('!!! error in f_extractMarkerDiameter: !!!');
        disp(['!!! vsk file ' Path_vsk ' couldn''t be find !!!']);
        return
    end
    
    MarkerVSK = ~cellfun('isempty',strfind(vsk,'Marker')); %Find word 'Marker' in vsk
    MarkerVSK(:,2) = ~cellfun('isempty',strfind(vsk,' NAME=')); %Find word ' NAME=' in vsk
    MarkersName = all(MarkerVSK,2); %Lines where both 'Marker' & ' NAME=' are
    
    vsk(MarkersName==0,:) = []; % Delete irrelevant lines

    for i = 1:size(vsk,1)

            SingleWords = strsplit(vsk{i,1},'"'); %split words between "

            LocName = find(strcmp('			<Marker NAME=',SingleWords)); %Locate ' NAME='
%             LocName = find(strcmp(' NAME=',SingleWords)); %Locate ' NAME='
            
            LocRadius = find(strcmp(' RADIUS=',SingleWords)); %Locate ' RADIUS='
            
            MarkerDiameter4_c3d{i,1} = SingleWords{:,LocName+1}; %Marker name
            MarkerDiameter4_c3d{i,2} = SingleWords{:,LocRadius+1}; %Marker diameter
            
    end %FOR i = 1:size(vsk,1)
  
end %FUNCTION