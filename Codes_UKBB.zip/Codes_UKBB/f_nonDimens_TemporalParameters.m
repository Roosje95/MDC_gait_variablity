%{
*********************************************************************************
 Function "f_nonDimens_TemporalParameters" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer June 2014
*********************************************************************************

Transforms the gait parameters to non-dimensional values according to Hof 1996.
The "foot off/contact" is keept in %. 
                                     
INPUT
     GaitParam = Struct with gait parameters of the current patient
     dataStruct = Gait parameters of patient
     LegLength = The leg length of the current patient in millimeters

OUTPUT
    GaitParam_ND = Struct with dimensionless gait parameters of the current patient
%}


function GaitParam_ND = f_nonDimens_TemporalParameters(GaitParam,LegLength_left,LegLength_right)

   % Transfer leg length from mm to m     
%    LegLength_left = str2double(LegLength_left)/1000;
%    LegLength_right = str2double(LegLength_right)/1000; 
   LegLength_left = LegLength_left/1000;
   LegLength_right = LegLength_right/1000; 

   
 %% norm gait parameter according to Hof 1996 (non-dimensionale)

   g = 9.81; %m/s2 Erdbeschleunigung
   
  % cadence (was in steps/min) --> /60 to transfer to seconds than
   GaitParam_ND.Cadence.Left = GaitParam.Cadence.Left/60*sqrt(LegLength_left/g);
   GaitParam_ND.Cadence.Right = GaitParam.Cadence.Right/60*sqrt(LegLength_right/g);
   
  % speed (was in m/s)      
   GaitParam_ND.Walking_Speed.Left = GaitParam.Walking_Speed.Left/sqrt(LegLength_left*g);
   GaitParam_ND.Walking_Speed.Right = GaitParam.Walking_Speed.Right/sqrt(LegLength_right*g);
   
  % time (was in seconds)    
   GaitParam_ND.Stride_Time.Left = GaitParam.Stride_Time.Left/sqrt(LegLength_left/g);
   GaitParam_ND.Step_Time.Left = GaitParam.Step_Time.Left/sqrt(LegLength_left/g);
   GaitParam_ND.Stride_Time.Right = GaitParam.Stride_Time.Right/sqrt(LegLength_right/g);
   GaitParam_ND.Step_Time.Right = GaitParam.Step_Time.Right/sqrt(LegLength_right/g);
   
  % Foot off and foot contact keep in %
   GaitParam_ND.Opposite_Foot_Off.Left = GaitParam.Opposite_Foot_Off.Left;
   GaitParam_ND.Opposite_Foot_Off.Right = GaitParam.Opposite_Foot_Off.Right; 
   GaitParam_ND.Opposite_Foot_Contact.Left = GaitParam.Opposite_Foot_Contact.Left;
   GaitParam_ND.Opposite_Foot_Contact.Right = GaitParam.Opposite_Foot_Contact.Right;
   GaitParam_ND.Foot_Off.Left = GaitParam.Foot_Off.Left;
   GaitParam_ND.Foot_Off.Right = GaitParam.Foot_Off.Right;
   
  % Singel and double support time (was in seconds)    
   GaitParam_ND.Single_Support.Left = GaitParam.Single_Support.Left/sqrt(LegLength_left/g);
   GaitParam_ND.Single_Support.Right = GaitParam.Single_Support.Right/sqrt(LegLength_right/g);
   GaitParam_ND.Double_Support.Left = GaitParam.Double_Support.Left/sqrt(LegLength_left/g);
   GaitParam_ND.Double_Support.Right = GaitParam.Double_Support.Right/sqrt(LegLength_right/g);  
 
   % length (was in metres) 
   GaitParam_ND.Stride_Length.Left = GaitParam.Stride_Length.Left/LegLength_left;
   GaitParam_ND.Step_Length.Left = GaitParam.Step_Length.Left/LegLength_left;
   GaitParam_ND.Stride_Width.Left = GaitParam.Stride_Width.Left/LegLength_left;
   GaitParam_ND.Stride_Length.Right = GaitParam.Stride_Length.Right/LegLength_right;
   GaitParam_ND.Step_Length.Right = GaitParam.Step_Length.Right/LegLength_right;
   GaitParam_ND.Stride_Width.Right = GaitParam.Stride_Width.Right/LegLength_right;
   
end %FUNCTION