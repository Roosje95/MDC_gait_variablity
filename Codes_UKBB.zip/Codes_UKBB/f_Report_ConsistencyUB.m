%{ 
*********************************************************************************
  Function "f_Report_ConsistencyUB" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer Dez. 2013
*********************************************************************************

Plots the upper body kinematic data for the report.
Plots the control group in a grey band, all trials of the left side of the patients in a
continous line, the right side in a dashed line. It also plots the foot-off
of the patients in horizontal line.
The plots are scared to 0-100% of a gait cycle on the x-achsis and 
to +/- 1% above/below the maximum/minimum of the data

INPUT
  PA_data = Data of patients from struct (e.g. "DataForCalc.PIGnormalised_101.Angle")
  Title = Titel for plot (e.g. "Consistency plots Joint rotation angles - Upper body")
  CG_RangeLB = Lower bound of control goup data
  CG_RangeUB = Upper bound of control goup data
  Subtitle = Titles for subplots (e.g. "Thorax tilt")
  name_Y = Names for Y-Axis (e.g. "post  degrees  ant")
  DataName = Names of fields to get the data (e.g. "Angle,Sagittal,Spine")
  rows_subplot = number of lines for subplots
  columnSubplot = number of columns for subplots
  YLim = the standard y-axis-limits (e.g. [-10 10]
  XTICK = [1 21 41 61 81 101]
  XTICKLABEL = {'0','20','40','60','80','100'}
  Color_band = Color for band of controls
  FootOff_Left = Left foot off for patients
  FootOff_Right = Right foot off for patients
  Color_Left = Color for the left side of the patient data (red)
  Color_Right = Color for the right side (blue)
  LineWidth_side1 = Line width for the left side of the patient data
  LineWidth_side2 = Line width for the right side of the patient data

OUTPUT
  PageNum = new actual page number for report
%}

function PageNum = f_Report_ConsistencyUB(PA_data,Title,CG_RangeLB,...
                                          CG_RangeUB,Subtitle,name_Y,DataName,rows_subplot,...
                                          columnSubplot,YLim,XTICK,XTICKLABEL,...
                                          Color_band,FootOff_Left,...
                                          FootOff_Right,Color_Left,Color_Right,...
                                          LineWidth_side1,LineWidth_side2,PageNum)                          

   Data_NaN = NaN;  

   
%**************************************************************************   
  %% Left side
%**************************************************************************

   % Set general figure parameter
   Fig_left = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                    'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                    'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]

   annotation(Fig_left,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
              'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
              'VerticalAlignment','middle','LineStyle','none');
   annotation(Fig_left,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
              'FontSize',11,'FitBoxToText','off','LineStyle','none',...
              'VerticalAlignment','middle','HorizontalAlignment','right');
   annotation(Fig_left,'textbox',[0.06 0.935 0.09 0.04],'String','Left',...
              'Color','r','FontSize',11,'LineStyle','none','FontWeight','bold');          

       
  % Across all data that should be plotted
   for i = 1:size(DataName,1)
          
       % Vector for patient data
       PA_Left = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Left;
       
       % Vector for control group data range (LB = lower bound, UB = upper bound)
       CG_LB = CG_RangeLB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
       CG_UB = CG_RangeUB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
       
       % for the last three subplots X-Achsis lable is "Gait cycle"
       if i > size(DataName,1)-3
           name_X = '% gait cycle';
         else
           name_X = '';
       end %i > size(DataName,1)-3
       
       figure(Fig_left)
       subplot(rows_subplot,columnSubplot,i)
          
       % apply "f_plotData" to plot each subplot
       f_plotData(CG_LB,CG_UB,PA_Left,Data_NaN,Subtitle{i,1},name_Y{i,1},name_X,...
                  Color_band,YLim(i,:),XTICK,XTICKLABEL,FootOff_Left,FootOff_Right,...
                  Color_Left,Color_Right,LineWidth_side1,LineWidth_side2)                    

   end %FOR i = 1:12
   
   
  %% Page Number
   f_makeTextbox(Fig_left,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
   PageNum = PageNum + 1;

   
   
%**************************************************************************   
  %% Right side
%**************************************************************************

   % Set general figure parameter 
   Fig_right = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                     'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                     'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]

   annotation(Fig_right,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
              'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
              'VerticalAlignment','middle','LineStyle','none');
   annotation(Fig_right,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
              'FontSize',11,'FitBoxToText','off','LineStyle','none',...
              'VerticalAlignment','middle','HorizontalAlignment','right');
   annotation(Fig_right,'textbox',[0.06 0.935 0.09 0.04],'String','Right',...
              'Color','b','FontSize',11,'LineStyle','none','FontWeight','bold');
          
  % Across all data that should be plotted
   for i = 1:size(DataName,1)
          
       % Vector for patient data
       PA_Right = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Right;
          
       % Vector for control group data range (LB = lower bound, UB = upper bound)
       CG_LB = CG_RangeLB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
       CG_UB = CG_RangeUB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
       
       % for the last three subplots X-Achsis lable is Gait cycle
       if i > size(DataName,1)-3
           name_X = '% gait cycle';
         else
           name_X = '';
       end %i > size(DataName,1)-3 
       
       figure(Fig_right)
       subplot(rows_subplot,columnSubplot,i)
          
       % apply "f_plotDat"a to plot each subplot
       f_plotData(CG_LB,CG_UB,Data_NaN,PA_Right,Subtitle{i,1},name_Y{i,1},name_X,...
                  Color_band,YLim(i,:),XTICK,XTICKLABEL,FootOff_Left,FootOff_Right,...
                  Color_Left,Color_Right,LineWidth_side1,LineWidth_side2)
              
   end %FOR i = 1:12

   
  %% Page Number
   f_makeTextbox(Fig_right,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
   PageNum = PageNum + 1;
 
   
   
%**************************************************************************   
  %% Both sides in one plot
%**************************************************************************
 
   % Set general figure parameter              
   Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]

   annotation(Fig,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
              'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
              'VerticalAlignment','middle','LineStyle','none');
   annotation(Fig,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
              'FontSize',11,'FitBoxToText','off','LineStyle','none',...
              'VerticalAlignment','middle','HorizontalAlignment','right');
   annotation(Fig,'textbox',[0.06 0.927 0.09 0.04],'String','-- Left',...
              'Color','r','FontSize',11,...
              'LineStyle','none','FontWeight','bold');
   annotation(Fig,'textbox',[0.125 0.927 0.09 0.04],'String','- - Right',...
              'Color','b','FontSize',11,...
              'LineStyle','none','FontWeight','bold');

  % Across all data that should be plotted
   for i = 1:size(DataName,1)
          
       % Vector for patient data
       PA_Left = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Left;
       PA_Right = PA_data.(DataName{i,1}).(DataName{i,2}).(DataName{i,3}).Right;
          
       % Vector for control group data range (LB = lower bound, UB = upper bound)
       CG_LB = CG_RangeLB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
       CG_UB = CG_RangeUB.(DataName{i,1}).(DataName{i,2}).(DataName{i,3});
       
       % for the last three subplots X-Achsis lable is Gait cycle
       if i > size(DataName,1)-3
           name_X = '% gait cycle';
         else
           name_X = '';
       end %i > size(DataName,1)-3  
       
       figure(Fig)
       subplot(rows_subplot,columnSubplot,i)
          
       % apply "f_plotData" to plot each subplot
       f_plotData(CG_LB,CG_UB,PA_Left,PA_Right,Subtitle{i,1},name_Y{i,1},name_X,...
                  Color_band,YLim(i,:),XTICK,XTICKLABEL,FootOff_Left,FootOff_Right,...
                  Color_Left,Color_Right,LineWidth_side1,LineWidth_side2)
   end %FOR i = 1:12 
   

  %% Page Number
   f_makeTextbox(Fig,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
   PageNum = PageNum + 1;
 
   
end %FUNCTION

