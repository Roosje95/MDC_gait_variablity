function [out,list_GCs_selected,Kinetic_4orMore] = f_checkGaitCycles_FootKin(list_GC)
%{
by M. Freslier, Mar. 2018

through a list of trials, where the gait cycles were already analysed and
their type determined (side, which forceplate, step number), the function
define which gait cycles will be used for the analysis.
Typical case for Footkin: 5 trials L&R and if possible from forceplate 1:
- goal is 5 gait cycles for left&right from 4th and 5th steps on the
forceplate 1
- otherwise others gait cycles from 3rd and more than 6th steps and/or from
other forceplates are taken.
- if the step numbers are unknown, the steps are taken first from 
forceplate 1

INPUT
    list_c3d: a struct with the trials informations (filename and a cell array with the
    gait cycles: {x,2} = side, {x,3} = forceplate, {x,4} = a struct with
    the events (FS ipsi&contra, FO ipsi&contra),{x,5} = step number (from 1st step =0 if
    undetermined), {x,6} = trial number, {x,7} = step number (from 1st gait
    cycle defined), {x,8} = is emg recorded? 'y' or 'n'
OUTPUT
    out = 1 if all ok, 0 if there is a problem to determine the
    informations
    list_GCs_selected = a list of the selected gait cycles
        {x,1} = filename of the c3d
        {x,2} = side
        {x,3} = forceplate
        {x,4} = struct with the events (FS ipsi&contra, FO ipsi&contra)
        {x,5} = step number, obtained from the definition of the 4th
                step, 0 if undetermined
        {x,6} = trial number (obtained from the c3d name)
        {x,7} = step number, obtained from the 1st gait cycle defined
                in the trial, -1 if impossible to determine
        {x,8} = is emg recorded? 'y' or 'n'
    Kinetic_4orMore = 1 if there is anough kinetics (>= 4x), else =0
%}
out = 1;

if isempty(list_GC)
    out = 0;
    disp('!!! error in f_checkGaitCycles.m: !!!');
    disp('!!! the list of gait cycles is empty !!!');
    list_GCs_selected = {};
    Kinetic_4orMore = 0;
    return
else nb_colomn = size(list_GC,2);
end

nb_le = 0;
nb_ri = 0;
index_fp1_R_45 = 0;
index_fp1_L_45 = 0;
index_fp1_R_others = 0;
index_fp1_L_others = 0;
index_fp_R_45 = 0;
index_fp_L_45 = 0;
index_fp_R_others = 0;
index_fp_L_others = 0;
list_fp1_R_45 = cell(1,nb_colomn);
list_fp1_L_45 = cell(1,nb_colomn);
list_fp1_R_others = cell(1,nb_colomn);
list_fp1_L_others = cell(1,nb_colomn);
list_fp_R_45 = cell(1,nb_colomn);
list_fp_L_45 = cell(1,nb_colomn);
list_fp_R_others = cell(1,nb_colomn);
list_fp_L_others = cell(1,nb_colomn);

for GC=1:size(list_GC,1)
    switch list_GC{GC,3}
        case 'FP0'
            disp('!!! error in f_checkGaitCycles.m: !!!');
            disp(['!!! the trial ' list_GC{GC,1} ' hasn''t any kinetic !!!']);
        case 'FP1'
            switch list_GC{GC,5} % step number
                case {4,5}
                    switch list_GC{GC,2} % side
                        case 'right'
                            nb_ri = nb_ri + 1;
                            index_fp1_R_45 = index_fp1_R_45 + 1;
                            list_fp1_R_45(index_fp1_R_45,:) = list_GC(GC,:);
                        case 'left'
                            nb_le = nb_le + 1;
                            index_fp1_L_45 = index_fp1_L_45 + 1;
                            list_fp1_L_45(index_fp1_L_45,:) = list_GC(GC,:);
                    end
                case 0
                    switch list_GC{GC,2} % side
                        case 'right'
                            nb_ri = nb_ri + 1;
                            index_fp1_R_others = index_fp1_R_others + 1;
                            list_fp1_R_others(index_fp1_R_others,:) = list_GC(GC,:);
                        case 'left'
                            nb_le = nb_le + 1;
                            index_fp1_L_others = index_fp1_L_others + 1;
                            list_fp1_L_others(index_fp1_L_others,:) = list_GC(GC,:);
                    end
                case {1,2}
                    % do nothing: the gait cycle is too small
                otherwise % =3 or >= 6
                    switch list_GC{GC,2} % side
                        case 'right'
                            nb_ri = nb_ri + 1;
                            index_fp1_R_others = index_fp1_R_others + 1;
                            list_fp1_R_others(index_fp1_R_others,:) = list_GC(GC,:);
                        case 'left'
                            nb_le = nb_le + 1;
                            index_fp1_L_others = index_fp1_L_others + 1;
                            list_fp1_L_others(index_fp1_L_others,:) = list_GC(GC,:);
                    end
            end % switch step number
        otherwise % FP2, FP3 or FP4
            switch list_GC{GC,5} % step number
                case {4,5}
                    switch list_GC{GC,2} % side
                        case 'right'
                            nb_ri = nb_ri + 1;
                            index_fp_R_45 = index_fp_R_45 + 1;
                            list_fp_R_45(index_fp_R_45,:) = list_GC(GC,:);
                        case 'left'
                            nb_le = nb_le + 1;
                            index_fp_L_45 = index_fp_L_45 + 1;
                            list_fp_L_45(index_fp_L_45,:) = list_GC(GC,:);
                    end
                case 0
                    switch list_GC{GC,2} % side
                        case 'right'
                            nb_ri = nb_ri + 1;
                            index_fp_R_others = index_fp_R_others + 1;
                            list_fp_R_others(index_fp_R_others,:) = list_GC(GC,:);
                        case 'left'
                            nb_le = nb_le + 1;
                            index_fp_L_others = index_fp_L_others + 1;
                            list_fp_L_others(index_fp_L_others,:) = list_GC(GC,:);
                    end
                case {1,2}
                    % do nothing: the gait cycle is too small
                otherwise % =3 or >= 6
                    switch list_GC{GC,2} % side
                        case 'right'
                            nb_ri = nb_ri + 1;
                            index_fp_R_others = index_fp_R_others + 1;
                            list_fp_R_others(index_fp_R_others,:) = list_GC(GC,:);
                        case 'left'
                            nb_le = nb_le + 1;
                            index_fp_L_others = index_fp_L_others + 1;
                            list_fp_L_others(index_fp_L_others,:) = list_GC(GC,:);
                    end
            end % switch step number
    end % switch list_GC{GC,3}
end % for GC=1:size(list_GC,1)

list_L = {};
if index_fp1_L_45 % ~= 0
    list_L = list_fp1_L_45;
end
if index_fp1_L_others % ~= 0
    list_L = [list_L ; list_fp1_L_others];
end
if index_fp_L_45 % ~= 0
    list_L = [list_L ; list_fp_L_45];
end
if index_fp_L_others % ~= 0
    list_L = [list_L ; list_fp_L_others];
end

list_R = {};
if index_fp1_R_45 % ~= 0
    list_R = list_fp1_R_45;
end
if index_fp1_R_others % ~= 0
    list_R = [list_R ; list_fp1_R_others];
end
if index_fp_R_45 % ~= 0
    list_R = [list_R ; list_fp_R_45];
end
if index_fp_R_others % ~= 0
    list_R = [list_R ; list_fp_R_others];
end

if size(list_L,1)>=4 && size(list_R,1)>=4
    Kinetic_4orMore = 1;
    n_L = min(5,size(list_L,1));
    n_R = min(5,size(list_R,1));
    list_GCs_selected = [list_L(1:n_L,:) ; list_R(1:n_R,:)];
else
    out = 0;
    disp('!!! error in f_checkGaitCycles_FootKin.m: !!!');
    disp('!!! there isn''t enough gait cycles !!!');
    list_GCs_selected = {};
    Kinetic_4orMore = 0;
    return
end
    