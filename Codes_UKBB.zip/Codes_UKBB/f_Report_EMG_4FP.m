%{ 
*********************************************************************************
      Function "f_Report_EMG" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer March 2014
*********************************************************************************

Prepares the data to plot the EMG report.
Plots the control group in grey rectangles, the raw EMG left side of the patients in 
the first two rows, the right side row 3-4. It also plots the foot-off
of the patients in horizontal line, dashed for the right side.
The plots are scared to 0-100% of a gait cycle on the x-achsis and 
to +/- 1% above/below the maximum/minimum of the data

INPUT
  PA_side1 = Data of patients from struct (e.g. "DataForCalc.PIGnormalised_101.Angle")
  PA_side1 = Data of patients from struct (e.g. "DataForCalc.PIGnormalised_101.Angle")
  Title = Titel for plot (e.g. "Rep. trial: Electromyographic Activity (20?700Hz bandpass)")
  CG_EMG = Struct with timing of "healthy" muscles derived by Polygon
  Subtitle = Titles for subplots (e.g. "Spine tilt")
  name_Y = Names for Y-Axis (e.g. "[mVolt]")
  DataName = Names of fields to get the data (e.g. "Angle,Sagittal,Spine")
  lines = number of lines for subplots
  Color_band = Color for band of controls
  TrialStr = Cell with name of trial that are plotted {'L4',R5'}
  PageNum = actual page number for report

OUTPUT
  PageNum = new actual page number for report
%}

function PageNum = f_Report_EMG_4FP(PA_side1,PA_side2,Title,CG_EMG,Subtitle,name_Y,...
                                DataName,lines,Color_band,TrialStr,PageNum)                          

                            
   DataGood_L = sum(~isnan(PA_side1.EMG.InVolt.(DataName{1,1}).Left));
   DataGood_R = sum(~isnan(PA_side2.EMG.InVolt.(DataName{1,1}).Right));
   
   Freq = PA_side1.Frequency.Analog.Hertz.Dummy;
         
   firstFrame_1 = PA_side1.FirstFrame.Analog.Dummy.Dummy;
   firstFrame_2 = PA_side2.FirstFrame.Analog.Dummy.Dummy;
   
   FootOff_1 = PA_side1.GaitParam.Dummy.Foot_Off.Left; %Foot off left in %
   FootOff_2 = PA_side2.GaitParam.Dummy.Foot_Off.Right; %Foot off right in %
   
   
   %if there are data either for the left or the right side  
   if DataGood_L >= 1 || DataGood_R >= 1 
 
       
      %% set general figure parameters
      
      Fig = figure('PaperSize',[20.98 29.68],'Units','centimeters',...
                       'Position', [18,0,20.98,29.68],'PaperPositionMode','manual',...
                       'PaperPosition', [0.5,1,20.48,27.68]);%[linker Seitenrand, unterer Seitenrand,Breite, H�he]
      TrialStr = strrep(TrialStr, '_', '.');
      
      annotation(Fig,'textbox',[0.05 0.97 0.805 0.05],'String',Title{1,1},...
                 'FontWeight','bold','FontSize',14,'FitBoxToText','off',...
                 'VerticalAlignment','middle','LineStyle','none');
      annotation(Fig,'textbox',[0.805 0.97 0.144 0.05],'String',Title{1,2},...
                 'FontSize',11,'FitBoxToText','off','LineStyle','none',...
                 'VerticalAlignment','middle','HorizontalAlignment','right');
      TrialSplit = strsplit(TrialStr{1,1},'.');
      annotation(Fig,'textbox',[0.06 0.93 0.09 0.04],'String',{[TrialSplit{1,1} '.' TrialSplit{1,3} '.' TrialSplit{1,4}],'Left'},...
              'Color','r','FontSize',11,...
              'LineStyle','none','FontWeight','bold');
      TrialSplit = strsplit(TrialStr{1,2},'.');
      annotation(Fig,'textbox',[0.06 0.49 0.09 0.04],'String',{[TrialSplit{1,1} '.' TrialSplit{1,3} '.' TrialSplit{1,4}],'Right'},...
              'Color','b','FontSize',11,...
              'LineStyle','none','FontWeight','bold');

      % For all relevant muscles    
      for i = 1:size(DataName,1)
          
          PA_Left = PA_side1.EMG.InVolt.(DataName{i,1}).Left;
          PA_Right = PA_side2.EMG.InVolt.(DataName{i,1}).Right;
          
          CG_Muscle = CG_EMG.EMG.InVolt.(DataName{i,1}).X;


          %% Cut EMG data to gait cycle "f_extractGaitCycle"

   
          FootStrike_left = PA_side1.Events_currentGC.InSeconds.FootStrike.dummy;
          PA_Left_cut = f_extractGaitCycle(PA_Left,FootStrike_left,Freq,firstFrame_1);
          
          FootStrike_right = PA_side2.Events_currentGC.InSeconds.FootStrike.dummy;
          PA_Right_cut = f_extractGaitCycle(PA_Right,FootStrike_right,Freq,firstFrame_2);          

          
%**************************************************************************      
          %% Plot left side "f_plotEMG"
%**************************************************************************            

          figure(Fig)
          subplot(lines,ceil(length(DataName)/2),i)
          
          Color_side1 = 'r';          

          FootOff_left = round(FootOff_1 * (length(PA_Left_cut)-1) / 100) +1; % Frame of Foot-off 
       
          f_plotEMG(PA_Left_cut,CG_Muscle,Subtitle{i,1},name_Y{i,1},...
                    Color_band,FootOff_left,Color_side1)
          

%**************************************************************************                
          %% Plot right side "f_plotEMG"
%**************************************************************************

          % if a even number of muscels was measured
          if ~mod(size(DataName,1),2)     
             subplot(lines,ceil(length(DataName)/2),i+length(DataName))
          else subplot(lines,ceil(length(DataName)/2),i+length(DataName)+1)
          end
          
          Color_side2 = 'b';

          FootOff_right = round(FootOff_2 * (length(PA_Right_cut)-1) / 100) +1; % Frame of Foot-off 
                    
          f_plotEMG(PA_Right_cut,CG_Muscle,Subtitle{i,1},name_Y{i,1},...
                    Color_band,FootOff_right,Color_side2)
           
       end %FOR i = 1:size(DataName,1)
       
       
       %% Make legend 
       
       annotation(Fig,'textbox',[0.386 0.0348 0.36 0.044],'FitBoxToText','on','String',...
                  {'Muscle active in healthy subjects'},'FontSize',11,...
                  'LineStyle','none'); %Text
       annotation(Fig, 'textbox',[0.35 0.06 0.043 0.02],'String',{'    '},...
                  'BackgroundColor',Color_band,'LineStyle','none'); %rectangle 

              
       %% Page Number "f_makeTextbox"
       
       f_makeTextbox(Fig,['- ',num2str(PageNum),' -'],0.849,0.001,0.10,0.0,7,'none','right')
       PageNum = PageNum + 1;
      
    end %IF DataGood_L >= 1 || DataGood_R >= 1 

end %FUNCTION