%{
********************************************************************************* 
 Function "f_copy_PressureFiles" linked to script "Auswertung_ChiBa15b"
                    by Katrin Schweizer Feb. 2015
*********************************************************************************

Copies the lst-files and the lin-file from NOVEL (plantar pressure) to end-server "L" and the
files with 1-5.lst and auswert.lin

INPUT: Path_Patientfolder = Path to data on "K"
       Path_Patientfolder_new = Path to data on "L"
       side = 'Links' or 'Right'

%}
function f_copy_PressureFiles(Path_Patientfolder,Path_Patientfolder_new,side)

    %Search for .lin-files and copy them
    lin = dir([Path_Patientfolder,'\' side '\*.lin']);
    
    if ~isempty(lin) %if a lin file exists, copy it
    copyfile([Path_Patientfolder,'\' side '\',lin.name],[Path_Patientfolder_new,'\' side '\','auswert.lin']);
    end
    
    %Search for .lst-files and copy them 
    lst = dir([Path_Patientfolder,'\' side '\*.lst']); 
    lst_cell = struct2cell(lst); % change struct to cell to run regexprep later on

    for i = 1:size(lst,1)
        copyfile([Path_Patientfolder,'\' side '\',lst_cell{1,i}],[Path_Patientfolder_new,'\' side '\',num2str(i),'.lst']);
    end %FOR i = 1:5

end %FUNCTION