%{ 
*********************************************************************************
            Function "f_plotData" linked to script "Auswertung_mitFormularen"
                     by Katrin Schweizer Dez. 2013
*********************************************************************************

Plots the control group in a grey band, the left side of the patients in a
continous line, the right side in a dashed line. It also plots the foot-off
of the patients in vertical line.
The plots are scaled to 0-100% of a gait cycle on the x-axis and 
to +/- 1% above/below the maximum/minimum of the data

INPUT
   RangeLB = lower bound of the band (e.g. mean-1 standard deviation)
   oneRange = Range of the data (e.g. one standard deviation / 1 confidence interval)
   PA_side1 = patient data left side (left side, continous line) 
   PA_side2 = patient data second side (right side, dashed line)
   name_plot = title for sublot (e.g. 'knee angle')
   Yaxis = lable for y-achsis (e.g. {'Ext          Flex'};)
   Xaxis = lable for x-achsis (for last row "% gait cycle")
   COLOR = color band
   YLim = the standard y-axis-limits (e.g. [-10 10]
   XTICK = ticks for x-axis (e.g. [1 21 41 61 81 101])
   XTICKLABEL = lables for x-axis (e.g. {'0','20','40','60','80','100'};)
   FootOff_1 = time of foot-off of the left side (side 1)
   FootOff_2 = time of foot-off of the right side (side 2)

%}

function f_plotData(RangeLB,oneRange,PA_side1,PA_side2,titlePlot,Yaxis,Xaxis,...
                    Color_band,YLim,XTICK,XTICKLABEL,FootOff_1,FootOff_2,...
                    Color_side1,Color_side2,LineWidth_side1,LineWidth_side2)

                
    %% plot control group band
    
    Band = RangeLB;
    Band(:,2) = 2*oneRange; % e.g. 2 SD above the lower Range

    hold all
    area1 = area([1:size(Band,1)]',Band,'LineStyle','non','Visible','off');
    set(area1(1),'FaceColor',[1 1 1],'Visible','off');
    set(area1(2),'LineStyle','none','FaceColor',Color_band,'Visible','on'); 
%     alpha(0.5) %macht transparent!
    
    % Exclude control band from legend
    set(get(get(area1(1),'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    set(get(get(area1(2),'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    
    %% to set y-limits

    % if first side is NaN
    if sum(~isnan(PA_side1(1,:))) == 0 && sum(~isnan(PA_side2(1,:))) ~= 0 
       AllData = cat(2,Band(:,1),Band(:,1)+Band(:,2),PA_side2); 
       
    elseif sum(~isnan(PA_side2(1,:))) == 0 && sum(~isnan(PA_side1(1,:))) ~= 0
       AllData = cat(2,Band(:,1),Band(:,1)+Band(:,2),PA_side1); 
       
    elseif sum(~isnan(PA_side1(1,:))) ~= 0 && sum(~isnan(PA_side2(1,:))) ~= 0 
       AllData = cat(2,Band(:,1),Band(:,1)+Band(:,2),PA_side1,PA_side2);
       
    else AllData = 1;
        
    end %IF isnan(PA_side1(1,1))
    
    Min = min(min(AllData,[],1),[],2);
    Max = max(max(AllData,[],1),[],2);

    if Min < 1 || Max < 1
       Percent = (Max*10 - Min*10) * 0.01; 
       MinPlot = floor(Min*10-Percent*10)/10;
       MaxPlot = ceil(Max*10+Percent*10)/10;
    else Percent = (Max-Min)*0.01; 
         MinPlot = floor(Min-Percent);
         MaxPlot = ceil(Max+Percent);
    end
    
         
    % Define Y-Limits
    if YLim(1,1) < Min %if the lower standard y-lim is smaller than the data to plot
       MinPlot = YLim(1,1); %use the standard y-limits      
    else %else use the data adapted y-limits and plot a line where the standard y-lim would have been
       Line1 = plot(1:100,repmat(YLim(1,1),1,100),'Color',[0.8 0.8 0.8],'LineStyle',':');
       set(get(get(Line1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    end %IF YLim(1,1) < MinPlot
 
    if YLim(1,2) > Max %if the upper standard y-lim is bigger than the data to plot
       MaxPlot = YLim(1,2); %use the standard y-limits      
    else %else use the data adapted y-limits and plot a line where the standard y-lim would have been
       Line1 = plot(1:100,repmat(YLim(1,2),1,100),'Color',[0.8 0.8 0.8],'LineStyle',':');
       set(get(get(Line1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
    end %IF YLim(1,1) < MinPlot
    
    Y = MinPlot:0.1:MaxPlot;

    %% plot patients first side (left, continous line)

     
     if sum(~isnan(PA_side1(1,:))) >= 1%~isnan(PA_side1(1,1))
        
       for i = 1:size(PA_side1,2)
           
            if ~isnan(PA_side1(1,i)) >= 1 %if the data are not NaN
              plot(PA_side1(:,i),'Color',Color_side1(i-floor((i-1)/12)*12,:),'LineWidth',LineWidth_side1(i,1));
              FootOffLine_1 = plot(repmat(FootOff_1(1,i),size(Y)),Y,'Color',Color_side1(i-floor((i-1)/12)*12,:),'LineWidth',1); %plot foot-off            
              set(get(get(FootOffLine_1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off'); % Exclude foot-off line from legend     
             else %if the data are NaN exlude the trial from being displayed in the legend
               Data1 = plot(NaN,'Color',Color_side1(i-floor((i-1)/12)*12,:),'LineWidth',1.5);
               set(get(get(Data1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off'); % Exclude line from legend               
            end %IF ~isnan(PA_side1(1,i)) >= 1
           
        end %FOR i = 1:size(PA_side1,2)
    
     end
     
     
     %% plot patients second side (right, dashed line)
     if sum(~isnan(PA_side2(1,:))) >= 1%~isnan(PA_side2(1,1))
        
       for i = 1:size(PA_side2,2) 
           
            if ~isnan(PA_side2(1,i)) >= 1 %if the data are not NaN             
              plot(PA_side2(:,i),'Color',Color_side2(i-floor((i-1)/12)*12,:),'LineWidth',LineWidth_side2(i,1),'LineStyle','--');
              FootOffLine_2 = plot(repmat(FootOff_2(1,i),size(Y)),Y,'Color',Color_side2(i-floor((i-1)/12)*12,:),'LineStyle','--','LineWidth',1); %plot foot-off        
              set(get(get(FootOffLine_2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off'); % Exclude foot-off line from legend
            else %if the data are NaN exlude the trial from being displayed in the legend
               Data2 = plot(NaN,'Color',Color_side2(i-floor((i-1)/12)*12,:),'LineWidth',1.5,'LineStyle','--');
               set(get(get(Data2,'Annotation'),'LegendInformation'),'IconDisplayStyle','off'); % Exclude line from legend               
            end %IF ~isnan(PA_side1(1,i)) >= 1         
           
        end %FOR i = 1:size(PA_side2,2)
       
     end %IF ~isnan(PA_side1(1,1))
        
       
  
    %% Set general figure parameter
    set(gca,'XTickLabel',XTICKLABEL,'XTick',XTICK,'FontSize',9);
    title(titlePlot,'FontWeight','demi','FontSize',11);
    ylabel(Yaxis,'LineWidth',0.1,'FontSize',9);
    xlabel(Xaxis,'LineWidth',0.1,'FontSize',9);
    
    ZeroLine = plot(zeros(size(Band,1),1)','Color','k','LineWidth',1); % plot zero line  

    % Exclude zero line from legend
    set(get(get(ZeroLine,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');

    % Set limits for X- & Y-axis
    xlim([1 size(Band,1)])        
    ylim([MinPlot MaxPlot]) %y-limit is min-1% and max+1%

    % Draw box around each subplot
    box on
    set(gca, 'Layer','top') % draw box on top    
 
end % FUNCTION

