function [out,c3d_infos] = f_copyCheck_c3dFiles(path_origin,path_new,subject)
%{
by M. Freslier, July. 2017

Function to copy the c3d files which were analysed: static, trials without
kinetics only copied; trials with kinetics copied and adapted (K... files:
check if the general events (FS and FO for 4th step) have descriptions, 
B,L&R... files: general events are included to define the gait cycles with 
good kinetics -> done in f_defineGaitCycles_generalCase()):
A struct give the informations about the type of the files.

INPUT
    Path_Origin = path where the data are stored
    Path_new = path where the data will be copied (temporary folder)

OUTPUT
    out = 1 if all ok, 0 if there is a problem ...
    c3d_infos = struct with informations about the files
        .filename = the new filename of the copied c3d
        .Processed = the type of the file (i.e. static, NoKinetics or
        Kinetics)
%}
    out = 1;
    
    list_c3dFiles = dir([path_origin,'\*.c3d']);
    
    for a = 1:length(list_c3dFiles)
       
        if length(list_c3dFiles(a).name)<8
            c3d_rename = split(list_c3dFiles(a,1).name,'.');
            
            d=c3d_rename(1);
            e=split(d,'');
            if ismember(e(2),'R')
                c3d_rename_prep = [c3d_rename(1),'_',subject];
            elseif ismember(e(2),'L')
                c3d_rename_prep = [c3d_rename(1),'_',subject];
            elseif ismember(e(2),'N')
                c3d_rename_prep = [c3d_rename(1),'_',subject];
            elseif ismember(e(2),'B')
                c3d_rename_prep = [c3d_rename(1),'_',subject];
            else
                c3d_rename_prep = ['B',c3d_rename(1),'_',subject];
            end 
            
            c3d_rename(1) = {strjoin(c3d_rename_prep,'')};
            rename = strjoin(c3d_rename,'.');
            path_origin_new = split(path_origin,'\');
            path_origin_new(9)={rename};
            newname = strjoin(path_origin_new,'\');
            path_origin_old = split(path_origin,'\');
            path_origin_old(9)={list_c3dFiles(a).name};
            oldname = strjoin(path_origin_old,'\');
            movefile(oldname, newname); 
            flag =1;
        else
            flag=0;
        end
        
    end
    
    if flag==1
    list_c3dFiles = dir([path_origin,'\*.c3d']);
    end
    
    if isempty(list_c3dFiles)
        out = 0;
        disp(' ');
        disp('!!! error in f_copyCheck_c3dFiles: !!!');
        disp(['!!! There isn''t any c3d files in the given folder: ',path_origin,' !!!']);
    else
        index = 0;
        for files = 1:length(list_c3dFiles)
            switch list_c3dFiles(files).name(1:3)
                case 'Rep' % RepTrial
%                     infos_filename = strsplit(list_c3dFiles(files).name,'_');
%                     trial_Type = infos_filename{1,2}(1);
                otherwise
                    trial_Type = list_c3dFiles(files).name(1);
%             end
                switch trial_Type %list_c3dFiles(files).name(1)
                    case 's'
                        index = index + 1;
                        c3d_infos(index).filename = list_c3dFiles(files).name;
                        c3d_infos(index).Processed = 'static';
                        copyfile([path_origin,'\',list_c3dFiles(files).name],...
                            [path_new,'\',list_c3dFiles(files).name]);
                        disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                            c3d_infos(index).filename,' ---']);
                    case 'N'
                        index = index + 1;
                        c3d_infos(index).filename = list_c3dFiles(files).name;
                        c3d_infos(index).Processed = 'NoKinetics';
                        copyfile([path_origin,'\',list_c3dFiles(files).name],...
                            [path_new,'\',list_c3dFiles(files).name]);
                        disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                            c3d_infos(index).filename,' ---']);
                    case 'K'
                        [~,newName] = f_defineGaitCycles_generalCase(path_origin,...
                            path_new,list_c3dFiles(files).name);
                        index = index + 1;
                        c3d_infos(index).filename = newName;
                        c3d_infos(index).Processed = 'Kinetics';
                        disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                            c3d_infos(index).filename,' ---']);
                 
                    case {'B','L'} % 2 gait cycles defined, both have kinetics (B) or only the left one has kinetics (L)
                        [GCdefined,newName] = f_defineGaitCycles_generalCase(path_origin,...
                            path_new,list_c3dFiles(files).name);
                        index = index + 1;
                        if GCdefined
                            c3d_infos(index).Processed = 'Kinetics';
                            c3d_infos(index).filename = newName;
                            disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                                c3d_infos(index).filename,' ---']);
                        else
                            c3d_infos(index).Processed = 'NoKinetics';
                            c3d_infos(index).filename = newName;
                            disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                                c3d_infos(index).filename,' ---']);
                        end
                    case 'R'
                        [GCdefined,newName] = f_defineGaitCycles_generalCase(path_origin,...
                            path_new,list_c3dFiles(files).name);
                        index = index + 1;
                        if GCdefined
                            c3d_infos(index).Processed = 'Kinetics';
                            c3d_infos(index).filename = newName;
                            disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                                c3d_infos(index).filename,' ---']);
                        else
                            c3d_infos(index).Processed = 'NoKinetics';
                            c3d_infos(index).filename = newName;
                            disp(['--- ',list_c3dFiles(files).name,' copied to ', ...
                                c3d_infos(index).filename,' ---']);
                        end
                    otherwise
                        disp(['!!! the type of the ' list_c3dFiles(files).name ...
                            ' trial is unknown. Please have a look. !!!']);
                        continue
                end % switch list_c3dFiles(files).name(1)
            end % switch list_c3dFiles(files).name(1:3)
        end
    end
end